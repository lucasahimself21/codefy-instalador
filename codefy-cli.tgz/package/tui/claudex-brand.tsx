/** @jsxImportSource @opentui/solid */
// Marca CodeFy no terminal (opencode): logo da tela inicial e rodapé da barra lateral.
import type { TuiPlugin, TuiPluginApi } from "@opencode-ai/plugin/tui"

// Letras de 3 linhas no mesmo estilo de blocos do logo original: CODE em branco, FY em coral → violeta.
const CODE = ["█▀▀ █▀█ █▀▄ █▀▀", "█   █ █ █ █ █▀▀", "▀▀▀ ▀▀▀ ▀▀  ▀▀▀"]
const FY = ["█▀▀ █ █", "█▀▀ ▀▄▀", "▀    ▀ "]
const CORAL = "#E97850"
const VIOLET = "#786EFF"

function Logo(props: { api: TuiPluginApi }) {
  const theme = () => props.api.theme.current
  return (
    <box>
      {CODE.map((line, i) => (
        <box flexDirection="row" gap={1}>
          <text fg={theme().text} selectable={false}>{line}</text>
          <text fg={i === 0 ? CORAL : i === 1 ? "#B073A8" : VIOLET} selectable={false}>{FY[i]}</text>
        </box>
      ))}
    </box>
  )
}

const tui: TuiPlugin = async (api) => {
  api.slots.register({
    order: 10,
    slots: {
      home_logo() {
        return <Logo api={api} />
      },
      sidebar_footer() {
        return (
          <text fg={api.theme.current.textMuted}>
            <span style={{ fg: CORAL }}>•</span> <b>Code</b><span style={{ fg: VIOLET }}><b>Fy</b></span>
          </text>
        )
      },
    },
  })
}

export default { id: "claudex.brand", tui }
