// Terminais do espaço (painel Terminal do site). Cada um é um bash (ou o claudex) num pty;
// continua vivo se a página recarregar, e a tela volta com o que já tinha (últimos 256 KB).
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');
const { StringDecoder } = require('string_decoder');

const WORKDIR = process.env.WORKDIR || process.cwd();
const KEEP = 256 * 1024;
const terms = new Map(); // id -> { id, kind, title, proc, buf, clients, exited }

// O segredo do porteiro não vai pro shell; o token do usuário vai (é dele, e o claudex precisa).
const shellEnv = () => {
  const env = { ...process.env, TERM: 'xterm-256color', COLORTERM: 'truecolor', LANG: process.env.LANG || 'C.UTF-8', CLAUDEX_IN_SPACE: '1', BASH_SILENCE_DEPRECATION_WARNING: '1' };
  delete env.CLAUDEX_GATEWAY_SECRET; delete env.PASSWORD; delete env.PORT; delete env.ELECTRON_RUN_AS_NODE;
  // No PC, o claudex do terminal lê a API/token do mesmo arquivo que as Configurações editam.
  if (env.CLAUDEX_CONFIG) { delete env.CLAUDEX_API_BASE; delete env.CLAUDEX_API_KEY; }
  return env;
};

// node-pty (app CodeFy e Windows) ou, sem ele, o helper em Python (VPS/Linux).
let nodePty = null;
try { nodePty = require('node-pty'); } catch {}
// node-pty 1.1.0 vem do npm com o spawn-helper do Mac sem permissão de execução ("posix_spawnp failed").
try { const h = path.join(path.dirname(require.resolve('node-pty/package.json')), 'prebuilds', `${process.platform}-${process.arch}`, 'spawn-helper'); if (fs.existsSync(h)) fs.chmodSync(h, 0o755); } catch {}
const WIN = process.platform === 'win32';
const sq = (x) => `'${String(x).replace(/'/g, `'\\''`)}'`;
const dq = (x) => `"${String(x).replace(/"/g, '\\"')}"`;
// Linha que abre o claudex. No app, o executável é o Electron rodando como Node.
function claudexLine(style = WIN ? 'cmd' : 'sh') {
  const js = process.env.CLAUDEX_JS;
  if (!js) return 'codefy';
  const asNode = process.versions.electron;
  if (style === 'cmd') return `${asNode ? 'set "ELECTRON_RUN_AS_NODE=1" && ' : ''}${dq(process.execPath)} ${dq(js)}`;
  return `${asNode ? 'ELECTRON_RUN_AS_NODE=1 ' : ''}${sq(process.execPath)} ${sq(js)}`;
}
function spawnPty(kind, cols, rows, cwd = WORKDIR) {
  let file, args;
  if (WIN) {
    file = kind === 'claudex' ? (process.env.COMSPEC || 'cmd.exe') : 'powershell.exe';
    args = kind === 'claudex' ? ['/k', claudexLine('cmd')] : ['-NoLogo'];
  } else {
    // No PC usa o shell da pessoa (zsh no Mac); o claudex vai pelo caminho completo (não depende do PATH).
    file = process.env.SHELL || 'bash';
    args = kind === 'claudex' ? ['-lc', `${claudexLine('sh')}; exec ${sq(file)} -l`] : ['-l'];
  }
  if (nodePty) {
    const p = nodePty.spawn(file, args, { name: 'xterm-256color', cols, rows, cwd, env: shellEnv() });
    return { onData: (f) => p.onData(f), onExit: (f) => p.onExit(({ exitCode }) => f(exitCode)), write: (d) => p.write(d), resize: (c, r) => p.resize(c, r), kill: (sig) => { try { p.kill(WIN ? undefined : sig); } catch {} } };
  }
  const proc = spawn('python3', [path.join(__dirname, 'ptyhelper.py'), file, ...args], { cwd, env: shellEnv(), stdio: ['pipe', 'pipe', 'inherit', 'pipe'] });
  const dec = new StringDecoder('utf8');
  proc.stdin.on('error', () => {}); proc.stdio[3].on('error', () => {});
  proc.stdio[3].write(`${rows} ${cols}\n`); // tamanho inicial (o node-pty recebe na criação)
  return {
    onData: (f) => proc.stdout.on('data', (d) => { const s = dec.write(d); if (s) f(s); }),
    onExit: (f) => proc.on('exit', (code) => f(code ?? 0)),
    write: (d) => proc.stdin.write(d),
    resize: (c, r) => proc.stdio[3].write(`${r} ${c}\n`),
    kill: (sig) => proc.kill(sig),
  };
}

function create({ kind = 'shell', cols = 100, rows = 30, cwd } = {}) {
  const id = crypto.randomBytes(6).toString('hex');
  cols = Math.min(Math.max(+cols | 0, 10), 500); rows = Math.min(Math.max(+rows | 0, 2), 200);
  const proc = spawnPty(kind, cols, rows, cwd || WORKDIR);
  const t = { id, kind, title: kind === 'claudex' ? 'codefy' : WIN ? 'powershell' : path.basename(process.env.SHELL || 'bash'), proc, buf: '', clients: new Set(), exited: null };
  proc.onData((s) => {
    t.buf = (t.buf + s).slice(-KEEP);
    for (const c of t.clients) c.send(JSON.stringify({ t: 'o', d: s }));
  });
  proc.onExit((code) => {
    t.exited = code ?? 0;
    for (const c of t.clients) { c.send(JSON.stringify({ t: 'x', code: t.exited })); c.close(); }
    terms.delete(id);
  });
  terms.set(id, t);
  return info(t);
}
const info = (t) => ({ id: t.id, kind: t.kind, title: t.title });
const list = () => [...terms.values()].map(info);
function resize(t, cols, rows) {
  cols = Math.min(Math.max(+cols | 0, 10), 500); rows = Math.min(Math.max(+rows | 0, 2), 200);
  try { t.proc.resize(cols, rows); } catch {}
}
function kill(id) {
  const t = terms.get(id);
  if (!t) return false;
  t.proc.kill('SIGHUP');
  setTimeout(() => t.proc.kill('SIGKILL'), 2000).unref();
  return true;
}

// ---- WebSocket mínimo (RFC 6455), só o que o painel usa: texto, ping e fechar ----
function accept(req, socket) {
  const key = req.headers['sec-websocket-key'];
  if (!key || String(req.headers.upgrade).toLowerCase() !== 'websocket') { socket.end('HTTP/1.1 400 Bad Request\r\n\r\n'); return null; }
  const acc = crypto.createHash('sha1').update(key + '258EAFA5-E914-47DA-95CA-C5AB0DC85B11').digest('base64');
  socket.write(`HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: ${acc}\r\n\r\n`);
  socket.setNoDelay(true);
  const frame = (op, payload) => {
    const n = payload.length;
    const head = n < 126 ? Buffer.from([0x80 | op, n]) : n < 65536 ? Buffer.from([0x80 | op, 126, n >> 8, n & 255]) : Buffer.concat([Buffer.from([0x80 | op, 127]), (() => { const b = Buffer.alloc(8); b.writeBigUInt64BE(BigInt(n)); return b; })()]);
    if (!socket.destroyed) socket.write(Buffer.concat([head, payload]));
  };
  const ws = {
    onmessage: null, onclose: null,
    send: (s) => frame(1, Buffer.from(s)),
    close: () => { frame(8, Buffer.alloc(0)); socket.end(); },
  };
  let acc2 = Buffer.alloc(0), parts = [];
  socket.on('data', (d) => {
    acc2 = Buffer.concat([acc2, d]);
    for (;;) {
      if (acc2.length < 2) return;
      const fin = acc2[0] & 0x80, op = acc2[0] & 0x0f, masked = acc2[1] & 0x80;
      let len = acc2[1] & 0x7f, off = 2;
      if (len === 126) { if (acc2.length < 4) return; len = acc2.readUInt16BE(2); off = 4; }
      else if (len === 127) { if (acc2.length < 10) return; len = Number(acc2.readBigUInt64BE(2)); off = 10; }
      if (len > 4 * 1024 * 1024) return socket.destroy();
      const need = off + (masked ? 4 : 0) + len;
      if (acc2.length < need) return;
      let payload = acc2.subarray(off + (masked ? 4 : 0), need);
      if (masked) { const m = acc2.subarray(off, off + 4); payload = Buffer.from(payload); for (let i = 0; i < payload.length; i++) payload[i] ^= m[i & 3]; }
      acc2 = acc2.subarray(need);
      if (op === 8) { ws.close(); return; }
      if (op === 9) { frame(10, payload); continue; }
      if (op === 1 || op === 2 || op === 0) {
        parts.push(payload);
        if (fin) { const msg = Buffer.concat(parts).toString('utf8'); parts = []; ws.onmessage?.(msg); }
      }
    }
  });
  socket.on('close', () => ws.onclose?.());
  socket.on('error', () => {});
  return ws;
}

// /api/term/<id>/ws
function upgrade(req, socket, id) {
  const t = terms.get(id);
  if (!t) { socket.end('HTTP/1.1 404 Not Found\r\n\r\n'); return; }
  const ws = accept(req, socket);
  if (!ws) return;
  t.clients.add(ws);
  if (t.buf) ws.send(JSON.stringify({ t: 'o', d: t.buf }));
  ws.onmessage = (m) => {
    let j; try { j = JSON.parse(m); } catch { return; }
    if (j.t === 'i' && typeof j.d === 'string') t.proc.write(j.d);
    else if (j.t === 'r') resize(t, j.c, j.r);
  };
  ws.onclose = () => t.clients.delete(ws);
}

const clientCount = () => [...terms.values()].reduce((n, t) => n + t.clients.size, 0);
module.exports = { create, list, kill, upgrade, clientCount };

// ---- Terminal da própria pessoa (só no PC, via claudex web): abre o app de terminal dela já no CodeFy ----
const TERM_APPS = { darwin: ['terminal', 'iterm', 'custom'], win32: ['wt', 'cmd', 'custom'], linux: ['linux', 'custom'] };
function external(pref, dir = WORKDIR) {
  const plat = TERM_APPS[process.platform] ? process.platform : 'linux';
  const app = TERM_APPS[plat].includes(pref.termApp) ? pref.termApp : TERM_APPS[plat][0];
  if (!process.env.CLAUDEX_JS) throw Object.assign(new Error('Abra pelo app CodeFy ou pelo comando claudex web pra usar o seu terminal.'), { status: 400 });
  const run = (bin, args) => spawn(bin, args, { detached: true, stdio: 'ignore', env: shellEnv() }).on('error', () => {}).unref();
  if (app === 'custom') {
    const tpl = String(pref.termCmd || '').trim();
    if (!tpl) throw Object.assign(new Error('Escreva o comando do seu terminal em Configurações › Terminal.'), { status: 400 });
    const line = tpl.replaceAll('{dir}', WIN ? dq(dir) : sq(dir)).replaceAll('{cmd}', claudexLine());
    return WIN ? run('cmd', ['/c', line]) : run('/bin/sh', ['-c', line]);
  }
  if (app === 'terminal' || app === 'iterm') {
    const cmd = `cd ${sq(dir)} && ${claudexLine('sh')}`.replace(/\\/g, '\\\\').replace(/"/g, '\\"');
    const script = app === 'terminal'
      ? ['tell application "Terminal"', 'activate', `do script "${cmd}"`, 'end tell']
      : ['tell application "iTerm"', 'activate', 'set w to (create window with default profile)', `tell current session of w to write text "${cmd}"`, 'end tell'];
    return run('osascript', script.flatMap((l) => ['-e', l]));
  }
  if (app === 'wt') return run('cmd', ['/c', 'start', '', 'wt', '-d', dir, 'cmd', '/k', claudexLine('cmd')]);
  if (app === 'cmd') return run('cmd', ['/c', 'start', '', '/d', dir, 'cmd', '/k', claudexLine('cmd')]);
  // Linux: o terminal padrão do sistema
  return run('x-terminal-emulator', ['-e', 'sh', '-c', `cd ${sq(dir)} && ${claudexLine('sh')}; exec "$SHELL"`]);
}

module.exports.external = external;
module.exports.TERM_APPS = TERM_APPS;
