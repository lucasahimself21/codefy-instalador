// Agente do CodeFy: conversas em disco, ciclo modelo <-> ferramentas e eventos ao vivo (SSE).
// Fala com qualquer API no formato OpenAI (/chat/completions com streaming e tools).
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { spawn } = require('child_process');

const HOME = process.env.HOME || '/home/claudex';
const WORKDIR = process.env.WORKDIR || path.join(HOME, 'projetos');
const DATA = path.join(HOME, '.claudex', 'sessions');
const API_HOST = Buffer.from('Z2hvc3RjbGkuZGV2', 'base64').toString();
const API_BASE = (process.env.CLAUDEX_API_BASE || `https://${API_HOST}/v1`).replace(/\/$/, '');
const API_KEY = process.env.CLAUDEX_API_KEY || process.env.ANTHROPIC_API_KEY || '';
const DEFAULT_MODEL = process.env.CLAUDEX_DEFAULT_MODEL || 'claude-fable-5.1';
// No PC (claudex web), API e token vêm de ~/.claudex/cli.json e valem na hora; no espaço do site, do ambiente.
// Sem token, a requisição sai sem Authorization.
const CONFIG = process.env.CLAUDEX_CONFIG || '';
function apiConf() {
  if (CONFIG) {
    try { const c = JSON.parse(fs.readFileSync(CONFIG, 'utf8')); return { base: API_BASE, token: c.token ?? c.key ?? '' }; } catch {} // API fixa: só a chave vem do arquivo
  }
  return { base: API_BASE, token: API_KEY };
}
const MAX_STEPS = 60;

fs.mkdirSync(WORKDIR, { recursive: true });
fs.mkdirSync(DATA, { recursive: true });

// ---------- ids em ordem crescente ----------
let seq = 0;
const id = (prefix) => `${prefix}_${Date.now().toString(36).padStart(9, '0')}${(seq++ % 1296).toString(36).padStart(2, '0')}${crypto.randomBytes(4).toString('hex')}`;
const err = (status, message) => Object.assign(new Error(message), { status });

// ---------- eventos ----------
const clients = new Set();
function emit(type, properties) {
  const line = `data: ${JSON.stringify({ type, properties })}\n\n`;
  for (const res of clients) res.write(line);
}
function subscribe(req, res) {
  res.writeHead(200, { 'content-type': 'text/event-stream', 'cache-control': 'no-cache', connection: 'keep-alive', 'x-accel-buffering': 'no' });
  res.write(`data: ${JSON.stringify({ type: 'server.connected', properties: {} })}\n\n`);
  clients.add(res);
  res.on('close', () => clients.delete(res));
}
setInterval(() => { for (const res of clients) res.write(': ping\n\n'); }, 20000).unref();

// ---------- conversas ----------
const sessions = new Map(); // id -> { info, messages: [{ info, parts: [] }] }
for (const f of fs.readdirSync(DATA)) {
  if (!f.endsWith('.json')) continue;
  try { const s = JSON.parse(fs.readFileSync(path.join(DATA, f), 'utf8')); sessions.set(s.info.id, s); } catch {}
}
const saveTimers = new Map();
function save(s, now) {
  clearTimeout(saveTimers.get(s.info.id));
  const write = () => fs.writeFile(path.join(DATA, s.info.id + '.json'), JSON.stringify(s), () => {});
  if (now) return write();
  saveTimers.set(s.info.id, setTimeout(write, 400));
}
function touch(s) { s.info.time.updated = Date.now(); emit('session.updated', { sessionID: s.info.id, info: s.info }); save(s); }

const listSessions = () => [...sessions.values()].map((s) => s.info).sort((a, b) => b.time.updated - a.time.updated);
function getSession(sid) { const s = sessions.get(sid); if (!s) throw err(404, 'Conversa não encontrada.'); return s; }
const MODES = ['bypass', 'edits', 'ask'];
function createSession(opts = {}) {
  const now = Date.now();
  const approval = MODES.includes(opts.approval) ? opts.approval : 'edits';
  const model = typeof opts.model === 'string' && opts.model ? opts.model : DEFAULT_MODEL;
  const s = { info: { id: id('ses'), title: 'Nova conversa', model: { id: model }, approval, time: { created: now, updated: now } }, messages: [] };
  sessions.set(s.info.id, s);
  save(s, true);
  emit('session.created', { info: s.info });
  return s.info;
}
function updateSession(sid, body = {}) {
  const s = getSession(sid);
  if (typeof body.title === 'string' && body.title.trim()) s.info.title = body.title.trim().slice(0, 120);
  if (MODES.includes(body.approval)) s.info.approval = body.approval;
  if (typeof body.model === 'string' && body.model) s.info.model = { id: body.model };
  touch(s);
  return s.info;
}
function deleteSession(sid) {
  const s = getSession(sid);
  abort(sid);
  sessions.delete(sid);
  fs.rm(path.join(DATA, sid + '.json'), { force: true }, () => {});
  emit('session.deleted', { info: s.info });
}

// ---------- estado de execução ----------
const running = new Map(); // sid -> AbortController
const status = new Map();  // sid -> { type }
function setStatus(sid, st) {
  status.set(sid, st);
  emit('session.status', { sessionID: sid, status: st });
  if (st.type === 'idle') emit('session.idle', { sessionID: sid });
}
const statuses = () => Object.fromEntries([...status].filter(([, v]) => v.type !== 'idle'));
function abort(sid) { running.get(sid)?.abort(); }

// ---------- aprovação ----------
// edits (padrão): arquivos liberados, comando pede. bypass: tudo liberado. ask: criar/editar/comando pedem.
const perms = new Map(); // id -> { sid, tool, resolve }
function needsApproval(s, tool) {
  const mode = s.info.approval || 'edits';
  if (s.allow?.[tool]) return false;
  if (mode === 'ask') return ['write', 'edit', 'bash'].includes(tool);
  if (mode === 'edits') return tool === 'bash';
  return false;
}
function waitApproval(sid, tool, reqId, signal) {
  return new Promise((resolve) => {
    const done = (r) => { perms.delete(reqId); signal.removeEventListener('abort', onAbort); resolve(r); };
    const onAbort = () => done('reject');
    signal.addEventListener('abort', onAbort, { once: true });
    perms.set(reqId, { sid, tool, resolve: done });
  });
}
function replyPermission(reqId, reply) {
  const p = perms.get(reqId);
  if (!p) throw err(404, 'Esse pedido de aprovação já foi respondido.');
  if (!['once', 'always', 'reject'].includes(reply)) throw err(400, 'Resposta inválida.');
  if (reply === 'always') { const s = sessions.get(p.sid); if (s) { s.allow = { ...(s.allow || {}), [p.tool]: true }; save(s); } }
  p.resolve(reply);
}

// ---------- arquivos ----------
const resolve = (p) => path.resolve(WORKDIR, String(p || '.'));
const relTo = (p) => path.relative(WORKDIR, p) || '.';
function listDir(p) {
  const dir = resolve(p);
  let ents;
  try { ents = fs.readdirSync(dir, { withFileTypes: true }); } catch { throw err(404, 'Pasta não encontrada.'); }
  return ents.filter((e) => e.name !== '.git' && e.name !== 'node_modules' && !e.name.endsWith('.claudex-upload')).map((e) => {
    const abs = path.join(dir, e.name);
    return { name: e.name, path: relTo(abs), absolute: abs, type: e.isDirectory() ? 'directory' : 'file', ignored: false };
  });
}
const IMG = { '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.gif': 'image/gif', '.webp': 'image/webp', '.svg': 'image/svg+xml' };
function fileContent(p) {
  const f = resolve(p);
  let st;
  try { st = fs.statSync(f); } catch { throw err(404, 'Arquivo não encontrado.'); }
  if (st.isDirectory()) throw err(400, 'Isso é uma pasta.');
  const mime = IMG[path.extname(f).toLowerCase()];
  if (mime && mime !== 'image/svg+xml') {
    if (st.size > 8e6) return { type: 'binary' };
    return { type: 'binary', encoding: 'base64', mimeType: mime, content: fs.readFileSync(f).toString('base64') };
  }
  if (st.size > 2e6) return { type: 'binary' };
  const buf = fs.readFileSync(f);
  if (buf.includes(0)) return { type: 'binary' };
  return { type: 'text', content: buf.toString('utf8') };
}

// ---------- .codefy da pasta (regras, agentes, skills) + skills globais (~/.claudex/skills) ----------
// Na pasta de projetos nasce .codefy/: REGRAS.md (vale em toda conversa), agentes/<nome>.md e skills/<nome>/SKILL.md.
const CFY = path.join(WORKDIR, '.codefy');
const SKILLS_DIRS = [path.join(CFY, 'skills'), path.join(HOME, '.claudex', 'skills')];
function ensureCodefy() {
  try {
    fs.mkdirSync(path.join(CFY, 'agentes'), { recursive: true });
    fs.mkdirSync(path.join(CFY, 'skills'), { recursive: true });
    const regras = path.join(CFY, 'REGRAS.md');
    if (!fs.existsSync(regras)) fs.writeFileSync(regras, '# Regras\n\nO que estiver aqui vale em toda conversa do CodeFy nesta pasta (site e terminal).\n\n- Responda em português, direto e curto.\n');
    const leia = path.join(CFY, 'LEIAME.md');
    if (!fs.existsSync(leia)) fs.writeFileSync(leia, '# .codefy\n\n- `REGRAS.md`: regras que valem em toda conversa.\n- `agentes/<nome>.md`: agente com papel próprio. Topo do arquivo:\n\n  ```\n  ---\n  name: revisor\n  description: revisa código antes do commit\n  ---\n  Instruções do agente...\n  ```\n\n  Chame com `/revisor` no chat.\n- `skills/<nome>/SKILL.md`: passo a passo pra uma tarefa (mesmo topo com name e description). Chame com `/<nome>` ou deixe o CodeFy usar quando a tarefa pedir.\n');
  } catch {}
}
ensureCodefy();
function readRules() {
  try { return fs.readFileSync(path.join(CFY, 'REGRAS.md'), 'utf8').trim(); } catch { return ''; }
}
function meta(file, fallback, kind) {
  let txt = '';
  try { txt = fs.readFileSync(file, 'utf8'); } catch { return null; }
  const fm = /^---\r?\n([\s\S]*?)\r?\n---/.exec(txt)?.[1] || '';
  const get = (k) => (new RegExp(`^${k}:\\s*(.+)$`, 'm').exec(fm)?.[1] || '').trim().replace(/^["']|["']$/g, '');
  return { name: get('name') || fallback, description: get('description'), file, kind };
}
function listSkills() {
  const out = [], seen = new Set();
  const add = (x) => { if (x && !seen.has(x.name)) { seen.add(x.name); out.push(x); } };
  try {
    for (const f of fs.readdirSync(path.join(CFY, 'agentes'))) if (f.endsWith('.md')) add(meta(path.join(CFY, 'agentes', f), f.slice(0, -3), 'agente'));
  } catch {}
  for (const dir of SKILLS_DIRS) {
    let dirs = [];
    try { dirs = fs.readdirSync(dir, { withFileTypes: true }).filter((d) => d.isDirectory()); } catch { continue; }
    for (const d of dirs) add(meta(path.join(dir, d.name, 'SKILL.md'), d.name, 'skill'));
  }
  return out.sort((a, b) => a.name.localeCompare(b.name));
}
const SKIP = new Set(['.git', 'node_modules', '.cache', '.npm', '__pycache__', '.venv']);
function searchFiles(q, limit = 30) {
  q = String(q || '').toLowerCase();
  const out = [];
  let seen = 0;
  const walk = (dir, depth) => {
    if (depth > 8 || seen > 20000) return;
    let ents; try { ents = fs.readdirSync(dir, { withFileTypes: true }); } catch { return; }
    for (const e of ents) {
      if (SKIP.has(e.name) || e.name.endsWith('.claudex-upload')) continue;
      seen++;
      const abs = path.join(dir, e.name), rel = path.relative(WORKDIR, abs), isDir = e.isDirectory();
      const hay = rel.toLowerCase();
      if (!q || hay.includes(q)) {
        const score = !q ? rel.split('/').length : (path.basename(hay).startsWith(q) ? 0 : path.basename(hay).includes(q) ? 1 : 2) * 100 + rel.length;
        out.push({ path: rel + (isDir ? '/' : ''), type: isDir ? 'directory' : 'file', score });
      }
      if (isDir) walk(abs, depth + 1);
    }
  };
  walk(WORKDIR, 0);
  return out.sort((a, b) => a.score - b.score).slice(0, limit).map(({ score, ...r }) => r);
}
// "/skill ..." no começo e "@arquivo" no meio viram contexto extra pro modelo (invisível na conversa).
function expandMentions(text) {
  const extra = [];
  const m = /^\/([\w.-]+)(?:\s|$)/.exec(text);
  if (m) {
    const sk = listSkills().find((x) => x.name === m[1] || path.basename(path.dirname(x.file)) === m[1]);
    if (sk) extra.push(sk.kind === 'agente'
      ? `O usuário chamou o agente "${sk.name}". Aja como esse agente nesta mensagem, seguindo as instruções dele (arquivo ${sk.file}):\n\n${clip(fs.readFileSync(sk.file, 'utf8'), 40000)}`
      : `O usuário chamou a skill "${sk.name}". Siga as instruções dela (arquivo ${sk.file}):\n\n${clip(fs.readFileSync(sk.file, 'utf8'), 40000)}`);
  }
  for (const [, ref] of text.matchAll(/(?:^|\s)@([^\s@]+)/g)) {
    const f = path.resolve(WORKDIR, ref);
    let st; try { st = fs.statSync(f); } catch { continue; }
    if (st.isDirectory()) extra.push(`Pasta @${ref} (conteúdo):\n${listDir(f).map((e) => e.name + (e.type === 'directory' ? '/' : '')).join('\n') || '(vazia)'}`);
    else {
      const c = fileContent(f);
      extra.push(c.type === 'text' ? `Arquivo @${ref}:\n\`\`\`\n${clip(c.content, 60000)}\n\`\`\`` : `Arquivo @${ref} não é texto (${st.size} bytes).`);
    }
  }
  return extra.join('\n\n');
}

// ---------- ferramentas ----------
const TOOLS = [
  { name: 'read', description: 'Lê um arquivo de texto e devolve o conteúdo com números de linha.', parameters: { type: 'object', properties: { filePath: { type: 'string', description: 'Caminho do arquivo (relativo à pasta de projetos ou absoluto)' } }, required: ['filePath'] } },
  { name: 'write', description: 'Cria ou substitui um arquivo inteiro com o conteúdo dado. Cria as pastas que faltarem.', parameters: { type: 'object', properties: { filePath: { type: 'string' }, content: { type: 'string' } }, required: ['filePath', 'content'] } },
  { name: 'edit', description: 'Troca um trecho exato de um arquivo. oldString precisa aparecer uma vez só (ou use replaceAll).', parameters: { type: 'object', properties: { filePath: { type: 'string' }, oldString: { type: 'string' }, newString: { type: 'string' }, replaceAll: { type: 'boolean' } }, required: ['filePath', 'oldString', 'newString'] } },
  { name: 'list', description: 'Lista arquivos e pastas de um diretório.', parameters: { type: 'object', properties: { path: { type: 'string', description: 'Pasta (padrão: pasta de projetos)' } } } },
  { name: 'bash', description: 'Roda um comando no terminal (bash) dentro da pasta de projetos. Use pra buscar (rg), instalar, rodar scripts, git etc. Limite padrão de 120 s.', parameters: { type: 'object', properties: { command: { type: 'string' }, timeout: { type: 'number', description: 'Segundos (máx. 600)' } }, required: ['command'] } },
];
const clip = (s, n = 30000) => (s.length > n ? s.slice(0, n) + `\n… (cortado, ${s.length - n} caracteres a mais)` : s);

// No Windows sem contêiner: o bash do Git (o "bash" do System32 é o do WSL, que pode nem ter Linux instalado).
const GIT_BASH = process.platform === 'win32' ? [process.env.ProgramFiles, process.env['ProgramFiles(x86)'], process.env.LOCALAPPDATA && path.join(process.env.LOCALAPPDATA, 'Programs')].filter(Boolean).map((d) => path.join(d, 'Git', 'bin', 'bash.exe')).find((f) => fs.existsSync(f)) : null;
// Windows sem Git: os comandos vão pro cmd (e o modelo é avisado na descrição da ferramenta).
const WIN_CMD = process.platform === 'win32' && !GIT_BASH;
if (WIN_CMD) TOOLS.find((t) => t.name === 'bash').description = 'Roda um comando no Prompt de Comando do Windows (cmd.exe, não é bash) dentro da pasta de projetos. Use dir, type, where, npm, node, git etc. Limite padrão de 120 s.';
function runBash(command, timeoutS, signal) {
  return new Promise((ok) => {
    const p = spawn(WIN_CMD ? (process.env.COMSPEC || 'cmd.exe') : GIT_BASH || 'bash', WIN_CMD ? ['/d', '/s', '/c', `"${command}"`] : ['-lc', command], { cwd: WORKDIR, windowsVerbatimArguments: WIN_CMD, env: { ...process.env, CLAUDEX_API_KEY: '', ANTHROPIC_API_KEY: '', PASSWORD: '' } });
    let out = '';
    const add = (d) => { out += d; if (out.length > 200000) out = out.slice(-200000); };
    p.stdout.on('data', add); p.stderr.on('data', add);
    const kill = () => p.kill('SIGKILL');
    const t = setTimeout(() => { out += `\n(parado: passou de ${timeoutS} s)`; kill(); }, timeoutS * 1000);
    signal.addEventListener('abort', kill, { once: true });
    p.on('close', (code) => { clearTimeout(t); signal.removeEventListener('abort', kill); ok({ out: clip(out.trim() || '(sem saída)'), code }); });
  });
}

async function runTool(name, input, signal) {
  switch (name) {
    case 'read': {
      const c = fileContent(input.filePath);
      if (c.type !== 'text') return 'Arquivo não é texto.';
      return clip(c.content.split('\n').map((l, i) => `${String(i + 1).padStart(5)}\t${l}`).join('\n'), 60000);
    }
    case 'write': {
      const f = resolve(input.filePath);
      fs.mkdirSync(path.dirname(f), { recursive: true });
      fs.writeFileSync(f, input.content ?? '');
      emit('file.edited', { file: f });
      return `Arquivo salvo: ${relTo(f)}`;
    }
    case 'edit': {
      const f = resolve(input.filePath);
      const src = fs.readFileSync(f, 'utf8');
      const n = src.split(input.oldString).length - 1;
      if (!input.oldString || n === 0) throw new Error('oldString não foi encontrado no arquivo.');
      if (n > 1 && !input.replaceAll) throw new Error(`oldString aparece ${n} vezes; mande mais contexto ou use replaceAll.`);
      fs.writeFileSync(f, input.replaceAll ? src.split(input.oldString).join(input.newString) : src.replace(input.oldString, () => input.newString));
      emit('file.edited', { file: f });
      return `Arquivo editado: ${relTo(f)}`;
    }
    case 'list':
      return listDir(input.path || '.').map((e) => e.name + (e.type === 'directory' ? '/' : '')).join('\n') || '(vazia)';
    case 'bash': {
      const r = await runBash(String(input.command || ''), Math.min(+input.timeout || 120, 600), signal);
      emit('file.watcher.updated', { file: null });
      return r.code ? `${r.out}\n(código de saída ${r.code})` : r.out;
    }
    default:
      throw new Error(`Ferramenta desconhecida: ${name}`);
  }
}

// ---------- ciclo do agente ----------
const SYSTEM = () => `Você é o CodeFy, um agente que trabalha nos arquivos de projeto do usuário.
Pasta de projetos: ${WORKDIR} (caminhos relativos partem daqui). Você roda num container Linux (Debian) isolado que é só deste usuário, com autonomia total nele: pode usar sudo sem senha pra instalar o que precisar (sudo apt-get install -y ..., pip, npm). Ex.: navegador = sudo apt-get install -y chromium e rodar com --headless --no-sandbox.
Use as ferramentas pra ler, criar e editar arquivos e rodar comandos, em vez de só descrever o que fazer.
Responda em português do Brasil, direto e curto. Hoje é ${new Date().toISOString().slice(0, 10)}.
Regras, agentes e skills desta pasta ficam em .codefy/ (REGRAS.md, agentes/<nome>.md, skills/<nome>/SKILL.md); se o usuário pedir pra criar uma regra, agente ou skill, crie lá.${rulesNote()}${skillsNote()}`;
function rulesNote() {
  const r = readRules();
  return r ? `\n\nRegras do usuário (.codefy/REGRAS.md), siga sempre:\n${clip(r, 20000)}` : '';
}
function skillsNote() {
  ensureCodefy();
  const sk = listSkills();
  if (!sk.length) return '';
  return `\n\nAgentes e skills disponíveis (leia o arquivo com a ferramenta read quando a tarefa pedir):\n${sk.map((x) => `- ${x.name} (${x.kind}): ${x.description || '(sem descrição)'} (${x.file})`).join('\n')}`;
}

function toApiMessages(s) {
  const out = [{ role: 'system', content: SYSTEM() }];
  for (const m of s.messages) {
    if (m.info.role === 'user') {
      out.push({ role: 'user', content: m.parts.filter((p) => p.type === 'text').map((p) => p.text).join('\n') });
      continue;
    }
    // Cada passo (step) do assistente vira uma mensagem + as respostas das ferramentas.
    let cur = null;
    const flush = () => {
      if (!cur) return;
      const msg = { role: 'assistant', content: cur.text || null };
      if (cur.tools.length) msg.tool_calls = cur.tools.map((t) => ({ id: t.callID, type: 'function', function: { name: t.tool, arguments: JSON.stringify(t.state.input || {}) } }));
      if (msg.content || msg.tool_calls) out.push(msg);
      for (const t of cur.tools) out.push({ role: 'tool', tool_call_id: t.callID, content: t.state.status === 'completed' ? String(t.state.output) : `Erro: ${t.state.error || 'interrompido'}` });
      cur = null;
    };
    for (const p of m.parts) {
      if (p.type === 'step-start') { flush(); cur = { text: '', tools: [] }; }
      cur = cur || { text: '', tools: [] };
      if (p.type === 'text') cur.text += p.text;
      if (p.type === 'tool') cur.tools.push(p);
    }
    flush();
  }
  return out;
}

async function* sse(res) {
  const dec = new TextDecoder();
  let buf = '';
  for await (const chunk of res.body) {
    buf += dec.decode(chunk, { stream: true });
    let i;
    while ((i = buf.indexOf('\n')) >= 0) {
      const line = buf.slice(0, i).trim();
      buf = buf.slice(i + 1);
      if (!line.startsWith('data:')) continue;
      const d = line.slice(5).trim();
      if (d === '[DONE]') return;
      try { yield JSON.parse(d); } catch {}
    }
  }
}

// Erro da API em mensagem própria: nunca mostra endereço nem nome do provedor. (Igual em cli/bin/claudex.js.)
const HOST_NAME = API_HOST.split('.')[0];
const scrub = (s) => String(s || '').replace(new RegExp(`https?://\\S*${HOST_NAME.slice(0, 5)}\\S*`, 'gi'), '').replace(new RegExp(`${HOST_NAME.slice(0, 5)}\\s*-?\\s*(${HOST_NAME.slice(5)}|fy)`, 'gi'), 'CodeFy');
function apiError(status, body) {
  let m = ''; try { m = JSON.parse(body).error?.message || ''; } catch {}
  m = String(m || body || '');
  const ip = /IP ([0-9a-f.:]+)/i.exec(m)?.[1];
  if (ip && /not authorized|pending|confirm/i.test(m)) return `Seu IP não está cadastrado. Envie seu IP para o admin: ${ip || '(veja em meuip.com.br)'}`;
  if (status === 401 || status === 403) return 'Chave do CodeFy recusada: está errada ou venceu. Troque a chave (codefy login ou Configurações › Chave).';
  if (status === 429) return 'Limite de uso da chave atingido. Espere um pouco e tente de novo.';
  if (status >= 500) return 'O servidor do CodeFy está com problema agora. Tente de novo em instantes.';
  return scrub(m).trim().slice(0, 300) || `Erro ${status}.`;
}
const RETRY = [408, 429, 500, 502, 503, 504, 529];
async function callModel(sid, model, messages, signal) {
  for (let attempt = 1; ; attempt++) {
    let res, msg;
    const { base, token } = apiConf();
    try {
      res = await fetch(base + '/chat/completions', {
        method: 'POST', signal,
        headers: { 'content-type': 'application/json', ...(token ? { authorization: `Bearer ${token}` } : {}) },
        body: JSON.stringify({ model, messages, stream: true, tools: TOOLS.map((t) => ({ type: 'function', function: t })) }),
      });
    } catch (e) {
      if (signal.aborted) throw e;
      msg = 'Não consegui falar com o servidor do CodeFy. Confira a internet.';
      if (attempt >= 4) throw new Error(msg);
    }
    if (res?.ok) return res;
    if (res) {
      msg = apiError(res.status, await res.text());
      if (!RETRY.includes(res.status) || attempt >= 4) throw new Error(msg);
    }
    setStatus(sid, { type: 'retry', attempt, message: msg });
    await new Promise((r) => setTimeout(r, 1500 * attempt));
    if (signal.aborted) throw Object.assign(new Error('abort'), { name: 'AbortError' });
    setStatus(sid, { type: 'busy' });
  }
}

function prompt(sid, body) {
  const s = getSession(sid);
  if (running.has(sid)) throw err(409, 'Essa conversa já está trabalhando.');
  const text = (body.parts || []).filter((p) => p.type === 'text').map((p) => p.text).join('\n').trim();
  if (!text) throw err(400, 'Mensagem vazia.');
  const model = body.model?.modelID || s.info.model?.id || DEFAULT_MODEL;
  s.info.model = { id: model };

  const now = Date.now();
  const user = { info: { id: id('msg'), sessionID: sid, role: 'user', time: { created: now } }, parts: [{ id: id('prt'), sessionID: sid, type: 'text', text }] };
  const ctx = expandMentions(text);
  if (ctx) user.parts.push({ id: id('prt'), sessionID: sid, type: 'text', text: ctx, synthetic: true });
  for (const p of user.parts) p.messageID = user.info.id;
  s.messages.push(user);
  emit('message.updated', { info: user.info });
  emit('message.part.updated', { part: user.parts[0] });
  if (s.info.title === 'Nova conversa') s.info.title = text.replace(/\s+/g, ' ').slice(0, 60);
  touch(s);

  const ctl = new AbortController();
  running.set(sid, ctl);
  setStatus(sid, { type: 'busy' });
  loop(s, model, ctl.signal)
    .catch((e) => console.error('agente', sid, e))
    .finally(() => { running.delete(sid); setStatus(sid, { type: 'idle' }); save(s, true); });
}

async function loop(s, model, signal) {
  const sid = s.info.id;
  const ai = { info: { id: id('msg'), sessionID: sid, role: 'assistant', modelID: model, time: { created: Date.now() } }, parts: [] };
  s.messages.push(ai);
  emit('message.updated', { info: ai.info });
  const addPart = (p) => { Object.assign(p, { id: id('prt'), sessionID: sid, messageID: ai.info.id }); ai.parts.push(p); emit('message.part.updated', { part: p }); return p; };
  const upd = (p) => emit('message.part.updated', { part: p });

  let empty = 0; // respostas vazias seguidas (a API às vezes fecha o stream sem conteúdo)
  try {
    for (let step = 0; step < MAX_STEPS; step++) {
      const history = toApiMessages(s);
      addPart({ type: 'step-start' });
      const res = await callModel(sid, model, history, signal);
      let text = null, reasoning = null, finish = null;
      const calls = []; // index -> { part, args }
      for await (const ch of sse(res)) {
        if (ch.error) throw new Error(apiError(+ch.error.code || 500, JSON.stringify(ch)));
        const c = ch.choices?.[0];
        if (!c) continue;
        const d = c.delta || {};
        const r = d.reasoning_content ?? d.reasoning;
        if (typeof r === 'string' && r) {
          if (!reasoning) reasoning = addPart({ type: 'reasoning', text: '' });
          reasoning.text += r;
          emit('message.part.delta', { sessionID: sid, messageID: ai.info.id, partID: reasoning.id, field: 'text', delta: r });
        }
        if (d.content) {
          if (!text) text = addPart({ type: 'text', text: '' });
          text.text += d.content;
          emit('message.part.delta', { sessionID: sid, messageID: ai.info.id, partID: text.id, field: 'text', delta: d.content });
        }
        for (const tc of d.tool_calls || []) {
          const i = tc.index ?? 0;
          if (!calls[i]) calls[i] = { part: addPart({ type: 'tool', tool: tc.function?.name || '', callID: tc.id || id('call'), state: { status: 'pending', input: {} } }), args: '' };
          if (tc.function?.name && !calls[i].part.tool) calls[i].part.tool = tc.function.name;
          if (tc.function?.arguments) calls[i].args += tc.function.arguments;
        }
        if (c.finish_reason) finish = c.finish_reason;
      }
      if (text) upd(text);
      if (reasoning) upd(reasoning);
      save(s);

      const todo = calls.filter(Boolean);
      if (!text && !reasoning && !todo.length) {
        if (++empty > 3) throw new Error('O modelo não respondeu. Tente de novo ou troque o modelo.');
        setStatus(sid, { type: 'retry', attempt: empty, message: 'O modelo não respondeu, tentando de novo…' });
        await new Promise((r) => setTimeout(r, 1500 * empty));
        setStatus(sid, { type: 'busy' });
        step--; continue;
      }
      empty = 0;
      if (!todo.length) { ai.info.finish = finish || 'stop'; break; }
      for (const { part, args } of todo) {
        let input = {};
        try { input = args ? JSON.parse(args) : {}; } catch { part.state = { status: 'error', input: {}, error: 'Argumentos inválidos vindos do modelo.' }; upd(part); continue; }
        if (needsApproval(s, part.tool)) {
          const reqId = id('per');
          part.state = { status: 'pending', input, awaiting: reqId };
          upd(part);
          setStatus(sid, { type: 'waiting' });
          const reply = await waitApproval(sid, part.tool, reqId, signal);
          if (signal.aborted) throw Object.assign(new Error('abort'), { name: 'AbortError' });
          setStatus(sid, { type: 'busy' });
          if (reply === 'reject') { part.state = { status: 'error', input, error: 'Negado pelo usuário. Não tente de novo sem perguntar.' }; upd(part); continue; }
        }
        part.state = { status: 'running', input };
        upd(part);
        // Antes/depois do arquivo, pra interface mostrar o diff da edição.
        const snap = () => { try { const c = fileContent(input.filePath); return c.type === 'text' ? clip(c.content, 200000) : null; } catch { return ''; } };
        const before = ['write', 'edit'].includes(part.tool) ? snap() : undefined;
        try {
          const output = await runTool(part.tool, input, signal);
          part.state = { status: 'completed', input, output, title: input.filePath || input.command || input.path || '' };
          if (before !== undefined && before !== null) { const after = snap(); if (after !== null) part.state.diff = { before, after }; }
        } catch (e) {
          part.state = { status: 'error', input, error: signal.aborted ? 'Parado.' : e.message };
        }
        upd(part);
        if (signal.aborted) throw Object.assign(new Error('abort'), { name: 'AbortError' });
      }
      save(s);
      if (step === MAX_STEPS - 1) throw new Error(`Parei depois de ${MAX_STEPS} passos seguidos. Mande "continua" pra seguir.`);
    }
  } catch (e) {
    ai.info.error = signal.aborted || e.name === 'AbortError'
      ? { name: 'MessageAbortedError', data: { message: 'Parado.' } }
      : { name: 'APIError', data: { message: e.message } };
    for (const p of ai.parts) if (p.type === 'tool' && ['pending', 'running'].includes(p.state.status)) { p.state = { ...p.state, status: 'error', error: 'Parado.' }; upd(p); }
  }
  ai.info.time.completed = Date.now();
  emit('message.updated', { info: ai.info });
  touch(s);
}

const fileChanged = (file) => emit('file.watcher.updated', { file });

const clientCount = () => clients.size; // janelas do site conectadas (eventos ao vivo)
module.exports = { WORKDIR, CONFIG, API_BASE, apiConf, clientCount, fileChanged, listSkills, searchFiles, subscribe, listSessions, createSession, getSession, updateSession, replyPermission, deleteSession, statuses, prompt, abort, listDir, fileContent };
