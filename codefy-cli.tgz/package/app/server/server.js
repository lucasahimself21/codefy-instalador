// CodeFy: serve a interface, faz o login e roda o agente (chama a API do modelo direto, sem CLI no meio).
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { spawn } = require('child_process');
const agent = require('./agent');
const term = require('./term');
const MAX_UPLOAD = (+process.env.CLAUDEX_MAX_UPLOAD_MB || 1024) * 1024 * 1024;

// Caminho dentro da pasta de projetos (upload/download não saem dela).
function inWork(p) {
  const f = path.resolve(agent.WORKDIR, String(p || '.'));
  if (f !== agent.WORKDIR && !f.startsWith(agent.WORKDIR + path.sep)) throw Object.assign(new Error('Fora da pasta de projetos.'), { status: 400 });
  return f;
}
// ---- Explorer: renomear, mover, copiar, apagar (lixeira com desfazer) ----
const TRASH = path.join(process.env.HOME || '/tmp', '.claudex', 'lixeira');
const bad = (status, message) => Object.assign(new Error(message), { status });
const relOf = (f) => path.relative(agent.WORKDIR, f);
function checkRel(rel) {
  rel = String(rel || '').replace(/\\/g, '/');
  if (!rel || rel.split('/').some((x) => x === '..')) throw bad(400, 'Nome inválido.');
  const f = inWork(rel);
  if (f === agent.WORKDIR) throw bad(400, 'Não dá pra mexer na pasta de projetos inteira.');
  return f;
}
// rename entre discos diferentes (lixeira fora do volume do projeto) vira copiar + apagar.
function moveFs(from, to) {
  fs.mkdirSync(path.dirname(to), { recursive: true });
  try { fs.renameSync(from, to); } catch (e) {
    if (e.code !== 'EXDEV') throw e;
    fs.cpSync(from, to, { recursive: true, preserveTimestamps: true });
    fs.rmSync(from, { recursive: true, force: true });
  }
}
// Nome livre no destino, no jeito do VS Code: "nome copy.js", "nome copy 2.js"...
function freeName(dir, base) {
  const ext = path.extname(base), stem = ext && ext !== base ? base.slice(0, -ext.length) : base;
  for (let n = 1; ; n++) {
    const name = n === 1 ? `${stem} copy${stem === base ? '' : ext}` : `${stem} copy ${n}${stem === base ? '' : ext}`;
    if (!fs.existsSync(path.join(dir, name))) return path.join(dir, name);
  }
}
function purgeTrash() {
  try {
    for (const d of fs.readdirSync(TRASH)) if (Date.now() - (+d.split('-')[0] || 0) > 7 * 864e5) fs.rmSync(path.join(TRASH, d), { recursive: true, force: true });
  } catch {}
}
async function fileOps(req, res, op) {
  const b = await readBody(req);
  if (op === 'rename') {
    const from = checkRel(b.from), to = checkRel(b.to);
    if (!fs.existsSync(from)) throw bad(404, 'Não encontrado.');
    if (fs.existsSync(to) && from.toLowerCase() !== to.toLowerCase()) throw bad(409, 'Já existe um arquivo ou pasta com esse nome.');
    moveFs(from, to); agent.fileChanged(to);
    return json(res, 200, { ok: true, path: relOf(to), absolute: to });
  }
  if (op === 'restore') {
    const ids = (Array.isArray(b.ids) ? b.ids : []).filter((x) => /^\d+-[0-9a-f]{6}$/.test(x));
    const restored = [];
    for (const id of ids) {
      const dir = path.join(TRASH, id);
      let orig; try { orig = fs.readFileSync(path.join(dir, '.origem'), 'utf8'); } catch { continue; }
      const to = inWork(orig);
      if (fs.existsSync(to)) continue;
      moveFs(path.join(dir, path.basename(to)), to);
      fs.rmSync(dir, { recursive: true, force: true });
      restored.push(orig); agent.fileChanged(to);
    }
    return json(res, 200, { ok: true, paths: restored });
  }
  const paths = (Array.isArray(b.paths) ? b.paths : []).slice(0, 500).map(checkRel);
  if (!paths.length) throw bad(400, 'Nada selecionado.');
  if (op === 'delete') {
    purgeTrash();
    const trashed = [];
    for (const f of paths) {
      if (!fs.existsSync(f)) continue;
      const id = `${Date.now()}-${crypto.randomBytes(3).toString('hex')}`;
      moveFs(f, path.join(TRASH, id, path.basename(f)));
      fs.writeFileSync(path.join(TRASH, id, '.origem'), relOf(f));
      trashed.push(id); agent.fileChanged(f);
    }
    return json(res, 200, { ok: true, trash: trashed });
  }
  if (op === 'copy' || op === 'move') {
    const dir = b.to ? checkRel(b.to) : agent.WORKDIR;
    if (!fs.statSync(dir, { throwIfNoEntry: false })?.isDirectory()) throw bad(400, 'O destino não é uma pasta.');
    const done = [];
    for (const f of paths) {
      if (dir === f || dir.startsWith(f + path.sep)) throw bad(400, 'Não dá pra pôr uma pasta dentro dela mesma.');
      let to = path.join(dir, path.basename(f));
      if (op === 'move') {
        if (to === f) continue;
        if (fs.existsSync(to)) throw bad(409, `Já existe "${path.basename(f)}" no destino.`);
        moveFs(f, to);
      } else {
        if (fs.existsSync(to)) to = freeName(dir, path.basename(f));
        fs.cpSync(f, to, { recursive: true });
      }
      done.push(relOf(to)); agent.fileChanged(to);
    }
    return json(res, 200, { ok: true, paths: done });
  }
  throw bad(404, 'Rota não existe.');
}
const disposition = (name) => `attachment; filename="${name.replace(/[^\x20-\x7e]|"/g, '_')}"; filename*=UTF-8''${encodeURIComponent(name)}`;

// Recebe o arquivo cru no corpo (um por pedido) e grava em ?path=pasta&name=sub/arquivo.ext
function upload(req, res, url) {
  const dir = inWork(url.searchParams.get('path') || '.');
  const name = String(url.searchParams.get('name') || '').replace(/\\/g, '/');
  if (!name || name.split('/').some((x) => !x || x === '..' || x === '.')) throw Object.assign(new Error('Nome de arquivo inválido.'), { status: 400 });
  const dest = inWork(path.join(path.relative(agent.WORKDIR, dir), name));
  fs.mkdirSync(path.dirname(dest), { recursive: true });
  const tmp = dest + '.claudex-upload';
  const out = fs.createWriteStream(tmp);
  let size = 0, failed = false;
  const abort = (code, msg) => { if (failed) return; failed = true; out.destroy(); fs.rm(tmp, { force: true }, () => {}); if (!res.headersSent) json(res, code, { error: msg }); };
  req.on('data', (d) => { size += d.length; if (size > MAX_UPLOAD) { abort(413, `Arquivo maior que ${MAX_UPLOAD / 1048576} MB.`); req.destroy(); } });
  req.on('aborted', () => abort(400, 'Envio interrompido.'));
  out.on('error', (e) => abort(500, e.message));
  req.pipe(out);
  out.on('finish', () => {
    if (failed) return;
    fs.rename(tmp, dest, (e) => {
      if (e) return abort(500, e.message);
      agent.fileChanged(dest);
      json(res, 200, { ok: true, path: path.relative(agent.WORKDIR, dest), size });
    });
  });
}

// Arquivo sai como está; pasta sai como .zip montado na hora.
function download(req, res, url) {
  const f = inWork(url.searchParams.get('path') || '.');
  let st;
  try { st = fs.statSync(f); } catch { throw Object.assign(new Error('Não encontrado.'), { status: 404 }); }
  if (st.isFile()) {
    res.writeHead(200, { 'content-type': 'application/octet-stream', 'content-length': st.size, 'content-disposition': disposition(path.basename(f)) });
    return fs.createReadStream(f).pipe(res);
  }
  const base = f === agent.WORKDIR ? 'projetos' : path.basename(f);
  const z = spawn('zip', ['-r', '-q', '-', '.', '-x', '*/node_modules/*', 'node_modules/*', '*.claudex-upload'], { cwd: f });
  res.writeHead(200, { 'content-type': 'application/zip', 'content-disposition': disposition(base + '.zip') });
  z.stdout.pipe(res);
  z.on('error', () => res.end());
  res.on('close', () => { if (!res.writableFinished) z.kill('SIGKILL'); });
}

const PORT = +process.env.PORT || 8080;
const PASSWORD = process.env.PASSWORD || '';
const WEB = path.join(__dirname, '..', 'web');
const SECRET = crypto.createHash('sha256').update('claudex:' + PASSWORD).digest();

// Atrás do porteiro (gateway), o login é dele: aqui só entra pedido com o segredo compartilhado.
const GATEWAY_SECRET = process.env.CLAUDEX_GATEWAY_SECRET || '';
if (!PASSWORD && !GATEWAY_SECRET) { console.error('Defina PASSWORD (uso solo) ou CLAUDEX_GATEWAY_SECRET (atrás do porteiro)'); process.exit(1); }

// ---- login ----
const sign = (v) => crypto.createHmac('sha256', SECRET).update(v).digest('base64url');
const makeToken = () => { const exp = String(Date.now() + 30 * 864e5); return `${exp}.${sign(exp)}`; };
// Só pra teste local da interface (nunca em produção): pula o login.
const DEV_OPEN = process.env.CLAUDEX_DEV_OPEN === '1';
function authed(req) {
  if (DEV_OPEN) return true;
  if (GATEWAY_SECRET) {
    const got = Buffer.from(String(req.headers['x-claudex-gateway'] || '')), good = Buffer.from(GATEWAY_SECRET);
    return got.length === good.length && crypto.timingSafeEqual(got, good);
  }
  const m = /(?:^|;\s*)claudex=([^;]+)/.exec(req.headers.cookie || '');
  if (!m) return false;
  const [exp, sig] = m[1].split('.');
  if (!exp || !sig || +exp < Date.now()) return false;
  const good = Buffer.from(sign(exp)), got = Buffer.from(sig);
  return good.length === got.length && crypto.timingSafeEqual(good, got);
}
function checkPassword(p) {
  const a = crypto.createHash('sha256').update(String(p)).digest();
  const b = crypto.createHash('sha256').update(PASSWORD).digest();
  return crypto.timingSafeEqual(a, b);
}

// Aberto pelo lançador do CodeFy (Mac/Windows): dá pra trocar a pasta. O servidor sai com código 3,
// o lançador pergunta a pasta nova e sobe de novo na mesma porta/senha (a janela só recarrega).
const LAUNCHER = process.env.CLAUDEX_LAUNCHER === '1';
// Trocar pasta pelo site só quando quem subiu o contêiner fica esperando o código 3 (CodeFy.app); no comando codefy é "codefy pasta".
const PICK = LAUNCHER && process.env.CLAUDEX_PICK !== '0';
const BOOT = crypto.randomBytes(4).toString('hex');
// codefy web (sem contêiner): a pasta aberta é o workspace. Trocar = grava a pasta nova e sai com código 3;
// o comando codefy sobe de novo na mesma porta/senha e a janela recarrega (igual ao "Abrir pasta" do VS Code).
const WS_NEXT = process.env.CODEFY_WS_NEXT || '';
const WS_RECENT = process.env.CODEFY_WS_RECENT || '';
function pickFolder() {
  const [cmd, args] = process.platform === 'darwin' ? ['osascript', ['-e', 'POSIX path of (choose folder with prompt "Escolha a pasta do CodeFy")']]
    : process.platform === 'win32' ? ['powershell', ['-NoProfile', '-STA', '-Command', "Add-Type -AssemblyName System.Windows.Forms; $d = New-Object System.Windows.Forms.FolderBrowserDialog; $d.Description = 'Escolha a pasta do CodeFy'; if ($d.ShowDialog() -eq 'OK') { $d.SelectedPath }"]]
    : ['zenity', ['--file-selection', '--directory', '--title=Escolha a pasta do CodeFy']];
  return new Promise((ok) => {
    let out = '';
    const p = spawn(cmd, args, { stdio: ['ignore', 'pipe', 'ignore'], windowsHide: true });
    p.stdout.on('data', (d) => (out += d));
    p.on('error', () => ok({ error: true }));
    p.on('close', () => ok({ folder: out.trim().replace(/[\\/]+$/, '') || '' }));
  });
}

// ---- http ----
const TYPES = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css', '.svg': 'image/svg+xml', '.png': 'image/png', '.woff2': 'font/woff2' };
const json = (res, code, obj, headers = {}) => { res.writeHead(code, { 'content-type': 'application/json', ...headers }); res.end(obj === undefined ? '' : JSON.stringify(obj)); };
const readBody = (req) => new Promise((ok, fail) => {
  let b = '';
  req.on('data', (d) => { b += d; if (b.length > 2e6) { req.destroy(); fail(new Error('corpo grande demais')); } });
  req.on('end', () => { try { ok(b ? JSON.parse(b) : {}); } catch { fail(new Error('JSON inválido')); } });
});

function serveStatic(req, res) {
  let p = decodeURIComponent(new URL(req.url, 'http://x').pathname);
  if (p === '/') p = '/index.html';
  const file = path.join(WEB, path.normalize(p));
  if (!file.startsWith(WEB)) return json(res, 404, {});
  fs.readFile(file, (err, data) => {
    if (err) return json(res, 404, { error: 'não encontrado' });
    res.writeHead(200, { 'content-type': TYPES[path.extname(file)] || 'application/octet-stream', 'cache-control': 'no-cache' });
    res.end(data);
  });
}

async function api(req, res, url) {
  const p = url.pathname.replace(/^\/api/, '');
  const m = req.method;
  let r;
  if (p === '/event') return agent.subscribe(req, res);
  if (p === '/upload' && m === 'POST') return upload(req, res, url);
  if (p === '/download') return download(req, res, url);
  if (p === '/session' && m === 'GET') return json(res, 200, agent.listSessions());
  if (p === '/session' && m === 'POST') return json(res, 200, agent.createSession(await readBody(req)));
  if (p === '/session/status') return json(res, 200, agent.statuses());
  if ((r = /^\/session\/([\w-]+)$/.exec(p))) {
    if (m === 'PATCH') return json(res, 200, agent.updateSession(r[1], await readBody(req)));
    if (m === 'DELETE') { agent.deleteSession(r[1]); return json(res, 200, true); }
    return json(res, 200, agent.getSession(r[1]).info);
  }
  if ((r = /^\/session\/([\w-]+)\/message$/.exec(p))) return json(res, 200, agent.getSession(r[1]).messages);
  if ((r = /^\/session\/([\w-]+)\/prompt_async$/.exec(p)) && m === 'POST') {
    const body = await readBody(req);
    agent.prompt(r[1], body);
    return json(res, 204);
  }
  if ((r = /^\/session\/([\w-]+)\/abort$/.exec(p)) && m === 'POST') { agent.abort(r[1]); return json(res, 200, true); }
  if ((r = /^\/permission\/([\w-]+)$/.exec(p)) && m === 'POST') { agent.replyPermission(r[1], (await readBody(req)).reply); return json(res, 200, true); }
  if (p === '/prefs') {
    const f = path.join(process.env.HOME, '.claudex', 'prefs.json');
    const cur = (() => { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch { return {}; } })();
    if (m !== 'PUT') return json(res, 200, cur);
    const body = await readBody(req);
    const next = { ...cur };
    if (typeof body.theme === 'string') next.theme = body.theme.slice(0, 32);
    if (['bypass', 'edits', 'ask'].includes(body.approval)) next.approval = body.approval;
    if (['chat', 'terminal'].includes(body.mode)) next.mode = body.mode;
    if (typeof body.welcomed === 'boolean') next.welcomed = body.welcomed;
    if (['site', 'terminal', 'iterm', 'wt', 'cmd', 'linux', 'custom'].includes(body.termApp)) next.termApp = body.termApp;
    if (typeof body.termCmd === 'string') next.termCmd = body.termCmd.slice(0, 400);
    if (body.shortcuts && typeof body.shortcuts === 'object') {
      next.shortcuts = Object.fromEntries(Object.entries(body.shortcuts).filter(([k, v]) => /^\w{1,32}$/.test(k) && typeof v === 'string' && v.length < 64).slice(0, 40));
    }
    fs.mkdirSync(path.dirname(f), { recursive: true });
    fs.writeFileSync(f, JSON.stringify(next));
    return json(res, 200, next);
  }
  // API e token (só no PC, via claudex web): o mesmo ~/.claudex/cli.json do comando claudex.
  if (p === '/config' && agent.CONFIG) {
    const cur = (() => { try { return JSON.parse(fs.readFileSync(agent.CONFIG, 'utf8')); } catch { return {}; } })();
    const tokenOf = (c) => c.token ?? c.key ?? '';
    if (m !== 'PUT') return json(res, 200, { hasToken: !!agent.apiConf().token, platform: process.platform, termApps: term.TERM_APPS[process.platform] || term.TERM_APPS.linux });
    const b = await readBody(req);
    const api = agent.API_BASE; // fixa: o usuário só troca a chave
    const token = typeof b.token === 'string' && b.token.trim() ? b.token.trim() : b.clearToken ? '' : tokenOf(cur);
    if (!token) throw Object.assign(new Error('Cole o seu token.'), { status: 400 });
    // Testa a chave antes de salvar: a lista de modelos abre sem chave, então manda uma mensagem mínima.
    let r;
    try {
      r = await fetch(api + '/chat/completions', {
        method: 'POST', headers: { 'content-type': 'application/json', authorization: `Bearer ${token}` },
        body: JSON.stringify({ model: 'claude-sonnet-5', max_tokens: 1, messages: [{ role: 'user', content: 'oi' }] }), signal: AbortSignal.timeout(150000),
      });
    } catch (e) { throw Object.assign(new Error('Não consegui testar o token agora. Confira a internet e tente de novo.'), { status: 400 }); }
    if (r.status === 401 || r.status === 403) throw Object.assign(new Error('Esse token foi recusado. Confira e cole de novo.'), { status: 400 });
    const models = 0;
    fs.mkdirSync(path.dirname(agent.CONFIG), { recursive: true, mode: 0o700 });
    const { key, ...rest } = cur;
    fs.writeFileSync(agent.CONFIG, JSON.stringify({ ...rest, api, token }, null, 2), { mode: 0o600 });
    return json(res, 200, { ok: true, hasToken: !!token, models });
  }
  if (p === '/workspace' && WS_NEXT) {
    if (m === 'GET') { let recent = []; try { recent = JSON.parse(fs.readFileSync(WS_RECENT, 'utf8')); } catch {} return json(res, 200, { current: agent.WORKDIR, recent: recent.filter((f) => f !== agent.WORKDIR && fs.existsSync(f)) }); }
    const f = path.resolve(String((await readBody(req)).folder || '').trim().replace(/^["']|["']$/g, ''));
    if (!fs.statSync(f, { throwIfNoEntry: false })?.isDirectory()) throw bad(400, 'Pasta não encontrada.');
    if (f === require('os').homedir()) throw bad(400, 'A pasta de usuário inteira não: escolha uma pasta dentro dela.');
    fs.writeFileSync(WS_NEXT, f);
    json(res, 200, { ok: true }); setTimeout(() => process.exit(3), 300); return;
  }
  if (p === '/workspace/pick' && m === 'POST' && WS_NEXT) return json(res, 200, await pickFolder());
  if (p === '/launcher/pick-folder' && m === 'POST' && PICK) { json(res, 200, { ok: true }); setTimeout(() => process.exit(3), 300); return; }
  if (p === '/term' && m === 'GET') return json(res, 200, term.list());
  if (p === '/term' && m === 'POST') {
    const b = await readBody(req);
    if (b.cwd) { const d = inWork(b.cwd); if (!fs.statSync(d, { throwIfNoEntry: false })?.isDirectory()) throw bad(400, 'Pasta não encontrada.'); b.cwd = d; }
    return json(res, 200, term.create(b));
  }
  if (p === '/term/external' && m === 'POST') {
    if (!agent.CONFIG) throw Object.assign(new Error('Só no CodeFy instalado no computador.'), { status: 400 });
    const pref = (() => { try { return JSON.parse(fs.readFileSync(path.join(process.env.HOME, '.claudex', 'prefs.json'), 'utf8')); } catch { return {}; } })();
    term.external(pref);
    return json(res, 200, { ok: true });
  }
  if ((r = /^\/term\/(\w+)$/.exec(p)) && m === 'DELETE') return json(res, 200, term.kill(r[1]));
  if (p === '/file') return json(res, 200, agent.listDir(url.searchParams.get('path') || '.'));
  if (p === '/skills') return json(res, 200, agent.listSkills().map(({ name, description }) => ({ name, description })));
  if (p === '/files/search') return json(res, 200, agent.searchFiles(url.searchParams.get('q') || ''));
  if ((r = /^\/file\/(rename|delete|copy|move|restore)$/.exec(p)) && m === 'POST') return fileOps(req, res, r[1]);
  // Explorer: novo arquivo (vazio) ou nova pasta. Nunca sobrescreve o que já existe.
  if (p === '/file/new' && m === 'POST') {
    const b = await readBody(req);
    const rel = String(b.path || '').replace(/\\/g, '/');
    if (!rel || rel.split('/').some((x) => x === '..')) throw Object.assign(new Error('Nome inválido.'), { status: 400 });
    const f = inWork(rel);
    if (f === agent.WORKDIR) throw Object.assign(new Error('Nome inválido.'), { status: 400 });
    if (fs.existsSync(f)) throw Object.assign(new Error('Já existe um arquivo ou pasta com esse nome.'), { status: 409 });
    const dir = b.type === 'directory';
    fs.mkdirSync(dir ? f : path.dirname(f), { recursive: true });
    if (!dir) fs.writeFileSync(f, '', { flag: 'wx' });
    agent.fileChanged(f);
    return json(res, 200, { ok: true, path: path.relative(agent.WORKDIR, f), absolute: f, type: dir ? 'directory' : 'file' });
  }
  if (p === '/file/content' && m === 'PUT') {
    const b = await readBody(req);
    if (typeof b.content !== 'string') throw Object.assign(new Error('Conteúdo inválido.'), { status: 400 });
    const f = inWork(b.path);
    fs.mkdirSync(path.dirname(f), { recursive: true });
    fs.writeFileSync(f, b.content);
    agent.fileChanged(f);
    return json(res, 200, { ok: true });
  }
  if (p === '/file/content') return json(res, 200, agent.fileContent(url.searchParams.get('path') || ''));
  json(res, 404, { error: 'rota não existe' });
}

http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://x');
  if (url.pathname === '/auth/login' && req.method === 'POST') {
    let pw = '';
    try { pw = (await readBody(req)).password; } catch {}
    if (!checkPassword(pw || '')) return setTimeout(() => json(res, 401, { error: 'Senha incorreta.' }), 600);
    return json(res, 200, { ok: true }, { 'set-cookie': `claudex=${makeToken()}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${30 * 86400}` });
  }
  // "claudex web" abre o navegador com a senha da vez no link: entra direto, sem digitar nada.
  if (url.pathname === '/auth/magic' && PASSWORD) {
    if (!checkPassword(url.searchParams.get('k') || '')) return setTimeout(() => json(res, 401, { error: 'Link vencido. Rode claudex web de novo.' }), 600);
    res.writeHead(302, { location: '/', 'set-cookie': `claudex=${makeToken()}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${30 * 86400}` });
    return res.end();
  }
  if (url.pathname === '/auth/logout') return json(res, 200, { ok: true }, { 'set-cookie': 'claudex=; Path=/; Max-Age=0' });
  if (url.pathname === '/auth/me') return json(res, authed(req) ? 200 : 401, { ok: authed(req), local: true, workdir: agent.WORKDIR, boot: BOOT, launcher: LAUNCHER, pick: PICK, workspaces: !!WS_NEXT, hostFolder: process.env.CLAUDEX_HOST_FOLDER || '' });
  if (url.pathname.startsWith('/api/')) {
    if (!authed(req)) return json(res, 401, { error: 'Entre com a senha.' });
    try { await api(req, res, url); } catch (err) { if (!res.headersSent) json(res, err.status || 500, { error: err.message }); }
    return;
  }
  serveStatic(req, res);
}).on('upgrade', (req, socket) => {
  const m = /^\/api\/term\/(\w+)\/ws$/.exec(new URL(req.url, 'http://x').pathname);
  const origin = req.headers.origin ? new URL(req.headers.origin).host : '';
  if (!m || !authed(req) || (origin && origin !== req.headers.host && !GATEWAY_SECRET)) return socket.end('HTTP/1.1 401 Unauthorized\r\n\r\n');
  term.upgrade(req, socket, m[1]);
}).listen(PORT, process.env.HOST || undefined, () => console.log('claudex em', PORT));

// Lançador do CodeFy (Mac/Windows): fechou a janela, desliga. Sem nenhuma janela conectada por
// CLAUDEX_IDLE_EXIT segundos (2 min de folga na abertura), o servidor sai e o contêiner (--rm) some.
const IDLE = +process.env.CLAUDEX_IDLE_EXIT || 0;
if (IDLE) {
  let lastSeen = Date.now() + 120e3;
  setInterval(() => {
    if (agent.clientCount() + term.clientCount() > 0) lastSeen = Date.now();
    else if (Date.now() - lastSeen > IDLE * 1000) { console.log('nenhuma janela aberta, desligando'); process.exit(0); }
  }, 3000).unref();
}
