# Terminal de verdade (pty) sem dependência nativa no Node: o server.js conversa com este processo.
# stdin -> teclado, stdout -> tela, fd 3 -> controle ("linhas colunas\n" = redimensionar).
import fcntl, os, pty, select, signal, struct, sys, termios

cmd = sys.argv[1:] or ['bash', '-l']
pid, fd = pty.fork()
if pid == 0:
    os.execvp(cmd[0], cmd)

def resize(rows, cols):
    fcntl.ioctl(fd, termios.TIOCSWINSZ, struct.pack('HHHH', rows, cols, 0, 0))
    os.kill(pid, signal.SIGWINCH)

ctl = 3
try: os.fstat(ctl)
except OSError: ctl = None
ins = [0, fd] + ([ctl] if ctl is not None else [])
buf = b''
while True:
    try: r, _, _ = select.select(ins, [], [])
    except InterruptedError: continue
    if fd in r:
        try: data = os.read(fd, 65536)
        except OSError: data = b''
        if not data: break
        os.write(1, data)
    if 0 in r:
        data = os.read(0, 65536)
        if not data: ins.remove(0)
        else: os.write(fd, data)
    if ctl is not None and ctl in r:
        data = os.read(ctl, 4096)
        if not data: ins.remove(ctl); ctl = None; continue
        buf += data
        while b'\n' in buf:
            line, buf = buf.split(b'\n', 1)
            try: rows, cols = map(int, line.split()); resize(max(rows, 2), max(cols, 10))
            except Exception: pass
_, status = os.waitpid(pid, 0)
sys.exit(os.waitstatus_to_exitcode(status) if hasattr(os, 'waitstatus_to_exitcode') else 0)
