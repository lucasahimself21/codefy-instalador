// ---------- Botões Terminal/Chat, janelas avulsas (?view=) e arrastar entre colunas e janelas ----------
// ?view=terminal = só o terminal; ?view=chat = só a conversa. Arrastar conversa, aba de conversa,
// aba de terminal ou arquivo funciona entre janelas do mesmo CodeFy (mesmo endereço).
const VIEW = URLQ.get('view');
if (VIEW === 'terminal' || VIEW === 'chat') {
  document.body.classList.add('v-' + VIEW);
  document.title = VIEW === 'terminal' ? 'CodeFy · Terminal' : 'CodeFy · Chat';
  // Janela avulsa não mexe no estado lembrado da janela principal (painel aberto, altura, aba ativa).
  const set = store.set;
  store.set = (k, v) => (/^term/.test(k) || k === 'groups' ? undefined : set(k, v));
}

function openWindow(view) {
  const w = Math.min(1100, screen.availWidth - 80), h = Math.min(720, screen.availHeight - 80);
  const url = view === 'chat' ? '/?view=chat&new=1' : '/?view=terminal';
  const win = window.open(url, 'claudex-' + view + '-' + Date.now().toString(36), `popup=yes,width=${w},height=${h},left=${screenX + 60},top=${screenY + 40}`);
  if (!win) toast('O navegador bloqueou a janela nova. Libere pop-ups pra este endereço.');
}
// Botões embaixo das conversas: dividem a tela, abrindo terminal ou conversa numa coluna ao lado. As janelas avulsas (?view=) continuam valendo pra quem abrir pelo link.
$('#win-term').addEventListener('click', () => newTermColumn(S.prefs.termApp && S.prefs.termApp !== 'site' ? 'shell' : 'claudex'));
$('#win-chat').addEventListener('click', () => {
  // Terminal em tela cheia esconderia a conversa nova: volta ele pro tamanho de painel.
  if (termPanel.classList.contains('max') && !termPanel.hidden) { termPanel.classList.remove('max'); store.set('termMax', false); }
  newChat('split');
});

// ---- Conversas: arrastar da lista ou da aba pra qualquer coluna (desta ou de outra janela) ----
const CHAT_T = 'application/x-claudex-chat', TAB_T = 'application/x-claudex-tab', TERM_T = 'application/x-claudex-term';
let droppedHere = false;
$('#chat-list').addEventListener('dragstart', (e) => {
  const li = e.target.closest('.chat-item');
  if (!li) return;
  e.dataTransfer.setData(CHAT_T, li.dataset.id);
  e.dataTransfer.setData('text/plain', title(S.sessions.get(li.dataset.id)));
  e.dataTransfer.effectAllowed = 'copyMove';
});
$('#groups').addEventListener('dragstart', (e) => {
  const t = e.target.closest('.tab');
  if (!t) return;
  droppedHere = false;
  e.dataTransfer.setData(CHAT_T, t.dataset.id);
  e.dataTransfer.setData(TAB_T, '1');
  e.dataTransfer.setData('text/plain', title(S.sessions.get(t.dataset.id)));
  e.dataTransfer.effectAllowed = 'move';
});
// Aba solta em outra janela: sai desta.
$('#groups').addEventListener('dragend', (e) => {
  const t = e.target.closest('.tab');
  if (t && e.dataTransfer.dropEffect === 'move' && !droppedHere) closeTab(t.dataset.id);
});
const hasType = (e, t) => [...(e.dataTransfer?.types || [])].includes(t);
$('#groups').addEventListener('dragover', (e) => {
  if (!hasType(e, CHAT_T)) return;
  e.preventDefault();
  e.dataTransfer.dropEffect = hasType(e, TAB_T) ? 'move' : 'copy';
  document.querySelectorAll('.group.drop-in').forEach((g) => g.classList.remove('drop-in'));
  e.target.closest('.group')?.classList.add('drop-in');
});
$('#groups').addEventListener('dragleave', (e) => { if (!e.currentTarget.contains(e.relatedTarget)) document.querySelectorAll('.group.drop-in').forEach((g) => g.classList.remove('drop-in')); });
$('#groups').addEventListener('drop', async (e) => {
  if (!hasType(e, CHAT_T)) return;
  e.preventDefault();
  droppedHere = true;
  document.querySelectorAll('.group.drop-in').forEach((g) => g.classList.remove('drop-in'));
  const sid = e.dataTransfer.getData(CHAT_T);
  const gi = gidx(e);
  if (gi >= 0) focusGroup(gi);
  if (isTermTab(sid)) return openTab(sid);
  if (!S.sessions.has(sid)) await loadSessions().catch(() => {});
  if (S.sessions.has(sid)) openTab(sid);
});
// Deixa as abas e os itens da lista arrastáveis (o HTML deles é redesenhado o tempo todo).
new MutationObserver(() => {
  document.querySelectorAll('.chat-item:not([draggable]), .tab:not([draggable])').forEach((el) => { el.draggable = true; });
}).observe(document.body, { childList: true, subtree: true });

// ---- Terminal: arrastar a aba do terminal pra outra janela (o terminal continua o mesmo) ----
$('#term-tabs').addEventListener('dragstart', (e) => {
  const b = e.target.closest('[data-tid]');
  if (!b) return;
  droppedHere = false;
  e.dataTransfer.setData(TERM_T, b.dataset.tid);
  e.dataTransfer.setData('text/plain', b.textContent.trim());
  e.dataTransfer.effectAllowed = 'move';
});
$('#term-tabs').addEventListener('dragend', (e) => {
  const b = e.target.closest('[data-tid]');
  if (!b || e.dataTransfer.dropEffect !== 'move' || droppedHere) return;
  detachTerm(b.dataset.tid);
});
// Solta o terminal desta janela sem encerrar (outra janela ficou com ele).
function detachTerm(id) {
  const i = T.inst.get(id);
  if (i) { i.closing = true; i.ws?.close(); i.term.dispose(); i.el.remove(); T.inst.delete(id); }
  T.list = T.list.filter((t) => t.id !== id);
  if (T.active === id) T.active = T.list[0]?.id || null;
  if (T.active) activateTerm(T.active);
  else if (VIEW === 'terminal') window.close();
  else { renderTermTabs(); closeTerm(); }
}
// Traz pra esta janela um terminal que está aberto em outra.
async function adoptTerm(id) {
  if (T.list.some((t) => t.id === id)) return activateTerm(id);
  if (!termOpen()) { termPanel.hidden = false; if (!termPanel.style.height) setTermHeight(Math.round(innerHeight * 0.38)); }
  await loadXterm();
  const t = ((await api('/term').catch(() => [])) || []).find((x) => x.id === id);
  if (!t) return toast('Esse terminal já foi encerrado.');
  T.list.push(t);
  activateTerm(id);
}
// Solta na área do terminal ou (janela principal) em qualquer lugar das conversas.
for (const z of [$('#term-panel'), $('#groups')]) {
  z.addEventListener('dragover', (e) => { if (!hasType(e, TERM_T)) return; e.preventDefault(); e.dataTransfer.dropEffect = 'move'; });
  z.addEventListener('drop', (e) => {
    if (!hasType(e, TERM_T)) return;
    e.preventDefault(); e.stopPropagation();
    const id = e.dataTransfer.getData(TERM_T);
    if (T.list.some((t) => t.id === id)) droppedHere = true;
    adoptTerm(id);
  });
}
new MutationObserver(() => { document.querySelectorAll('.term-tab:not([draggable])').forEach((el) => { el.draggable = true; }); })
  .observe($('#term-tabs'), { childList: true });

// ---- Janela só do terminal: abre um CodeFy novo em tela cheia ----
window.viewBoot = async () => {
  if (VIEW !== 'terminal') return false;
  termPanel.hidden = false;
  termPanel.classList.add('max');
  await newTerm(S.prefs.termApp && S.prefs.termApp !== 'site' ? 'shell' : 'claudex');
  return true;
};
