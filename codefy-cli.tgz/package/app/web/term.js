// ---------- Terminal (painel embaixo, igual ao do VS Code) ----------
// Cada aba é um bash (ou o claudex) rodando no espaço do usuário. Fechar o painel não mata nada;
// recarregar a página reconecta nos que estão abertos.
const T = {
  list: [],              // [{ id, kind, title }]
  active: null,
  inst: new Map(),       // id -> { term, fit, ws, el, tries }
  loaded: null,
};
const termPanel = $('#term-panel');

function loadXterm() {
  if (T.loaded) return T.loaded;
  const add = (src) => new Promise((ok, bad) => { const s = document.createElement('script'); s.src = src; s.onload = ok; s.onerror = () => bad(new Error('Não carregou ' + src)); document.head.append(s); });
  T.loaded = add('vendor/xterm.js').then(() => add('vendor/xterm-fit.js')).catch((e) => { T.loaded = null; throw e; });
  return T.loaded;
}
const termThemeObj = () => ({
  background: cssVar('--bg'), foreground: cssVar('--text'), cursor: cssVar('--text'), cursorAccent: cssVar('--bg'),
  selectionBackground: cssVar('--line2') || cssVar('--line'),
});
window.termTheme = () => { for (const i of T.inst.values()) i.term.options.theme = termThemeObj(); };

const termOpen = () => !termPanel.hidden;

// ---------- Terminal numa coluna (tela dividida, como o terminal no editor do VS Code) ----------
window.termTitle = (id) => T.list.find((t) => t.id === id)?.title;
async function newTermColumn(kind = 'claudex', cwd) {
  try { await loadXterm(); } catch (e) { return toast(e.message); }
  let t;
  try { t = await api('/term', { method: 'POST', body: { kind, cwd, cols: 100, rows: 30 } }); } catch (e) { return toast('Não deu pra abrir o terminal: ' + e.message); }
  T.list.push(t);
  const tab = 'term:' + t.id;
  openSplit(tab);
}
// Coloca o terminal dentro da coluna (o mesmo xterm é reaproveitado quando a coluna é redesenhada).
window.mountTermIn = async (box, id) => {
  box.innerHTML = '<div class="term-col"></div>';
  const host = box.firstChild;
  try { await loadXterm(); } catch (e) { host.textContent = e.message; return; }
  if (!T.list.some((t) => t.id === id)) T.list = (await api('/term').catch(() => [])) || [];
  if (!T.list.some((t) => t.id === id)) { setTimeout(() => closeTab('term:' + id), 0); return; } // encerrado enquanto a página estava fechada
  if (!T.inst.has(id)) mountTerm(id);
  const i = T.inst.get(id);
  i.col = true; i.el.hidden = false;
  host.append(i.el);
  i.ro?.disconnect();
  i.ro = new ResizeObserver(() => { try { i.fit.fit(); } catch {} });
  i.ro.observe(host);
  requestAnimationFrame(() => { try { i.fit.fit(); } catch {} i.term.focus(); });
  renderTermTabs();
};
// Fechar a aba da coluna encerra o terminal.
window.termTabClosed = (id) => {
  const i = T.inst.get(id);
  if (i) { i.closing = true; i.ro?.disconnect(); i.ws?.close(); i.term.dispose(); i.el.remove(); T.inst.delete(id); }
  T.list = T.list.filter((t) => t.id !== id);
  api('/term/' + id, { method: 'DELETE' }).catch(() => {});
};
function setTermHeight(h) {
  const max = Math.max(160, $('.main').clientHeight - 120);
  h = Math.min(Math.max(h, 120), max);
  termPanel.style.height = h + 'px';
  store.set('termH', h);
}
async function openTerm(focus = true) {
  termPanel.hidden = false;
  store.set('termOpen', true);
  if (!termPanel.style.height) setTermHeight(store.get('termH', Math.round(innerHeight * 0.38)));
  termPanel.classList.toggle('max', store.get('termMax', false));
  try { await loadXterm(); } catch (e) { return toast(e.message); }
  if (!T.list.length) await refreshTerms();
  if (!T.list.length) await newTerm(S.prefs.mode === 'terminal' ? 'claudex' : 'shell');
  else if (!panelList().length) await newTerm(S.prefs.mode === 'terminal' ? 'claudex' : 'shell');
  else activateTerm(T.active && panelList().some((t) => t.id === T.active) ? T.active : panelList()[0].id, focus);
}
function closeTerm() {
  termPanel.hidden = true;
  store.set('termOpen', false);
  $('.composer textarea', groupEl(S.g))?.focus();
}
const toggleTerm = () => (termOpen() ? closeTerm() : openTerm());

async function refreshTerms() {
  T.list = (await api('/term').catch(() => [])) || [];
  renderTermTabs();
}
// Terminais abertos numa coluna (tela dividida) não aparecem no painel de baixo.
const inColumn = (id) => S.groups.some((g) => g.open.includes('term:' + id));
const panelList = () => T.list.filter((t) => !inColumn(t.id));
function renderTermTabs() {
  $('#term-tabs').innerHTML = panelList().map((t) => `<button type="button" role="tab" class="term-tab${t.id === T.active ? ' active' : ''}" aria-selected="${t.id === T.active}" data-tid="${t.id}">
    ${icon('cmd')}<span>${esc(t.title)}</span><span class="term-x" data-kill="${t.id}" title="Encerrar" aria-label="Encerrar ${esc(t.title)}">${icon('x')}</span></button>`).join('');
}
$('#term-tabs').addEventListener('click', (e) => {
  const k = e.target.closest('[data-kill]');
  if (k) { e.stopPropagation(); return killTerm(k.dataset.kill); }
  const b = e.target.closest('[data-tid]');
  if (b) activateTerm(b.dataset.tid);
});

async function newTerm(kind = 'shell', cwd) {
  if (!termOpen()) { termPanel.hidden = false; store.set('termOpen', true); if (!termPanel.style.height) setTermHeight(store.get('termH', Math.round(innerHeight * 0.38))); }
  try { await loadXterm(); } catch (e) { return toast(e.message); }
  let t;
  try { t = await api('/term', { method: 'POST', body: { kind, cwd, ...termSize() } }); } catch (e) { return toast('Não deu pra abrir o terminal: ' + e.message); }
  T.list.push(t);
  activateTerm(t.id);
}
async function killTerm(id) {
  await api('/term/' + id, { method: 'DELETE' }).catch(() => {});
  dropTerm(id);
}
function dropTerm(id) {
  const i = T.inst.get(id);
  if (i) { i.closing = true; i.ws?.close(); i.term.dispose(); i.el.remove(); T.inst.delete(id); }
  T.list = T.list.filter((t) => t.id !== id);
  if (inColumn(id)) closeTab('term:' + id);
  if (T.active === id) T.active = panelList()[0]?.id || null;
  if (T.active) activateTerm(T.active); else { renderTermTabs(); if (!termPanel.hidden && !panelList().length) closeTerm(); }
}

// Tamanho aproximado antes do xterm existir (o servidor corrige no primeiro "fit").
function termSize() {
  const b = $('#term-body');
  return { cols: Math.max(20, Math.floor((b.clientWidth - 16) / 7.8)), rows: Math.max(5, Math.floor((b.clientHeight - 8) / 17)) };
}

function activateTerm(id, focus = true) {
  T.active = id;
  store.set('termActive', id);
  renderTermTabs();
  if (!T.inst.has(id)) mountTerm(id);
  for (const [tid, i] of T.inst) if (!i.col) i.el.hidden = tid !== id;
  const i = T.inst.get(id);
  requestAnimationFrame(() => { try { i.fit.fit(); } catch {} if (focus) i.term.focus(); });
}

function mountTerm(id) {
  const el = document.createElement('div');
  el.className = 'term-host';
  $('#term-body').append(el);
  const term = new Terminal({
    fontFamily: "'JetBrains Mono', ui-monospace, monospace", fontSize: 13, lineHeight: 1.15, cursorBlink: true,
    scrollback: 5000, allowProposedApi: false, macOptionIsMeta: true, theme: termThemeObj(),
  });
  const fit = new FitAddon.FitAddon();
  term.loadAddon(fit);
  term.open(el);
  const i = { term, fit, el, ws: null, tries: 0, closing: false };
  T.inst.set(id, i);
  // Programas de tela cheia (o claudex) às vezes terminam de carregar sem redesenhar ("Loading plugins…"):
  // enquanto a tela alternativa estiver vazia, balança o tamanho a cada 2 s (até 30 s) pra forçar o desenho.
  const screenText = () => { const b = term.buffer.alternate; let o = ''; for (let k = 0; k < b.length && o.length < 80; k++) o += b.getLine(k)?.translateToString(true).trim() || ''; return o; };
  term.buffer.onBufferChange((b) => {
    if (b.type !== 'alternate' || i.nudge) return;
    let n = 0;
    i.nudge = setInterval(() => {
      if (++n > 15 || term.buffer.active.type !== 'alternate' || screenText().length > 40) { clearInterval(i.nudge); i.nudge = null; return; }
      if (i.ws?.readyState !== 1) return;
      i.ws.send(JSON.stringify({ t: 'r', c: term.cols, r: term.rows - 1 }));
      setTimeout(() => i.ws?.readyState === 1 && i.ws.send(JSON.stringify({ t: 'r', c: term.cols, r: term.rows })), 120);
    }, 2000);
  });
  term.onData((d) => i.ws?.readyState === 1 && i.ws.send(JSON.stringify({ t: 'i', d })));
  term.onResize(({ cols, rows }) => i.ws?.readyState === 1 && i.ws.send(JSON.stringify({ t: 'r', c: cols, r: rows })));
  connectTerm(id);
}
function connectTerm(id) {
  const i = T.inst.get(id);
  if (!i) return;
  const ws = new WebSocket(`${location.protocol === 'https:' ? 'wss' : 'ws'}://${location.host}/api/term/${id}/ws`);
  i.ws = ws;
  let first = true, gotAny = false;
  // Ao (re)conectar, balança o tamanho: programas de tela cheia (claudex, vim) só redesenham quando ele muda.
  const sendSize = (dr = 0) => ws.readyState === 1 && ws.send(JSON.stringify({ t: 'r', c: i.term.cols, r: i.term.rows - dr }));
  ws.onopen = () => { i.tries = 0; try { i.fit.fit(); } catch {} sendSize(1); setTimeout(() => sendSize(), 120); };
  ws.onmessage = (e) => {
    const j = JSON.parse(e.data);
    gotAny = true;
    if (j.t === 'o') { if (first) { i.term.reset(); first = false; } i.term.write(j.d); }
    if (j.t === 'x') { i.closing = true; dropTerm(id); toast('Terminal encerrado.'); }
  };
  ws.onclose = async () => {
    if (i.closing || !T.inst.has(id)) return;
    // Caiu (rede, porteiro reiniciou): tenta de novo; se o terminal não existe mais, some com a aba.
    const alive = ((await api('/term').catch(() => null)) || []).some((t) => t.id === id);
    if (!alive && (gotAny || i.tries > 0)) return dropTerm(id);
    if (i.tries++ < 20) setTimeout(() => connectTerm(id), Math.min(500 * i.tries, 5000));
  };
}

new ResizeObserver(() => {
  if (!termOpen()) return;
  const i = T.inst.get(T.active);
  try { i?.fit.fit(); } catch {}
}).observe($('#term-body'));

// Altura: arrastar a borda de cima
$('#term-resize').addEventListener('pointerdown', (e) => {
  e.preventDefault();
  const y0 = e.clientY, h0 = termPanel.offsetHeight;
  termPanel.classList.remove('max'); store.set('termMax', false);
  document.body.classList.add('resizing-v');
  const move = (ev) => setTermHeight(h0 + (y0 - ev.clientY));
  const up = () => { document.body.classList.remove('resizing-v'); removeEventListener('pointermove', move); removeEventListener('pointerup', up); };
  addEventListener('pointermove', move); addEventListener('pointerup', up);
});
$('#term-max').addEventListener('click', () => { const m = termPanel.classList.toggle('max'); store.set('termMax', m); });
$('#term-close').addEventListener('click', closeTerm);
$('#term-kill').addEventListener('click', () => T.active && killTerm(T.active));
$('#term-btn').addEventListener('click', toggleTerm);
$('#term-menu').addEventListener('click', () => openSide());
$('#term-new').addEventListener('click', (e) => {
  e.stopPropagation();
  const r = e.currentTarget.getBoundingClientRect();
  showCtx([
    { icon: 'cmd', label: 'Terminal (bash)', action: 'newTerm', run: () => newTerm('shell') },
    { icon: 'spark', label: 'CodeFy no terminal', run: () => newTerm('claudex') },
    ...(useExternal() ? ['-', { icon: 'window', label: `CodeFy no ${TERM_APP_NAMES[S.prefs.termApp][0]}`, action: 'newClaudex', run: openExternal }] : []),
  ], r.right - 240, r.bottom + 4);
});

// ---------- Arrastar pro terminal ----------
// Da lateral: cola o caminho. Do computador: envia pra anexos/ e cola o caminho de cada arquivo.
const shq = (p) => (/^[\w@%+=:,./-]+$/.test(p) ? p : `'${p.replace(/'/g, `'\\''`)}'`);
const pasteTerm = (paths) => { const i = T.inst.get(T.active); if (!i || !paths.length) return; i.term.paste(paths.map(shq).join(' ') + ' '); i.term.focus(); };
$('#tree').addEventListener('dragstart', (e) => {
  const row = e.target.closest('.tree-row');
  if (!row) return;
  e.dataTransfer.setData('application/x-claudex-path', row.dataset.abs);
  e.dataTransfer.setData('text/plain', row.dataset.abs);
  e.dataTransfer.effectAllowed = 'copy';
});
const termBody = $('#term-body');
const termDragOk = (e) => { const ty = [...(e.dataTransfer?.types || [])]; return ty.includes('application/x-claudex-path') || ty.includes('Files'); };
let termDrag = 0;
termBody.addEventListener('dragenter', (e) => { if (!termDragOk(e)) return; e.preventDefault(); termDrag++; $('#term-drop').hidden = false; });
termBody.addEventListener('dragover', (e) => { if (!termDragOk(e)) return; e.preventDefault(); e.dataTransfer.dropEffect = 'copy'; });
termBody.addEventListener('dragleave', (e) => { if (!termDragOk(e)) return; if (--termDrag <= 0) { termDrag = 0; $('#term-drop').hidden = true; } });
termBody.addEventListener('drop', async (e) => {
  if (!termDragOk(e)) return;
  e.preventDefault(); e.stopPropagation();
  termDrag = 0; $('#term-drop').hidden = true;
  const p = e.dataTransfer.getData('application/x-claudex-path');
  if (p) return pasteTerm([p]);
  const entries = [...e.dataTransfer.items].map((it) => it.webkitGetAsEntry?.()).filter(Boolean);
  const items = [];
  if (entries.length) for (const en of entries) await readEntries(en, '', items);
  else [...e.dataTransfer.files].forEach((f) => items.push({ file: f, rel: f.name }));
  // Pasta arrastada: cola só o caminho da pasta, não de cada arquivo dentro dela.
  const sent = await uploadItems(items, 'anexos');
  if (!sent) return;
  const tops = [...new Set(sent.map((r) => r.split('/').slice(0, 2).join('/')))];
  pasteTerm(tops.map((r) => S.workdir + '/' + r));
});

// ---------- Atalhos ----------
Object.assign(ACTIONS, {
  toggleTerm: { name: 'Abrir ou fechar o terminal', def: 'Ctrl+Backquote', term: true, run: toggleTerm },
  newTerm: { name: 'Novo terminal', def: 'Ctrl+Shift+Backquote', term: true, run: () => newTerm('shell') },
  newClaudex: { name: 'CodeFy no terminal', def: 'Alt+KeyK', run: () => (useExternal() ? openExternal() : newTerm('claudex')) },
});

// ---------- Configurações › Terminal ----------
// Sem usuário = rodando no PC da pessoa (claudex web): não tem "instalar no computador", já está nele.
const isLocal = () => !S.user;
const inApp = () => !!window.claudexApp; // aberto pelo app CodeFy (Mac/Windows)
const pcCmd = () => isLocal() ? `cd pasta-do-projeto\ncodefy           # terminal\ncodefy web       # este site` : `npm i -g ${location.origin}/cli/codefy-cli.tgz\ncodefy login     # endereço: ${location.origin}\ncodefy           # dentro da pasta do projeto`;
function renderTermSettings(c) {
  const mode = S.prefs.mode || 'chat';
  c.innerHTML = `<h3>Terminal</h3><p class="lead">O CodeFy funciona no chat do site ou num terminal de verdade, com o mesmo agente e os mesmos arquivos.</p>
    <div class="modes" role="radiogroup" aria-label="Jeito padrão">${[
      { id: 'chat', name: 'Chat no site', note: 'Abre nas conversas. O terminal fica no botão da lateral (⌃`).' },
      { id: 'terminal', name: 'Terminal', note: 'Abre direto no CodeFy do terminal, em tela cheia.' },
    ].map((m) => `<button type="button" class="mode-card" role="radio" aria-checked="${m.id === mode}" data-tmode="${m.id}">
      ${icon(m.id === 'chat' ? 'chat-plus' : 'cmd')}<span><span class="n">${m.name}</span><span class="d">${m.note}</span></span>${icon('check').replace('class="i"', 'class="i ok"')}</button>`).join('')}</div>
    ${isLocal() ? '<h4>Abrir o CodeFy em</h4><div id="term-app"></div>' : ''}
    ${isLocal() && inApp() ? '' : `<h4>${isLocal() ? 'Direto no terminal do computador' : 'No seu computador'}</h4>
    <p class="lead">${isLocal() ? 'Em qualquer pasta, sem abrir o site:' : 'Instale uma vez e rode <code>codefy</code> dentro de qualquer pasta. Entra com o mesmo usuário e senha daqui.'}</p>
    <pre class="cmd-box">${esc(pcCmd())}</pre>
    <div class="set-foot"><button type="button" class="btn-flat" id="copy-pc">Copiar comandos</button></div>`}`;
  c.querySelectorAll('[data-tmode]').forEach((b) => b.addEventListener('click', () => { savePrefs({ mode: b.dataset.tmode }); renderSettings(); }));
  if (isLocal() && T.cfg) paintTermApp(c);
  $('#copy-pc')?.addEventListener('click', () => navigator.clipboard.writeText(pcCmd().replace(/ +#.*$/gm, '')).then(() => toast('Comandos copiados.'), () => toast('Não deu pra copiar.')));
}

// ---------- No PC: terminal da própria pessoa + API/token ----------
const TERM_APP_NAMES = {
  site: ['Terminal do site', 'O painel aqui embaixo.'],
  terminal: ['Terminal do Mac', 'Abre uma janela nova do Terminal já no CodeFy.'],
  iterm: ['iTerm', 'Abre uma janela nova do iTerm já no CodeFy.'],
  wt: ['Windows Terminal', 'Abre uma aba do Windows Terminal já no CodeFy.'],
  cmd: ['Prompt de comando', 'Abre o cmd já no CodeFy.'],
  linux: ['Terminal do sistema', 'O terminal padrão do Linux.'],
  custom: ['Outro terminal', 'Qualquer app: escreva o comando que abre ele.'],
};
const CUSTOM_EX = { darwin: 'open -na WezTerm --args start --cwd {dir} -- {cmd}', win32: 'start "" alacritty --working-directory {dir} -e {cmd}', linux: 'kitty --directory {dir} {cmd}' };
const useExternal = () => isLocal() && S.prefs.termApp && S.prefs.termApp !== 'site';
// No app, quem abre o terminal da pessoa é o próprio app (o CodeFy pode estar num contêiner).
const HOST_APPS = { darwin: ['terminal', 'iterm', 'custom'], win32: ['wt', 'cmd', 'custom'], linux: ['linux', 'custom'] };
const hostPlatform = () => (inApp() ? window.claudexApp.platform : T.cfg?.platform);
async function openExternal() {
  try {
    if (inApp()) { const r = await window.claudexApp.openTerminal({ termApp: S.prefs.termApp, termCmd: S.prefs.termCmd }); if (r?.error) throw new Error(r.error); }
    else await api('/term/external', { method: 'POST' });
    toast(`Abrindo o CodeFy no ${TERM_APP_NAMES[S.prefs.termApp]?.[0] || 'seu terminal'}…`); }
  catch (e) { toast(e.message); }
}
function paintTermApp(c) {
  const box = $('#term-app', c);
  const cur = S.prefs.termApp || 'site';
  box.innerHTML = `<div class="modes" role="radiogroup" aria-label="Abrir o CodeFy em">${['site', ...(inApp() ? HOST_APPS[hostPlatform()] || HOST_APPS.linux : T.cfg.termApps)].map((id) => `<button type="button" class="mode-card" role="radio" aria-checked="${id === cur}" data-tapp="${id}">
      ${icon(id === 'site' ? 'window' : id === 'custom' ? 'pencil' : 'cmd')}<span><span class="n">${TERM_APP_NAMES[id][0]}</span><span class="d">${TERM_APP_NAMES[id][1]}</span></span>${icon('check').replace('class="i"', 'class="i ok"')}</button>`).join('')}</div>
    ${cur === 'custom' ? `<label class="field term-cmd"><span>Comando ({dir} = pasta, {cmd} = CodeFy)</span><input id="term-cmd" spellcheck="false" autocomplete="off" placeholder="${esc(CUSTOM_EX[hostPlatform()] || CUSTOM_EX.linux)}" value="${esc(S.prefs.termCmd || '')}"></label>` : ''}
    ${cur !== 'site' ? '<div class="set-foot"><button type="button" class="btn-flat" id="term-test">Abrir agora pra testar</button></div>' : ''}`;
  box.querySelectorAll('[data-tapp]').forEach((b) => b.addEventListener('click', () => { savePrefs({ termApp: b.dataset.tapp }); paintTermApp(c); }));
  $('#term-cmd', box)?.addEventListener('change', (e) => savePrefs({ termCmd: e.target.value }));
  $('#term-test', box)?.addEventListener('click', async () => { const i = $('#term-cmd', box); if (i) await savePrefs({ termCmd: i.value }); openExternal(); });
}
function renderApiSettings(c) {
  const cfg = T.cfg || {};
  c.innerHTML = `<h3>Chave</h3><p class="lead">Cole a sua chave do CodeFy: vale na hora, pro site e pro comando <code>codefy</code>.</p>
    <form class="pw-form" id="api-form">
      <label class="field"><span>Chave ${cfg.hasToken ? '(configurada; deixe vazio pra manter)' : ''}</span><input name="token" type="password" ${cfg.hasToken ? '' : 'required'} autocomplete="off" spellcheck="false" placeholder="${cfg.hasToken ? '••••••••' : 'cole a chave'}"></label>
      <p class="form-err" id="api-err" role="alert"></p>
      <button class="btn-primary" type="submit">Testar e salvar</button>
    </form>`;
  $('#api-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const f = e.currentTarget, btn = $('button[type=submit]', f);
    $('#api-err').textContent = ''; btn.disabled = true; btn.textContent = 'Testando (até 2 min)…';
    try {
      const r = await api('/config', { method: 'PUT', body: { token: f.token.value } });
      Object.assign(T.cfg, { hasToken: r.hasToken });
      toast('Chave salva.');
      renderApiSettings(c);
    } catch (err) { $('#api-err').textContent = err.message; btn.disabled = false; btn.textContent = 'Testar e salvar'; }
  });
}

// ---------- Boas-vindas (primeira vez) e início ----------
$('#welcome').addEventListener('click', (e) => {
  const b = e.target.closest('[data-wl]');
  if (!b) return;
  savePrefs({ mode: b.dataset.wl, welcomed: true });
  $('#welcome').close();
  if (b.dataset.wl === 'terminal') { if (useExternal()) openExternal(); else { store.set('termMax', true); openTerm(); } }
});
$('#welcome').addEventListener('cancel', () => savePrefs({ welcomed: true }));

window.termBoot = async () => {
  if (isLocal()) { T.cfg = await api('/config').catch(() => null); $('#nav-api').hidden = !T.cfg; }
  if (typeof VIEW !== 'undefined' && VIEW) { if (isLocal()) T.cfg = await api('/config').catch(() => null); return window.viewBoot(); }
  if (!S.prefs.welcomed) {
    $('#wl-cmd').textContent = pcCmd();
    if ((isLocal() && inApp()) || S.launcher) $('#welcome .wl-pc').hidden = true; // no instalador não há codefy no computador
    if (isLocal() || S.launcher) {
      const pasta = (S.launcher && S.hostFolder) || S.workdir;
      $('#welcome .lead').textContent = `O CodeFy está aberto na pasta ${pasta.split(/[\\/]/).pop() || pasta}. Use do jeito que preferir:`;
      $('#welcome .wl-pc b').textContent = 'Sem abrir o site';
      $('#welcome .wl-pc small').textContent = 'No terminal do computador, dentro da pasta do projeto:';
    }
    return $('#welcome').showModal();
  }
  T.active = store.get('termActive', null);
  if (S.prefs.mode === 'terminal') { store.set('termMax', true); return openTerm(); }
  if (store.get('termOpen', false)) openTerm(false);
};
