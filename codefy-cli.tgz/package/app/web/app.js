'use strict';

// ---------- Modelos ----------
const PROVIDER = 'codefy';
const MODELS = [
  { id: 'claude-opus-5-5', name: 'Opus 5.5', group: 'Claude', note: 'O mais forte, pra tarefa pesada', color: 'var(--m-opus)' },
  { id: 'claude-sonnet-5', name: 'Sonnet 5', group: 'Claude', note: 'Rápido pro dia a dia', color: 'var(--m-sonnet)' },
  { id: 'claude-fable-5.1', name: 'Fable 5.1', group: 'Claude', note: 'Anthropic', color: 'var(--m-fable)' },
  { id: 'gpt-6-astra', name: 'GPT-6 Astra', group: 'OpenAI', note: '1M de contexto', color: 'var(--m-gpt)' },
  { id: 'z-ai/glm-5.3', name: 'GLM 5.3', group: 'Outros', note: 'Z.ai, 1M de contexto', color: 'var(--m-glm)' },
];
const DEFAULT_MODEL = 'claude-fable-5.1';
const modelOf = (id) => MODELS.find((m) => m.id === id) || { id, name: id || 'Modelo', color: 'var(--faint)' };

const isMac = /Mac|iPhone|iPad/.test(navigator.platform);
// ⌘W é do navegador e não dá pra bloquear: com conversa aberta, ele pergunta antes de fechar a página.
window.addEventListener('beforeunload', (e) => { if (!S.leaving && S.groups?.some((g) => g.open.length) || dirty?.()) { e.preventDefault(); e.returnValue = ''; } });

// ---------- Estado ----------
const store = {
  get(k, d) { try { const v = localStorage.getItem('claudex.' + k); return v ? JSON.parse(v) : d; } catch { return d; } },
  set(k, v) { try { localStorage.setItem('claudex.' + k, JSON.stringify(v)); } catch {} },
};
// Abas abertas são por janela (sessionStorage); a última janela usada vira o padrão de uma janela nova.
const win = {
  get(k, d) { try { const v = sessionStorage.getItem('claudex.' + k); return v ? JSON.parse(v) : d; } catch { return d; } },
  set(k, v) { try { sessionStorage.setItem('claudex.' + k, JSON.stringify(v)); } catch {} },
};
const URLQ = new URLSearchParams(location.search);
if (URLQ.has('chat') || URLQ.has('new')) history.replaceState(null, '', location.pathname);
const S = {
  workdir: '',
  sessions: new Map(),           // id -> info
  groups: [],                    // colunas lado a lado: [{ open: [ids], active: id }]
  g: 0,                          // coluna com foco
  prefs: { theme: 'padrao', approval: 'edits', shortcuts: {} },
  selecting: false,
  selected: new Set(),
  lastSel: null,
  msgs: new Map(),               // sid -> Map(mid -> { info, parts: Map(pid -> part) })
  loaded: new Set(),
  status: new Map(),             // sid -> { type: idle|busy|retry, ... }
  errors: new Map(),             // sid -> texto do último erro da sessão
  models: store.get('models', {}), // sid -> modelID
  drafts: new Map(),
  tree: new Map(),               // dir -> [nodes]
  expanded: new Set(store.get('expanded', [''])),
  filePath: null,
};

function loadGroups() {
  if (URLQ.has('chat')) return [{ open: [URLQ.get('chat')], active: URLQ.get('chat') }];
  if (URLQ.has('new')) return [{ open: [], active: null }];
  const g = win.get('groups', store.get('groups', null));
  if (Array.isArray(g) && g.length) return g.map((x) => ({ open: Array.isArray(x.open) ? x.open : [], active: x.active || null }));
  const open = store.get('open', []);
  return [{ open, active: store.get('active', open[0] || null) }];
}
S.groups = loadGroups();
// S.open / S.active = a coluna com foco (o resto do código continua falando só da coluna atual).
Object.defineProperties(S, {
  open: { get() { return S.groups[S.g].open; }, set(v) { S.groups[S.g].open = v; } },
  active: { get() { return S.groups[S.g].active; }, set(v) { S.groups[S.g].active = v; } },
});
const MAX_GROUPS = 4;
const groupIndexOf = (sid) => S.groups.findIndex((g) => g.open.includes(sid));
const isOpen = (sid) => groupIndexOf(sid) >= 0;
const shownIn = (sid) => S.groups.findIndex((g) => g.active === sid);
const groupEl = (gi) => document.querySelector(`.group[data-g="${gi}"]`);
const viewOf = (sid) => { const gi = shownIn(sid); return gi < 0 ? null : groupEl(gi); };
// Aba de terminal numa coluna (tela dividida): id "term:<id do terminal>". O term.js cuida do conteúdo.
const isTermTab = (id) => typeof id === 'string' && id.startsWith('term:');
function pruneGroups() {
  for (const g of S.groups) { g.open = g.open.filter((id) => isTermTab(id) || S.sessions.size === 0 || S.sessions.has(id)); if (!g.open.includes(g.active)) g.active = g.open[0] || null; }
  const before = S.groups.length;
  S.groups = S.groups.filter((g, i) => g.open.length || (i === 0 && S.groups.every((x) => !x.open.length)));
  if (!S.groups.length) S.groups = [{ open: [], active: null }];
  S.g = Math.min(S.g, S.groups.length - 1);
  return S.groups.length !== before;
}
function focusGroup(gi) {
  if (gi === S.g || gi < 0 || gi >= S.groups.length) return;
  S.g = gi;
  document.querySelectorAll('.group').forEach((el) => el.classList.toggle('focused', +el.dataset.g === gi));
  renderChats(); saveTabs();
}

const $ = (s, el = document) => el.querySelector(s);
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const icon = (n) => `<svg class="i"><use href="#i-${n}"/></svg>`;
const rel = (p) => (p && S.workdir && p.startsWith(S.workdir + '/') ? p.slice(S.workdir.length + 1) : p || '');
const saveTabs = () => { win.set('groups', S.groups); store.set('groups', S.groups); };

marked.setOptions({ gfm: true, breaks: true });
const md = (t) => DOMPurify.sanitize(marked.parse(t || ''), { ADD_ATTR: ['target'] });

// ---------- API ----------
async function api(path, opts = {}) {
  const r = await fetch('/api' + path, {
    method: opts.method || 'GET',
    headers: opts.body ? { 'content-type': 'application/json' } : {},
    body: opts.body ? JSON.stringify(opts.body) : undefined,
  });
  if (r.status === 401) { showLogin(); throw new Error('login'); }
  if (!r.ok) throw new Error((await r.json().catch(() => ({}))).error || `Erro ${r.status}`);
  return r.status === 204 ? null : r.json().catch(() => null);
}

// ---------- Login ----------
function showLogin(local = S.localAuth) {
  $('#app').hidden = true; $('#login').hidden = false;
  // No computador (codefy web) não tem usuário e senha: entra pelo link que o comando abre.
  if (local) { $('#login-form').innerHTML = '<h1 class="wordmark">CodeFy</h1><p class="login-sub">Essa aba perdeu o acesso. No terminal, rode <code>codefy web</code> de novo: ele abre o CodeFy já logado.</p>'; return; }
  ($('#login-user').value ? $('#login-pass') : $('#login-user')).focus();
}
$('#login-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  $('#login-err').textContent = '';
  const r = await fetch('/auth/login', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ username: $('#login-user').value.trim().toLowerCase(), password: $('#login-pass').value }) });
  if (!r.ok) { $('#login-err').textContent = (await r.json().catch(() => ({}))).error || 'Não deu pra entrar.'; return; }
  $('#login-pass').value = '';
  boot();
});

// ---------- Sessões ----------
const isTop = (s) => !s.parentID;
const title = (s) => (!s || !s.title || /^New session/i.test(s.title) ? 'Nova conversa' : s.title);
const sessionModel = (sid) => S.models[sid] || S.sessions.get(sid)?.model?.id || DEFAULT_MODEL;
const busy = (sid) => ['busy', 'retry', 'waiting'].includes(S.status.get(sid)?.type);

function ago(ts) {
  const d = (Date.now() - ts) / 1000;
  if (d < 60) return 'agora';
  if (d < 3600) return `${Math.floor(d / 60)} min`;
  if (d < 86400) return `${Math.floor(d / 3600)} h`;
  if (d < 86400 * 7) return `${Math.floor(d / 86400)} d`;
  return new Date(ts).toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' });
}

async function loadSessions() {
  const list = await api('/session');
  S.sessions.clear();
  for (const s of list || []) S.sessions.set(s.id, s);
  const st = await api('/session/status').catch(() => ({}));
  for (const [id, v] of Object.entries(st || {})) S.status.set(id, v);
  pruneGroups();
  saveTabs();
}

async function newChat(beside) {
  const model = S.active ? sessionModel(S.active) : DEFAULT_MODEL;
  const s = await api('/session', { method: 'POST', body: { approval: S.prefs.approval || 'edits', model } });
  S.sessions.set(s.id, s);
  S.loaded.add(s.id);
  S.msgs.set(s.id, new Map());
  S.models[s.id] = model;
  store.set('models', S.models);
  beside === 'split' ? openSplit(s.id) : beside && S.open.length ? openBeside(s.id) : openTab(s.id);
  closeSide();
  setTimeout(() => $('.composer textarea', groupEl(S.g))?.focus(), 0);
}

function openTab(sid) {
  const gi = groupIndexOf(sid);
  if (gi >= 0 && gi !== S.g) focusGroup(gi);
  if (!S.open.includes(sid)) S.open.push(sid);
  S.active = sid;
  saveTabs();
  renderTabs(); renderChats(); renderChat(S.g);
}
function closeTab(sid) {
  const gi = groupIndexOf(sid);
  if (gi < 0) return;
  if (isTermTab(sid)) window.termTabClosed?.(sid.slice(5));
  const g = S.groups[gi], i = g.open.indexOf(sid);
  g.open.splice(i, 1);
  if (g.active === sid) g.active = g.open[Math.min(i, g.open.length - 1)] || null;
  if (pruneGroups()) { saveTabs(); return renderAll(); }
  saveTabs();
  renderTabs(); renderChats(); renderChat(gi);
}
// Divide a tela: abre numa coluna NOVA à direita (até MAX_GROUPS); com a coluna atual vazia, abre nela.
function openSplit(id) {
  if (!S.open.length) return openTab(id);
  if (S.groups.length >= MAX_GROUPS) return openBeside(id);
  S.groups.push({ open: [id], active: id });
  S.g = S.groups.length - 1;
  saveTabs();
  renderAll();
}
// Abre a conversa numa coluna ao lado (cria a coluna se couber).
function openBeside(sid) {
  const src = groupIndexOf(sid);
  const from = src >= 0 ? src : S.g;
  let target = from + 1;
  if (target >= S.groups.length) {
    if (S.groups.length < MAX_GROUPS) S.groups.push({ open: [], active: null });
    else target = from - 1;
  }
  if (src >= 0) {
    const g = S.groups[src];
    if (g.open.length === 1 && S.groups.length === 1) { S.groups.push({ open: [], active: null }); target = 1; }
    g.open = g.open.filter((x) => x !== sid);
    if (g.active === sid) g.active = g.open[0] || null;
  }
  const t = S.groups[target];
  t.open.push(sid); t.active = sid;
  S.g = target;
  pruneGroups();
  S.g = groupIndexOf(sid);
  saveTabs();
  renderAll();
}
async function deleteChat(sid) {
  const ok = await confirmDialog('Apagar conversa?', `"${title(S.sessions.get(sid))}" some da lista e não dá pra desfazer.`);
  if (ok) await deleteMany([sid]);
}
async function deleteMany(ids) {
  for (const sid of ids) {
    await api('/session/' + sid, { method: 'DELETE' }).catch(() => {});
    S.sessions.delete(sid);
    S.selected.delete(sid);
    for (const g of S.groups) { const i = g.open.indexOf(sid); if (i >= 0) { g.open.splice(i, 1); if (g.active === sid) g.active = g.open[Math.min(i, g.open.length - 1)] || null; } }
  }
  pruneGroups();
  saveTabs();
  renderAll();
  toast(ids.length === 1 ? 'Conversa apagada.' : `${ids.length} conversas apagadas.`);
}
function startRename(sid) {
  const li = $(`.chat-item[data-id="${sid}"]`);
  if (!li) return;
  const inp = document.createElement('input');
  inp.value = title(S.sessions.get(sid));
  li.replaceChildren(inp);
  inp.focus(); inp.select();
  let done = false;
  const finish = (save) => { if (done) return; done = true; save ? renameChat(sid, inp.value) : renderChats(); };
  inp.addEventListener('keydown', (ev) => { if (ev.key === 'Enter') finish(true); if (ev.key === 'Escape') finish(false); });
  inp.addEventListener('blur', () => finish(true));
}
async function renameChat(sid, name) {
  name = name.trim();
  if (!name) return;
  const s = await api('/session/' + sid, { method: 'PATCH', body: { title: name } });
  if (s) S.sessions.set(sid, s);
  renderChats(); renderTabs();
}

// ---------- Lateral: conversas ----------
function renderChats() {
  const ul = $('#chat-list');
  const list = [...S.sessions.values()].filter(isTop).sort((a, b) => b.time.updated - a.time.updated);
  if (!list.length) { ul.innerHTML = '<li class="side-empty">Nenhuma conversa ainda.</li>'; return; }
  $('#sec-chats').classList.toggle('selecting', S.selecting);
  ul.innerHTML = list.map((s) => {
    const open = isOpen(s.id);
    const m = modelOf(sessionModel(s.id));
    const sel = S.selected.has(s.id);
    const mark = `<span class="box" data-act="check" role="checkbox" aria-checked="${sel}" aria-label="Selecionar">${icon('check')}</span>`
      + `<span class="dot${open ? '' : ' hollow'}${busy(s.id) ? ' busy' : ''}" style="--mc:${m.color}"></span>`;
    return `<li class="chat-item${open ? ' is-open' : ''}${s.id === S.active ? ' active' : ''}${sel ? ' sel' : ''}${busy(s.id) ? ' busy' : ''}" data-id="${s.id}">
      <button class="open-chat" type="button" title="${esc(title(s))}">
        ${mark}
        <span class="title">${esc(title(s))}</span><span class="when">${ago(s.time.updated)}</span>
      </button>
      <span class="acts">
        <button class="icon-btn" type="button" data-act="rename" aria-label="Renomear">${icon('pencil')}</button>
        <button class="icon-btn danger" type="button" data-act="delete" aria-label="Apagar">${icon('trash')}</button>
      </span></li>`;
  }).join('');
}
$('#chat-list').addEventListener('click', (e) => {
  const li = e.target.closest('.chat-item');
  if (!li || e.target.closest('input')) return;
  const sid = li.dataset.id;
  const act = e.target.closest('[data-act]')?.dataset.act;
  if (act === 'check' || (S.selected.size && (e.shiftKey || e.metaKey || e.ctrlKey))) return toggleSelect(sid, e.shiftKey);
  if (act === 'delete') return deleteChat(sid);
  if (act === 'rename') return startRename(sid);
  openTab(sid);
  closeSide();
});
$('#chat-list').addEventListener('contextmenu', (e) => {
  const li = e.target.closest('.chat-item');
  if (!li) return;
  e.preventDefault();
  chatMenu(li.dataset.id, e.clientX, e.clientY);
});

// ---------- Colunas e abas ----------
function renderAll() {
  const box = $('#groups');
  box.innerHTML = S.groups.map((g, gi) => `<section class="group${gi === S.g ? ' focused' : ''}" data-g="${gi}">
    <nav class="tabs-bar">${gi === 0 ? `<button class="icon-btn menu-btn" type="button" aria-label="Abrir lateral">${icon('menu')}</button>` : ''}<div class="tabs" role="tablist"></div>
      <span class="tb-acts"><button class="icon-btn" type="button" data-tb="split" title="Abrir ao lado" aria-label="Abrir a aba ao lado">${icon('split')}</button><button class="icon-btn" type="button" data-tb="more" title="Mais ações" aria-label="Mais ações">${icon('dots')}</button></span></nav>
    <div class="chat-head"><span class="ch-title"></span>
      <button class="icon-btn" type="button" data-ch="history" title="Conversas" aria-label="Abrir outra conversa aqui">${icon('clock')}</button>
      <button class="icon-btn" type="button" data-ch="new" title="Nova conversa" aria-label="Nova conversa nesta coluna">${icon('chat-plus')}</button></div>
    <div class="chat"></div></section>`).join('');
  box.dataset.n = S.groups.length;
  renderTabs();
  S.groups.forEach((_, gi) => renderChat(gi));
  renderChats();
}
function renderTabs() {
  S.groups.forEach((g, gi) => {
    const el = groupEl(gi);
    if (!el) return;
    $('.tabs', el).innerHTML = g.open.map((sid) => {
      if (isTermTab(sid)) return `<div class="tab term${sid === g.active ? ' active' : ''}" role="tab" aria-selected="${sid === g.active}" data-id="${sid}">
        ${icon('cmd')}<button class="t" type="button">${esc(window.termTitle?.(sid.slice(5)) || 'terminal')}</button>
        <button class="x" type="button" aria-label="Fechar terminal">${icon('x')}</button></div>`;
      const s = S.sessions.get(sid);
      const m = modelOf(sessionModel(sid));
      return `<div class="tab${sid === g.active ? ' active' : ''}" role="tab" aria-selected="${sid === g.active}" data-id="${sid}" style="--mc:${m.color}">
        <span class="dot${busy(sid) ? ' busy' : ''}" style="--mc:${m.color}"></span>
        <button class="t" type="button">${esc(title(s))}</button>
        <button class="x" type="button" aria-label="Fechar aba">${icon('x')}</button></div>`;
    }).join('');
    $('.tab.active', el)?.scrollIntoView({ block: 'nearest', inline: 'nearest' });
    $('.chat-head', el).hidden = !g.active;
    $('.ch-title', el).textContent = !g.active ? '' : isTermTab(g.active) ? 'Terminal · ' + (window.termTitle?.(g.active.slice(5)) || '') : title(S.sessions.get(g.active));
  });
}
const gidx = (e) => { const g = e.target.closest('.group'); return g ? +g.dataset.g : -1; };
$('#groups').addEventListener('pointerdown', (e) => focusGroup(gidx(e)));
$('#groups').addEventListener('focusin', (e) => focusGroup(gidx(e)));
$('#groups').addEventListener('click', (e) => {
  if (e.target.closest('.menu-btn')) return openSide();
  const tb = e.target.closest('[data-tb]');
  if (tb) {
    focusGroup(gidx(e));
    if (tb.dataset.tb === 'split') return S.active ? openBeside(S.active) : newChat(true);
    const r = tb.getBoundingClientRect(), g = S.groups[S.g];
    return showCtx([
      { icon: 'split', label: 'Abrir ao lado', run: () => S.active && openBeside(S.active), action: 'split' },
      { icon: 'plus', label: 'Nova conversa ao lado', run: () => newChat(true), action: 'newBeside' },
      '-',
      { icon: 'x', label: 'Fechar aba', run: () => S.active && closeTab(S.active), action: 'closeTab' },
      { icon: 'x', label: 'Fechar as outras', run: () => { g.open.filter((x) => x !== g.active).forEach((x) => closeTab(x)); } },
      { icon: 'x', label: 'Fechar todas desta coluna', run: () => { [...g.open].forEach((x) => closeTab(x)); } },
    ], r.right - 230, r.bottom + 4);
  }
  const ch = e.target.closest('[data-ch]');
  if (ch) {
    focusGroup(gidx(e));
    if (ch.dataset.ch === 'new') return newChat();
    const r = ch.getBoundingClientRect();
    const list = [...S.sessions.values()].filter(isTop).sort((a, b) => b.time.updated - a.time.updated).slice(0, 14);
    return showCtx(list.length ? list.map((s) => ({ icon: 'clock', label: title(s), run: () => openTab(s.id) })) : [{ icon: 'clock', label: 'Nenhuma conversa ainda', run: () => {} }], r.left - 180, r.bottom + 4);
  }
  const tab = e.target.closest('.tab');
  if (!tab) return;
  focusGroup(gidx(e));
  if (e.target.closest('.x')) return closeTab(tab.dataset.id);
  openTab(tab.dataset.id);
});
$('#groups').addEventListener('auxclick', (e) => { const t = e.target.closest('.tab'); if (t && e.button === 1) closeTab(t.dataset.id); });
$('#groups').addEventListener('contextmenu', (e) => {
  const t = e.target.closest('.tab');
  if (!t) return;
  e.preventDefault();
  if (isTermTab(t.dataset.id)) return showCtx([
    { icon: 'split', label: 'Abrir ao lado', run: () => openBeside(t.dataset.id) },
    { icon: 'x', label: 'Encerrar terminal', run: () => closeTab(t.dataset.id) },
  ], e.clientX, e.clientY);
  chatMenu(t.dataset.id, e.clientX, e.clientY);
});

// ---------- Chat ----------
async function loadMessages(sid) {
  const list = await api(`/session/${sid}/message`);
  const map = new Map();
  for (const m of list || []) map.set(m.info.id, { info: m.info, parts: new Map(m.parts.map((p) => [p.id, p])) });
  S.msgs.set(sid, map);
  S.loaded.add(sid);
}

function renderChat(gi = S.g) {
  const root = groupEl(gi);
  if (!root) return;
  const box = $('.chat', root);
  const sid = S.groups[gi].active;
  if (isTermTab(sid)) return window.mountTermIn?.(box, sid.slice(5));
  if (!sid) {
    box.innerHTML = `<div class="empty"><h2>Nenhuma conversa aberta</h2>
      <p>Abra uma conversa na lateral ou comece uma nova. As conversas fechadas continuam guardadas lá.</p>
      <button class="btn-primary" type="button" id="empty-new">Nova conversa</button></div>`;
    $('#empty-new', box).onclick = () => newChat();
    return;
  }
  const m = modelOf(sessionModel(sid));
  box.innerHTML = `<div class="chat-view" style="--mc:${m.color}">
    <div class="scroll"><div class="msgs"></div></div>
    <div class="composer-wrap"></div></div>`;
  const wrap = $('.composer-wrap', box);
  wrap.append($('#tpl-composer').content.cloneNode(true));
  setupComposer(sid, box);
  if (!S.loaded.has(sid)) {
    $('.msgs', box).innerHTML = '<p class="side-empty">Carregando…</p>';
    loadMessages(sid).then(() => paintMessages(sid, true)).catch((err) => {
      if (/não encontrada/i.test(err.message)) return closeTab(sid); // aba lembrada de uma conversa que já não existe
      const v = viewOf(sid);
      if (v) $('.msgs', v).innerHTML = `<div class="note-err"><b>Não deu pra carregar a conversa.</b> ${esc(err.message)}</div>`;
    });
  } else paintMessages(sid, true);
}

function paintMessages(sid, toBottom) {
  const root = viewOf(sid);
  const box = root && $('.msgs', root);
  if (!box) return;
  const list = [...(S.msgs.get(sid)?.values() || [])].sort((a, b) => a.info.time.created - b.info.time.created);
  if (!list.length) {
    box.innerHTML = `<div class="empty" style="padding:8vh 0 0"><h2>O que vamos fazer?</h2>
      <p>O CodeFy lê, cria e edita os arquivos da lateral. Peça uma página, um texto, uma correção, e escolha o modelo aqui embaixo.</p></div>`;
  } else {
    box.innerHTML = list.map((m) => msgHTML(m)).join('');
  }
  const err = S.errors.get(sid);
  if (err) box.insertAdjacentHTML('beforeend', `<div class="note-err"><b>A conversa parou.</b> ${esc(err)}</div>`);
  box.insertAdjacentHTML('beforeend', '<div class="working" hidden><span class="spin"></span><span class="w-t">Trabalhando…</span></div>');
  if (toBottom) scrollBottom(root, true);
  updateComposer(sid);
}

function msgHTML(m) {
  const parts = [...m.parts.values()].sort((a, b) => (a.id < b.id ? -1 : 1));
  if (m.info.role === 'user') {
    const text = parts.filter((p) => p.type === 'text' && !p.synthetic).map((p) => p.text).join('\n');
    return `<div class="msg-user" data-mid="${m.info.id}">${esc(text)}</div>`;
  }
  const mo = modelOf(m.info.modelID);
  const body = parts.map(partHTML).join('');
  const e = m.info.error;
  const errMsg = e && e.name !== 'MessageAbortedError' ? `<div class="tl-item k-err"><div class="note-err"><b>Erro do modelo.</b> ${esc(e.data?.message || e.name)}</div></div>` : '';
  const stopped = e?.name === 'MessageAbortedError' ? '<div class="tl-item k-think"><span class="tl-dim">Parado por você.</span></div>' : '';
  const t = m.info.time;
  const secs = t?.completed ? Math.max(1, Math.round((t.completed - t.created) / 1000)) : 0;
  const meta = secs ? `<div class="msg-meta"><span class="dot"></span>${esc(mo.name)} · ${secs < 60 ? secs + 's' : Math.floor(secs / 60) + 'min ' + (secs % 60) + 's'}</div>` : '';
  return `<div class="msg-ai" data-mid="${m.info.id}" style="--mc:${mo.color}">${body}${errMsg}${stopped}${meta}</div>`;
}

const TOOL_VERB = { write: 'Criou', edit: 'Editou', multiedit: 'Editou', patch: 'Editou', apply_patch: 'Editou', read: 'Leu', bash: 'Rodou', glob: 'Procurou', grep: 'Procurou em', list: 'Listou', ls: 'Listou', webfetch: 'Abriu', todowrite: 'Atualizou tarefas', todoread: 'Leu tarefas', task: 'Subtarefa' };
const TOOL_VERB_NOW = { write: 'Criando', edit: 'Editando', multiedit: 'Editando', read: 'Lendo', bash: 'Rodando', glob: 'Procurando', grep: 'Procurando em', list: 'Listando', webfetch: 'Abrindo' };

function partHTML(p) {
  if (p.type === 'text') return p.text ? `<div class="tl-item k-text" data-pid="${p.id}"><div class="md">${md(p.text)}</div></div>` : '';
  if (p.type === 'reasoning') {
    if (!p.text?.trim()) return '';
    return `<details class="tl-item k-think think" data-pid="${p.id}"><summary>Pensou</summary><div class="md">${md(p.text)}</div></details>`;
  }
  if (p.type === 'tool') return toolHTML(p);
  return '';
}

const TOOL_ASK = { write: 'Quer criar', edit: 'Quer editar', bash: 'Quer rodar' };
function askHTML(p) {
  const inp = p.state.input || {};
  const target = inp.filePath ? rel(inp.filePath) : inp.command || '';
  let preview = '';
  if (p.tool === 'edit') preview = (inp.oldString || '').split('\n').map((l) => '- ' + l).join('\n') + '\n' + (inp.newString || '').split('\n').map((l) => '+ ' + l).join('\n');
  else if (p.tool === 'write') preview = (inp.content || '').slice(0, 4000);
  else if (p.tool === 'bash') preview = inp.command || '';
  const id = esc(p.state.awaiting);
  return `<div class="tl-item k-ask ask-card" data-pid="${p.id}">
    <div class="ask-head">${icon('shield')}<span><b>${esc(TOOL_ASK[p.tool] || 'Quer usar ' + p.tool)}</b> ${esc(target)}</span></div>
    ${preview ? `<pre>${esc(preview)}</pre>` : ''}
    <div class="ask-acts">
      <button type="button" class="yes" data-perm="${id}" data-reply="once">Permitir</button>
      <button type="button" class="always" data-perm="${id}" data-reply="always">Sempre nesta conversa</button>
      <button type="button" class="no" data-perm="${id}" data-reply="reject">Negar</button>
    </div></div>`;
}

function toolHTML(p) {
  const st = p.state || {};
  if (st.awaiting && st.status === 'pending') return askHTML(p);
  const inp = st.input || {};
  const file = inp.filePath || inp.path || '';
  const done = st.status === 'completed', err = st.status === 'error';
  const denied = err && /^Negado/.test(st.error || '');
  const verb = denied ? ({ write: 'Criar', edit: 'Editar', bash: 'Rodar' }[p.tool] || p.tool)
    : done || err ? (TOOL_VERB[p.tool] || p.tool) : (TOOL_VERB_NOW[p.tool] || TOOL_VERB[p.tool] || p.tool);
  let target = '';
  if (file && ['write', 'edit', 'multiedit', 'read'].includes(p.tool)) target = `<span class="target file" data-open="${esc(file)}">${esc(rel(file))}</span>`;
  else if (inp.command) target = `<span class="target">${esc(inp.command)}</span>`;
  else if (inp.pattern) target = `<span class="target">${esc(inp.pattern)}</span>`;
  else if (inp.url) target = `<span class="target">${esc(inp.url)}</span>`;
  else if (st.title) target = `<span class="target">${esc(st.title)}</span>`;

  let status = '';
  if (denied) status = '<span class="st">negado</span>';
  else if (err) status = '<span class="st">falhou</span>';
  else if (!done) status = '<span class="running" aria-label="rodando"></span>';
  else if (p.tool === 'edit' && inp.oldString != null) {
    const a = (inp.newString || '').split('\n').length, r = (inp.oldString || '').split('\n').length;
    status = `<span class="st">+${a} −${r}</span>`;
  } else if (p.tool === 'write' && inp.content) status = `<span class="st">${inp.content.split('\n').length} linhas</span>`;

  // Caixa IN/OUT como no Claude Code
  let inTxt = inp.command || (file ? rel(file) : '') || inp.pattern || inp.url || '';
  let outHTML = '';
  if (p.tool === 'edit' && inp.oldString != null) {
    outHTML = '<pre class="diff">' + (inp.oldString || '').split('\n').map((l) => `<span class="del">- ${esc(l)}</span>`).join('\n') + '\n'
      + (inp.newString || '').split('\n').map((l) => `<span class="add">+ ${esc(l)}</span>`).join('\n') + '</pre>';
  } else if (p.tool === 'write' && inp.content) outHTML = `<pre>${esc(inp.content.slice(0, 6000))}</pre>`;
  else if (err) outHTML = `<pre>${esc(st.error || '')}</pre>`;
  else if (st.output) outHTML = `<pre>${esc(String(st.output).slice(0, 6000))}</pre>`;
  const io = inTxt || outHTML ? `<div class="io">${inTxt ? `<div class="io-r"><span class="io-k">IN</span><pre>${esc(inTxt)}</pre></div>` : ''}${outHTML ? `<div class="io-r"><span class="io-k">OUT</span>${outHTML}</div>` : ''}</div>` : '';
  const diffBtn = done && st.diff ? `<button type="button" class="diff-btn" data-diff="${p.id}" data-sid="${esc(p.sessionID)}">Ver diff</button>` : '';
  const name = { bash: 'Bash', read: 'Read', write: 'Write', edit: 'Edit', list: 'List' }[p.tool] || p.tool;
  const tgt = file && ['write', 'edit', 'read'].includes(p.tool) ? `<span class="tl-tgt file" data-open="${esc(file)}">${esc(rel(file))}</span>` : '';
  return `<div class="tl-item k-tool${err ? ' err' : ''}${!done && !err ? ' run' : ''}" data-pid="${p.id}">
    <div class="tl-h"><b>${esc(name)}</b>${tgt}${!done ? `<span class="tl-dim">${esc(denied ? 'negado' : err ? 'falhou' : verb + '…')}</span>` : ''}${done ? status : err ? '' : status}${diffBtn}</div>${io}</div>`;
}

// Atualiza só o necessário durante o streaming.
const pending = new Map(); // sid -> Set(mid)
let raf = 0;
function schedule(sid, mid) {
  if (shownIn(sid) < 0) return;
  if (!pending.has(sid)) pending.set(sid, new Set());
  pending.get(sid).add(mid);
  if (!raf) raf = setTimeout(flush, 30);
}
function flush() {
  raf = 0;
  for (const [sid, mids] of pending) {
    const root = viewOf(sid), box = root && $('.msgs', root);
    if (!box) continue;
    const near = nearBottom(root);
    const map = S.msgs.get(sid);
    let repainted = false;
    for (const mid of mids) {
      const m = map?.get(mid);
      if (!m) continue;
      const el = box.querySelector(`[data-mid="${mid}"]`);
      if (!el) { paintMessages(sid, near); repainted = true; break; }
      const open = new Set([...el.querySelectorAll('details[open]')].map((d) => d.dataset.pid));
      const tmp = document.createElement('div');
      tmp.innerHTML = msgHTML(m);
      const fresh = tmp.firstElementChild;
      fresh.querySelectorAll('details').forEach((d) => { if (open.has(d.dataset.pid)) d.open = true; });
      el.replaceWith(fresh);
    }
    if (!repainted && near) scrollBottom(root);
  }
  pending.clear();
}
const nearBottom = (root) => { const s = root && $('.scroll', root); return !s || s.scrollHeight - s.scrollTop - s.clientHeight < 120; };
function scrollBottom(root, force) { const s = root && $('.scroll', root); if (s && (force || nearBottom(root))) s.scrollTop = s.scrollHeight; }

$('#groups').addEventListener('click', (e) => {
  const f = e.target.closest('[data-open]');
  if (f) { e.preventDefault(); openFile(f.dataset.open); }
  const dv = e.target.closest('[data-diff]');
  if (dv) {
    e.preventDefault(); e.stopPropagation();
    for (const m of S.msgs.get(dv.dataset.sid)?.values() || []) { const part = m.parts.get(dv.dataset.diff); if (part) { openAgentDiff(part); break; } }
  }
  const b = e.target.closest('[data-perm]');
  if (b) {
    b.closest('.ask-acts').querySelectorAll('button').forEach((x) => { x.disabled = true; });
    api('/permission/' + b.dataset.perm, { method: 'POST', body: { reply: b.dataset.reply } }).catch((err) => toast(err.message));
  }
});

// ---------- Composer ----------
function setupComposer(sid, root) {
  const form = $('.composer', root);
  const ta = $('textarea', form);
  const btn = $('.send-btn', form);
  ta.value = S.drafts.get(sid) || '';
  const grow = () => { ta.style.height = 'auto'; ta.style.height = ta.scrollHeight + 'px'; };
  grow();
  const sug = attachSuggest(ta, form, sid);
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  const mic = $('.mic-btn', form);
  if (SR && mic) {
    mic.hidden = false;
    let rec = null;
    mic.addEventListener('click', () => {
      if (rec) return rec.stop();
      rec = new SR(); rec.lang = 'pt-BR'; rec.interimResults = true; rec.continuous = true;
      const base = ta.value ? ta.value.replace(/\s*$/, ' ') : '';
      rec.onresult = (e) => { ta.value = base + [...e.results].map((r) => r[0].transcript).join(''); ta.dispatchEvent(new Event('input')); };
      rec.onend = () => { rec = null; mic.classList.remove('rec'); ta.focus(); };
      rec.onerror = (e) => { if (e.error === 'not-allowed') toast('O navegador bloqueou o microfone.'); };
      mic.classList.add('rec');
      rec.start();
    });
  }
  $('.slash-btn', form).addEventListener('click', () => { if (!ta.value.startsWith('/')) ta.value = '/' + ta.value; ta.focus(); ta.setSelectionRange(1, 1); ta.dispatchEvent(new Event('input')); });
  const ai = $('.attach-input', form);
  $('.attach-btn', form).addEventListener('click', () => { ai.value = ''; ai.click(); });
  ai.addEventListener('change', async () => {
    const files = [...ai.files];
    if (!files.length) return;
    await uploadItems(files.map((f) => ({ file: f, rel: 'anexos/' + f.name })), '');
    const add = files.map((f) => '@anexos/' + f.name).join(' ');
    ta.value = (ta.value ? ta.value.replace(/\s*$/, ' ') : '') + add + ' ';
    ta.dispatchEvent(new Event('input')); ta.focus();
  });
  ta.addEventListener('input', () => { S.drafts.set(sid, ta.value); grow(); updateComposer(sid); sug.update(); });
  // Ctrl+V com imagem (print, imagem copiada): salva em anexos/ e menciona, igual ao botão de anexar.
  ta.addEventListener('paste', async (e) => {
    const imgs = [...(e.clipboardData?.files || [])].filter((f) => f.type.startsWith('image/'));
    if (!imgs.length) return;
    e.preventDefault();
    const stamp = new Date().toISOString().replace(/\D/g, '').slice(0, 14);
    const items = imgs.map((f, i) => ({ file: f, rel: `anexos/colado-${stamp}${imgs.length > 1 ? '-' + (i + 1) : ''}.${(f.type.split('/')[1] || 'png').replace('jpeg', 'jpg')}` }));
    await uploadItems(items, '');
    const add = items.map((x) => '@' + x.rel).join(' ');
    const at = ta.selectionStart, before = ta.value.slice(0, at), after = ta.value.slice(ta.selectionEnd);
    ta.value = before + (before && !/\s$/.test(before) ? ' ' : '') + add + ' ' + after;
    ta.dispatchEvent(new Event('input')); ta.focus();
  });
  ta.addEventListener('click', () => sug.update());
  ta.addEventListener('keydown', (e) => {
    if (sug.key(e)) return;
    if (e.key === 'Escape') { e.preventDefault(); ta.blur(); return; }
    if (e.key === 'Tab' && e.shiftKey) { e.preventDefault(); form.cycleMode?.(); return; }
    if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) { e.preventDefault(); form.requestSubmit(); }
  });
  form.addEventListener('submit', (e) => {
    e.preventDefault();
    if (busy(sid)) return abort(sid);
    send(sid, ta.value);
  });
  btn.disabled = false;
  setupModelMenu(sid, form);
  setupModeMenu(sid, form);
  updateComposer(sid);
}

const CTX_MAX = 1000000;
function ctxTokens(sid) {
  let n = 0;
  for (const m of S.msgs.get(sid)?.values() || []) for (const p of m.parts.values()) {
    n += (p.text || '').length;
    if (p.type === 'tool') n += JSON.stringify(p.state?.input || {}).length + String(p.state?.output || '').length;
  }
  return Math.round(n / 3.6) + 1800; // + instruções do sistema
}
const fmtK = (n) => (n / 1000).toFixed(1) + 'k';
function updateComposer(sid) {
  const root = viewOf(sid);
  const form = root && $('.composer', root);
  if (!form) return;
  const ta = $('textarea', form), btn = $('.send-btn', form), note = $('.status-note', form);
  const b = busy(sid);
  btn.classList.toggle('stop', b);
  btn.innerHTML = icon(b ? 'stop' : 'up');
  btn.setAttribute('aria-label', b ? 'Parar' : 'Enviar');
  btn.disabled = !b && !ta.value.trim();
  const st = S.status.get(sid);
  note.textContent = st?.type === 'retry' ? `Tentando de novo (tentativa ${st.attempt}): ${st.message}` : st?.type === 'waiting' ? 'Esperando sua aprovação' : '';
  const tk = ctxTokens(sid), pct = Math.min(100, (tk / CTX_MAX) * 100);
  const ctx = $('.ctxm', form);
  if (ctx) {
    $('.ctx-t', ctx).textContent = `Ctx ${Math.round(pct)}% (${fmtK(tk)}/${fmtK(CTX_MAX)})`;
    const c = 2 * Math.PI * 6;
    $('.r-fg', ctx).style.strokeDasharray = `${(pct / 100) * c} ${c}`;
    ctx.classList.toggle('warn', pct > 70);
  }
  const s0 = S.sessions.get(sid);
  const at = $('.age-t', form);
  if (at && s0) { const mins = Math.max(0, Math.floor((Date.now() - s0.time.created) / 60000)); at.textContent = mins < 60 ? `${mins}m` : mins < 1440 ? `${Math.floor(mins / 60)}h` : `${Math.floor(mins / 1440)}d`; }
  const wk = $('.working', root);
  if (wk) { wk.hidden = !b || st?.type === 'waiting'; $('.w-t', wk).textContent = st?.type === 'retry' ? 'Tentando de novo…' : 'Trabalhando…'; wk.parentElement.append(wk); }
}

async function send(sid, text) {
  text = text.trim();
  if (!text) return;
  S.drafts.delete(sid);
  S.errors.delete(sid);
  const ta = $('.composer textarea', viewOf(sid)) || document.createElement('textarea');
  ta.value = ''; ta.style.height = 'auto';
  S.status.set(sid, { type: 'busy' });
  renderTabs(); renderChats(); updateComposer(sid);
  try {
    await api(`/session/${sid}/prompt_async`, { method: 'POST', body: { model: { providerID: PROVIDER, modelID: sessionModel(sid) }, parts: [{ type: 'text', text }] } });
  } catch (err) {
    S.status.set(sid, { type: 'idle' });
    S.errors.set(sid, 'A mensagem não foi enviada: ' + err.message);
    ta.value = text; S.drafts.set(sid, text);
    paintMessages(sid, true); renderTabs(); renderChats();
  }
}
const abort = (sid) => api(`/session/${sid}/abort`, { method: 'POST' }).catch(() => {});

// ---------- "/" skills e comandos, "@" arquivos e pastas ----------
const COMMANDS = [
  { name: 'nova', description: 'Começa uma conversa nova', run: () => newChat() },
  { name: 'ao-lado', description: 'Abre uma conversa nova ao lado', run: () => newChat(true) },
  { name: 'modelo', description: 'Troca o modelo desta conversa', run: (form) => $('.model-btn', form).click() },
  { name: 'aprovacao', description: 'Muda o modo de aprovação', run: (form) => $('.mode-btn', form).click() },
  { name: 'config', description: 'Abre as configurações', run: () => openSettings() },
  { name: 'atalhos', description: 'Mostra e muda os atalhos', run: () => openSettings('atalhos') },
];
let skillsCache = null, skillsAt = 0;
async function getSkills() {
  if (!skillsCache || Date.now() - skillsAt > 30000) { skillsCache = await api('/skills').catch(() => []); skillsAt = Date.now(); }
  return skillsCache;
}
function attachSuggest(ta, form, sid) {
  const box = document.createElement('div');
  box.className = 'suggest'; box.hidden = true; box.setAttribute('role', 'listbox');
  form.prepend(box);
  let items = [], idx = 0, trig = null, seq = 0, timer = 0;
  const close = () => { box.hidden = true; items = []; trig = null; };
  const paint = () => {
    if (!items.length) {
      box.innerHTML = `<div class="sug-empty">${trig?.kind === '@' ? 'Nenhum arquivo com esse nome.' : 'Nenhum comando, agente ou skill com esse nome. Crie em .codefy/agentes e .codefy/skills da pasta.'}</div>`;
      box.hidden = false; return;
    }
    box.innerHTML = `<div class="sug-head">${trig.kind === '@' ? 'Arquivos e pastas' : 'Comandos, agentes e skills'}</div>` + items.map((it, i) => `<button type="button" class="sug${i === idx ? ' on' : ''}" data-i="${i}" role="option" aria-selected="${i === idx}">
      ${icon(it.icon)}<span class="sug-n">${esc(it.label)}</span>${it.desc ? `<span class="sug-d">${esc(it.desc)}</span>` : ''}</button>`).join('');
    box.hidden = false;
    box.querySelector('.sug.on')?.scrollIntoView({ block: 'nearest' });
  };
  const pick = (i) => {
    const it = items[i];
    if (!it || !trig) return;
    const v = ta.value, before = v.slice(0, trig.start), after = v.slice(ta.selectionStart);
    if (it.command) { ta.value = before + after.replace(/^\S*\s?/, ''); close(); S.drafts.set(sid, ta.value); ta.dispatchEvent(new Event('input')); return it.command.run(form); }
    const ins = it.insert + (it.insert.endsWith('/') ? '' : ' ');
    ta.value = before + ins + after;
    const pos = (before + ins).length;
    ta.setSelectionRange(pos, pos);
    close();
    ta.dispatchEvent(new Event('input'));
    ta.focus();
    if (it.insert.endsWith('/')) update();
  };
  async function update() {
    const upto = ta.value.slice(0, ta.selectionStart);
    let m = /(^|\s)@([^\s@]*)$/.exec(upto);
    if (m) trig = { kind: '@', q: m[2], start: upto.length - m[2].length - 1 };
    else if ((m = /^\/([\w.-]*)$/.exec(upto))) trig = { kind: '/', q: m[1], start: 0 };
    else return close();
    const my = ++seq;
    clearTimeout(timer);
    timer = setTimeout(async () => {
      let list;
      if (trig.kind === '@') {
        const r = await api('/files/search?q=' + encodeURIComponent(trig.q)).catch(() => []);
        list = r.map((f) => ({ icon: f.type === 'directory' ? 'folder' : 'file', label: f.path, insert: '@' + f.path }));
      } else {
        const q = trig.q.toLowerCase();
        const sk = (await getSkills()).filter((s) => s.name.toLowerCase().includes(q)).map((s) => ({ icon: 'spark', label: '/' + s.name, desc: s.description, insert: '/' + s.name }));
        const cm = COMMANDS.filter((c) => c.name.includes(q)).map((c) => ({ icon: 'cmd', label: '/' + c.name, desc: c.description, command: c }));
        list = [...sk, ...cm];
      }
      if (my !== seq || !trig) return;
      items = list; idx = 0; paint();
    }, trig.kind === '@' ? 90 : 0);
  }
  box.addEventListener('mousedown', (e) => { const b = e.target.closest('.sug'); if (b) { e.preventDefault(); pick(+b.dataset.i); } });
  ta.addEventListener('blur', () => setTimeout(close, 120));
  return {
    update,
    key(e) {
      if (box.hidden || !trig) return false;
      if (e.key === 'ArrowDown') { e.preventDefault(); idx = (idx + 1) % Math.max(items.length, 1); paint(); return true; }
      if (e.key === 'ArrowUp') { e.preventDefault(); idx = (idx - 1 + items.length) % Math.max(items.length, 1); paint(); return true; }
      if ((e.key === 'Enter' || e.key === 'Tab') && items.length) { e.preventDefault(); pick(idx); return true; }
      if (e.key === 'Escape') { e.preventDefault(); close(); return true; }
      return false;
    },
  };
}

const MODES = [
  { id: 'edits', name: 'Editar sozinho', note: 'Cria e edita arquivos sem perguntar. Pede antes de rodar comando. É o padrão (recomendado).' },
  { id: 'ask', name: 'Perguntar antes', note: 'Pede aprovação antes de criar, editar ou rodar qualquer coisa. Ler é livre.' },
  { id: 'bypass', name: 'Tudo liberado (Bypass)', note: 'Faz tudo sem perguntar, inclusive rodar comandos. Por sua conta e risco.' },
];
const modeOf = (sid) => S.sessions.get(sid)?.approval || S.prefs.approval || 'edits';
// Bypass só depois de a pessoa confirmar que o risco é dela.
const okBypass = (mode, cur) => mode !== 'bypass' || cur === 'bypass' || confirmDialog('Usar o modo Bypass?',
  'O CodeFy vai rodar comandos sem te perguntar: instalar programas, apagar arquivos, mandar dados pra internet. Se algo der errado, é por sua conta e risco.', 'Usar Bypass');
function setupModeMenu(sid, form) {
  const btn = $('.mode-btn', form), menu = $('.mode-menu', form);
  const paint = () => {
    const m = MODES.find((x) => x.id === modeOf(sid)) || MODES[0];
    btn.dataset.mode = m.id;
    $('.mode-name', btn).textContent = m.name;
    btn.title = `Modo de aprovação: ${m.name} (Shift+Tab troca)`;
  };
  paint();
  menu.innerHTML = MODES.map((m) => `<button type="button" class="opt-row" role="option" data-mode="${m.id}">${icon('shield')}
    <span><span class="n">${m.name}</span><span class="d">${m.note}</span></span><span class="check"></span></button>`).join('');
  const toggle = (show) => {
    menu.hidden = !show;
    btn.setAttribute('aria-expanded', show);
    if (show) {
      menu.querySelectorAll('.opt-row').forEach((o) => { const on = o.dataset.mode === modeOf(sid); o.setAttribute('aria-selected', on); $('.check', o).textContent = on ? '✓' : ''; });
      (menu.querySelector('[aria-selected="true"]') || menu.querySelector('.opt-row')).focus();
    }
  };
  btn.addEventListener('click', () => toggle(menu.hidden));
  menu.addEventListener('click', async (e) => {
    const o = e.target.closest('.opt-row');
    if (!o) return;
    toggle(false);
    setMode(o.dataset.mode);
  });
  // Shift+Tab no campo de mensagem: próximo modo (igual ao terminal).
  const setMode = async (mode) => {
    if (!(await okBypass(mode, modeOf(sid)))) return $('textarea', form).focus();
    const s = await api('/session/' + sid, { method: 'PATCH', body: { approval: mode } }).catch((err) => { toast(err.message); return null; });
    if (s) S.sessions.set(sid, s);
    paint();
    $('textarea', form).focus();
  };
  form.cycleMode = () => setMode(MODES[(MODES.findIndex((x) => x.id === modeOf(sid)) + 1) % MODES.length].id);
  menu.addEventListener('keydown', (e) => {
    const opts = [...menu.querySelectorAll('.opt-row')];
    const i = opts.indexOf(document.activeElement);
    if (e.key === 'ArrowDown') { e.preventDefault(); opts[(i + 1) % opts.length].focus(); }
    if (e.key === 'ArrowUp') { e.preventDefault(); opts[(i - 1 + opts.length) % opts.length].focus(); }
    if (e.key === 'Escape') { toggle(false); btn.focus(); }
  });
  document.addEventListener('click', (e) => { if (!menu.hidden && !e.target.closest('.mode-wrap')) toggle(false); });
}

function setupModelMenu(sid, form) {
  const btn = $('.model-btn', form), menu = $('.model-menu', form);
  const paint = () => {
    const m = modelOf(sessionModel(sid));
    $('.model-name', btn).textContent = m.name;
    $('.dot', btn).style.setProperty('--mc', m.color);
  };
  paint();
  const groups = [...new Set(MODELS.map((m) => m.group))];
  menu.innerHTML = groups.map((g) => `<div class="model-group">${g}</div>` + MODELS.filter((m) => m.group === g).map((m) =>
    `<button type="button" class="model-opt" role="option" data-id="${m.id}"><span class="dot" style="--mc:${m.color}"></span>
      <span><span class="n">${m.name}</span><span class="d">${m.note}</span></span><span class="check"></span></button>`).join('')).join('');
  const toggle = (show) => {
    menu.hidden = !show;
    btn.setAttribute('aria-expanded', show);
    if (show) {
      menu.querySelectorAll('.model-opt').forEach((o) => {
        const on = o.dataset.id === sessionModel(sid);
        o.setAttribute('aria-selected', on);
        $('.check', o).textContent = on ? '✓' : '';
      });
      (menu.querySelector('[aria-selected="true"]') || menu.querySelector('.model-opt')).focus();
    }
  };
  btn.addEventListener('click', () => toggle(menu.hidden));
  menu.addEventListener('click', (e) => {
    const o = e.target.closest('.model-opt');
    if (!o) return;
    S.models[sid] = o.dataset.id;
    store.set('models', S.models);
    api('/session/' + sid, { method: 'PATCH', body: { model: o.dataset.id } }).then((s) => s && S.sessions.set(sid, s)).catch(() => {});
    toggle(false); paint();
    form.closest('.chat-view')?.style.setProperty('--mc', modelOf(o.dataset.id).color);
    renderTabs(); renderChats();
    $('textarea', form).focus();
  });
  menu.addEventListener('keydown', (e) => {
    const opts = [...menu.querySelectorAll('.model-opt')];
    const i = opts.indexOf(document.activeElement);
    if (e.key === 'ArrowDown') { e.preventDefault(); opts[(i + 1) % opts.length].focus(); }
    if (e.key === 'ArrowUp') { e.preventDefault(); opts[(i - 1 + opts.length) % opts.length].focus(); }
    if (e.key === 'Escape') { toggle(false); btn.focus(); }
  });
  document.addEventListener('click', (e) => { if (!menu.hidden && !e.target.closest('.model-wrap')) toggle(false); });
}

// ---------- Arquivos ----------
async function loadDir(dir) {
  const list = await api('/file?path=' + encodeURIComponent(dir || '.'));
  const nodes = (list || []).filter((n) => !n.ignored && n.name !== '.git')
    .sort((a, b) => (a.type === b.type ? a.name.localeCompare(b.name) : a.type === 'directory' ? -1 : 1));
  S.tree.set(dir, nodes);
  return nodes;
}
function treeHTML(dir) {
  const nodes = S.tree.get(dir);
  if (!nodes) return '';
  if (!nodes.length && dir === '') return '<li class="side-empty">Pasta vazia. Peça pro CodeFy criar algo.</li>';
  return nodes.map((n) => {
    const isDir = n.type === 'directory';
    const open = isDir && S.expanded.has(n.path);
    return `<li role="treeitem"${isDir ? ` aria-expanded="${open}"` : ''}>
      <button type="button" draggable="true" class="tree-row${isDir ? ' dir' : ''}${n.absolute === S.filePath ? ' active' : ''}" data-path="${esc(n.path)}" data-abs="${esc(n.absolute)}" data-dir="${isDir}">
        <span class="tw${isDir ? (open ? ' open' : '') : ' none'}" draggable="false">${isDir ? icon('chev') : ''}</span>${icon(isDir ? 'folder' : 'file')}<span class="tn">${esc(n.name)}</span></button>
      ${open ? `<ul role="group">${treeHTML(n.path)}</ul>` : ''}</li>`;
  }).join('');
}
const renderTree = () => { $('#tree').innerHTML = treeHTML(''); };
async function refreshTree() {
  const dirs = ['', ...[...S.expanded].filter(Boolean)];
  await Promise.all(dirs.map((d) => loadDir(d).catch(() => S.expanded.delete(d))));
  renderTree();
}
$('#tree').addEventListener('click', async (e) => {
  const row = e.target.closest('.tree-row');
  if (!row) return;
  const p = row.dataset.path;
  if (row.dataset.dir === 'true') {
    if (S.expanded.has(p)) S.expanded.delete(p);
    else { S.expanded.add(p); if (!S.tree.has(p)) await loadDir(p).catch(() => {}); }
    store.set('expanded', [...S.expanded]);
    renderTree();
  } else { openFile(row.dataset.abs); closeSide(); }
});
$('#tree-refresh').addEventListener('click', refreshTree);

// ---------- Enviar e baixar arquivos ----------
const parentOf = (p) => (p.includes('/') ? p.slice(0, p.lastIndexOf('/')) : '');
function downloadPath(p) {
  const a = document.createElement('a');
  a.href = '/api/download?path=' + encodeURIComponent(p || '.');
  a.rel = 'noopener';
  document.body.append(a); a.click(); a.remove();
}
function sendOne(item, dir, onProgress) {
  return new Promise((ok, bad) => {
    const x = new XMLHttpRequest();
    x.open('POST', `/api/upload?path=${encodeURIComponent(dir || '.')}&name=${encodeURIComponent(item.rel)}`);
    x.upload.onprogress = (e) => e.lengthComputable && onProgress(e.loaded);
    x.onload = () => (x.status < 300 ? ok() : bad(new Error((() => { try { return JSON.parse(x.responseText).error; } catch { return `Erro ${x.status}`; } })())));
    x.onerror = () => bad(new Error('A conexão caiu durante o envio.'));
    x.send(item.file);
  });
}
let uploading = false;
async function uploadItems(items, dir) {
  items = items.filter((i) => i.file);
  if (!items.length) return;
  if (uploading) return toast('Espere o envio atual terminar.');
  uploading = true;
  const total = items.reduce((n, i) => n + i.file.size, 0) || 1;
  let done = 0, sent = 0;
  const box = $('#up-status');
  box.hidden = false;
  const paint = (cur) => {
    $('#up-text').textContent = `Enviando ${Math.min(sent + 1, items.length)} de ${items.length} (${Math.round(((done + cur) / total) * 100)}%)`;
    $('#up-fill').style.width = ((done + cur) / total) * 100 + '%';
  };
  const errors = [];
  for (const it of items) {
    paint(0);
    try { await sendOne(it, dir, paint); } catch (e) { errors.push(`${it.rel}: ${e.message}`); }
    done += it.file.size; sent++;
  }
  box.hidden = true; uploading = false;
  if (dir) { S.expanded.add(dir); store.set('expanded', [...S.expanded]); }
  refreshTree();
  const ok = items.length - errors.length;
  toast(errors.length ? `${ok} enviados, ${errors.length} falharam. ${errors[0]}` : ok === 1 ? `${items[0].rel} enviado.` : `${ok} arquivos enviados.`);
  return items.filter((it) => !errors.some((e) => e.startsWith(it.rel + ':'))).map((it) => (dir ? dir + '/' : '') + it.rel);
}
let pickDir = '';
function pick(kind, dir) { pickDir = dir || ''; const inp = $(kind === 'dir' ? '#up-dir' : '#up-files'); inp.value = ''; inp.click(); }
$('#up-files').addEventListener('change', (e) => uploadItems([...e.target.files].map((f) => ({ file: f, rel: f.name })), pickDir));
$('#up-dir').addEventListener('change', (e) => uploadItems([...e.target.files].map((f) => ({ file: f, rel: f.webkitRelativePath || f.name })), pickDir));
$('#up-btn').addEventListener('click', (e) => {
  e.stopPropagation();
  const r = e.currentTarget.getBoundingClientRect();
  showCtx([
    { icon: 'upload', label: 'Enviar arquivos', run: () => pick('files') },
    { icon: 'folder', label: 'Enviar uma pasta', run: () => pick('dir') },
    '-',
    { icon: 'download', label: 'Baixar tudo (.zip)', run: () => downloadPath('.') },
  ], r.left, r.bottom + 4);
});
// Menu de clique direito da árvore: explorer.js (todas as ações do Explorer).
$('#file-dl').addEventListener('click', () => S.filePath && downloadPath(rel(S.filePath)));

// Arrastar do computador pra lateral (solta numa pasta = vai pra ela)
async function readEntries(entry, prefix, out) {
  if (entry.isFile) { await new Promise((ok) => entry.file((f) => { out.push({ file: f, rel: prefix + f.name }); ok(); }, ok)); return; }
  if (!entry.isDirectory) return;
  const reader = entry.createReader();
  for (;;) {
    const batch = await new Promise((ok) => reader.readEntries(ok, () => ok([])));
    if (!batch.length) break;
    for (const e of batch) await readEntries(e, prefix + entry.name + '/', out);
  }
}
const filesSec = $('#sec-files');
let dragDepth = 0;
const isFileDrag = (e) => [...(e.dataTransfer?.types || [])].includes('Files');
filesSec.addEventListener('dragenter', (e) => { if (!isFileDrag(e)) return; e.preventDefault(); dragDepth++; filesSec.classList.add('dragging'); $('#drop-hint').hidden = false; });
filesSec.addEventListener('dragover', (e) => {
  if (!isFileDrag(e)) return;
  e.preventDefault();
  document.querySelectorAll('.tree-row.drop').forEach((r) => r.classList.remove('drop'));
  e.target.closest('.tree-row[data-dir="true"]')?.classList.add('drop');
});
filesSec.addEventListener('dragleave', (e) => { if (!isFileDrag(e)) return; if (--dragDepth <= 0) { dragDepth = 0; filesSec.classList.remove('dragging'); $('#drop-hint').hidden = true; } });
filesSec.addEventListener('drop', async (e) => {
  if (!isFileDrag(e)) return;
  e.preventDefault();
  dragDepth = 0; filesSec.classList.remove('dragging'); $('#drop-hint').hidden = true;
  const row = e.target.closest('.tree-row');
  document.querySelectorAll('.tree-row.drop').forEach((r) => r.classList.remove('drop'));
  const dir = row ? (row.dataset.dir === 'true' ? row.dataset.path : parentOf(row.dataset.path)) : '';
  const entries = [...e.dataTransfer.items].map((i) => i.webkitGetAsEntry?.()).filter(Boolean);
  const items = [];
  if (entries.length) for (const en of entries) await readEntries(en, '', items);
  else [...e.dataTransfer.files].forEach((f) => items.push({ file: f, rel: f.name }));
  uploadItems(items, dir);
});

// ---------- Editor (Monaco, o mesmo do VS Code) ----------
let monacoP = null;
function loadMonaco() {
  if (monacoP) return monacoP;
  monacoP = new Promise((ok, bad) => {
    const base = 'https://cdn.jsdelivr.net/npm/monaco-editor@0.52.2/min';
    window.MonacoEnvironment = { getWorkerUrl: () => 'data:text/javascript;charset=utf-8,' + encodeURIComponent(`self.MonacoEnvironment={baseUrl:'${base}/'};importScripts('${base}/vs/base/worker/workerMain.js');`) };
    const s = document.createElement('script');
    s.src = base + '/vs/loader.js';
    s.onload = () => { window.require.config({ paths: { vs: base + '/vs' } }); window.require(['vs/editor/editor.main'], () => { defineMonacoTheme(); ok(window.monaco); }, bad); };
    s.onerror = () => { monacoP = null; bad(new Error('Não carreguei o editor. Confira a internet e tente de novo.')); };
    document.head.append(s);
  });
  return monacoP;
}
const cssVar = (n) => getComputedStyle(document.documentElement).getPropertyValue(n).trim();
function defineMonacoTheme() {
  if (!window.monaco) return;
  const bg = cssVar('--bg'), light = parseInt(bg.slice(1, 3), 16) > 128;
  monaco.editor.defineTheme('claudex', {
    base: light ? 'vs' : 'vs-dark', inherit: true, rules: [],
    colors: {
      'editor.background': bg, 'editorGutter.background': bg, 'minimap.background': bg,
      'editor.foreground': cssVar('--text'), 'editorLineNumber.foreground': cssVar('--faint'), 'editorLineNumber.activeForeground': cssVar('--muted'),
      'editor.lineHighlightBackground': cssVar('--raise'), 'editor.lineHighlightBorder': '#00000000', 'editorIndentGuide.background1': cssVar('--line'),
      'editorWidget.background': cssVar('--raise'), 'editorWidget.border': cssVar('--line'), 'input.background': cssVar('--bg'),
      'scrollbarSlider.background': cssVar('--line') + 'aa', 'scrollbarSlider.hoverBackground': cssVar('--faint') + 'aa',
      'diffEditor.insertedTextBackground': cssVar('--m-gpt') + '33', 'diffEditor.removedTextBackground': cssVar('--danger') + '33',
      'diffEditor.insertedLineBackground': cssVar('--m-gpt') + '14', 'diffEditor.removedLineBackground': cssVar('--danger') + '14',
    },
  });
  monaco.editor.setTheme('claudex');
}
const EDITOR_OPTS = {
  fontFamily: "'JetBrains Mono', ui-monospace, monospace", fontSize: 12.5, lineHeight: 20, fontLigatures: true,
  minimap: { enabled: false }, scrollBeyondLastLine: false, automaticLayout: true, padding: { top: 10, bottom: 10 },
  renderLineHighlight: 'line', smoothScrolling: true, tabSize: 2, overviewRulerBorder: false, stickyScroll: { enabled: false },
  scrollbar: { verticalScrollbarSize: 10, horizontalScrollbarSize: 10 }, bracketPairColorization: { enabled: true },
};
const FP = { mode: null, saved: '', editor: null, diff: null, model: null, orig: null, showDiff: false };
const langFor = (p) => { const ext = '.' + String(p).split('.').pop().toLowerCase(); return monaco.languages.getLanguages().find((l) => (l.extensions || []).includes(ext))?.id || 'plaintext'; };
function disposeEditors() {
  FP.editor?.dispose(); FP.diff?.dispose(); FP.model?.dispose(); FP.orig?.dispose();
  FP.editor = FP.diff = FP.model = FP.orig = null; FP.showDiff = false;
}
const dirty = () => FP.mode === 'file' && !!FP.model && FP.model.getValue() !== FP.saved;
function paintFileHead() {
  const d = dirty();
  $('#file-dirty').hidden = !d;
  $('#file-save').hidden = !d; $('#file-discard').hidden = !d;
  $('#file-diff').hidden = !d;
  $('#file-diff').textContent = FP.showDiff ? 'Voltar a editar' : 'Mudanças';
  $('#file-open').hidden = FP.mode !== 'agentdiff';
  $('#file-dl').hidden = FP.mode === 'agentdiff';
}
function mountEditor() {
  const body = $('#file-body');
  body.innerHTML = '<div class="mon"></div>';
  FP.editor = monaco.editor.create($('.mon', body), { ...EDITOR_OPTS, model: FP.model });
  FP.editor.addCommand(monaco.KeyMod.CtrlCmd | monaco.KeyCode.KeyS, saveFile);
}
function mountDiff(readOnly) {
  const body = $('#file-body');
  body.innerHTML = '<div class="mon"></div>';
  FP.diff = monaco.editor.createDiffEditor($('.mon', body), { ...EDITOR_OPTS, readOnly, originalEditable: false, renderSideBySide: body.clientWidth > 720, renderOverviewRuler: false, hideUnchangedRegions: { enabled: true } });
  FP.diff.setModel({ original: FP.orig, modified: FP.model });
  if (!readOnly) FP.diff.getModifiedEditor().addCommand(monaco.KeyMod.CtrlCmd | monaco.KeyCode.KeyS, saveFile);
}
async function confirmLeave() {
  return !dirty() || confirmDialog('Descartar as mudanças?', 'Este arquivo tem mudanças que ainda não foram salvas.', 'Descartar');
}
async function openFile(abs) {
  if (FP.mode === 'file' && S.filePath === abs && FP.model) return;
  if (!(await confirmLeave())) return;
  S.filePath = abs;
  $('#file-panel').hidden = false;
  $('#file-path').textContent = rel(abs);
  $('#file-path').title = rel(abs);
  const body = $('#file-body');
  disposeEditors(); FP.mode = null; paintFileHead();
  body.innerHTML = '<p class="file-msg">Abrindo…</p>';
  renderTree();
  try {
    const c = await api('/file/content?path=' + encodeURIComponent(rel(abs)));
    if (S.filePath !== abs) return;
    if (c?.encoding === 'base64' && /^image\//.test(c.mimeType || '')) {
      FP.mode = 'img';
      body.innerHTML = `<img class="file-img" alt="${esc(rel(abs))}" src="data:${esc(c.mimeType)};base64,${c.content}">`;
    } else if (c?.type === 'text' && c.encoding !== 'base64') {
      await loadMonaco();
      if (S.filePath !== abs) return;
      FP.mode = 'file'; FP.saved = c.content || '';
      FP.model = monaco.editor.createModel(FP.saved, langFor(abs));
      FP.model.onDidChangeContent(paintFileHead);
      mountEditor();
    } else body.innerHTML = '<p class="file-msg">Esse arquivo não é texto, então não dá pra mostrar aqui.</p>';
  } catch (err) {
    body.innerHTML = `<p class="file-msg">Não deu pra abrir: ${esc(err.message)}</p>`;
  }
  paintFileHead();
}
// Diff de uma edição feita pelo agente (antes/depois guardados no cartão da ferramenta)
async function openAgentDiff(part) {
  const d = part.state?.diff, file = part.state?.input?.filePath;
  if (!d || !file || !(await confirmLeave())) return;
  await loadMonaco();
  disposeEditors();
  S.filePath = file; FP.mode = 'agentdiff';
  $('#file-panel').hidden = false;
  $('#file-path').textContent = rel(file) + ' (mudanças do agente)';
  FP.orig = monaco.editor.createModel(d.before, langFor(file));
  FP.model = monaco.editor.createModel(d.after, langFor(file));
  mountDiff(true);
  paintFileHead();
  renderTree();
}
function toggleDiff() {
  if (FP.mode !== 'file' || !FP.model) return;
  if (!FP.showDiff) { FP.editor.dispose(); FP.editor = null; FP.orig = monaco.editor.createModel(FP.saved, FP.model.getLanguageId()); mountDiff(false); FP.showDiff = true; }
  else { FP.diff.dispose(); FP.diff = null; FP.orig.dispose(); FP.orig = null; mountEditor(); FP.showDiff = false; }
  paintFileHead();
}
async function saveFile() {
  if (!dirty()) return;
  const value = FP.model.getValue();
  $('#file-save').disabled = true;
  try {
    await api('/file/content', { method: 'PUT', body: { path: rel(S.filePath), content: value } });
    FP.saved = value;
    if (FP.showDiff) toggleDiff();
    toast('Arquivo salvo.');
  } catch (err) { toast('Não salvou: ' + err.message); }
  $('#file-save').disabled = false;
  paintFileHead();
}
async function closeFile() {
  if (!(await confirmLeave())) return;
  disposeEditors(); FP.mode = null;
  S.filePath = null; $('#file-panel').hidden = true; renderTree();
}
$('#file-close').addEventListener('click', closeFile);
$('#file-save').addEventListener('click', saveFile);
$('#file-diff').addEventListener('click', toggleDiff);
$('#file-discard').addEventListener('click', () => { if (FP.showDiff) toggleDiff(); FP.model?.setValue(FP.saved); paintFileHead(); });
$('#file-open').addEventListener('click', () => { const f = S.filePath; disposeEditors(); FP.mode = null; openFile(f); });

// Largura do painel: arrastar a borda esquerda
(() => {
  const w = store.get('fileW', 0);
  if (w) document.documentElement.style.setProperty('--file-w', w + 'px');
  const h = $('#file-resize');
  h.addEventListener('pointerdown', (e) => {
    e.preventDefault(); h.setPointerCapture(e.pointerId); h.classList.add('drag');
    const move = (ev) => { const nw = Math.max(320, Math.min(innerWidth - 520, innerWidth - ev.clientX)); document.documentElement.style.setProperty('--file-w', nw + 'px'); store.set('fileW', nw); };
    const up = () => { h.classList.remove('drag'); h.removeEventListener('pointermove', move); h.removeEventListener('pointerup', up); };
    h.addEventListener('pointermove', move); h.addEventListener('pointerup', up);
  });
})();

let treeTimer = 0;
function fileChanged(file) {
  clearTimeout(treeTimer);
  treeTimer = setTimeout(async () => {
    await refreshTree();
    const row = file && $(`.tree-row[data-abs="${CSS.escape(file)}"]`);
    if (row) row.classList.add('flash');
  }, 250);
  if (file && file === S.filePath && FP.mode === 'file') {
    if (dirty()) toast('O arquivo mudou no disco enquanto você editava. Salvar vai sobrescrever.');
    else api('/file/content?path=' + encodeURIComponent(rel(file))).then((c) => { if (c?.type === 'text' && FP.model && !dirty()) { FP.saved = c.content || ''; FP.model.setValue(FP.saved); paintFileHead(); } }).catch(() => {});
  }
}

// ---------- Eventos ao vivo ----------
let es;
function connectEvents() {
  es?.close();
  es = new EventSource('/api/event');
  let wasDown = false;
  es.onopen = async () => {
    if (!wasDown) return;
    wasDown = false;
    await loadSessions().catch(() => {});
    S.loaded.clear();
    pruneGroups(); renderAll();
  };
  es.onerror = () => { wasDown = true; };
  es.onmessage = (ev) => {
    let e; try { e = JSON.parse(ev.data); } catch { return; }
    const p = e.properties || {};
    switch (e.type) {
      case 'session.created':
      case 'session.updated': {
        const info = p.info;
        if (!info) break;
        const old = S.sessions.get(info.id);
        S.sessions.set(info.id, info);
        if (!old || old.title !== info.title) { renderTabs(); }
        renderChats();
        break;
      }
      case 'session.deleted':
        if (p.info) { S.sessions.delete(p.info.id); closeTab(p.info.id); renderChats(); }
        break;
      case 'session.status':
        S.status.set(p.sessionID, p.status);
        renderTabs(); renderChats(); updateComposer(p.sessionID);
        break;
      case 'session.idle':
        S.status.set(p.sessionID, { type: 'idle' });
        renderTabs(); renderChats(); updateComposer(p.sessionID);
        break;
      case 'session.error': {
        const sid = p.sessionID;
        const er = p.error;
        if (sid && er && er.name !== 'MessageAbortedError') { S.errors.set(sid, er.data?.message || er.name); if (shownIn(sid) >= 0) paintMessages(sid); }
        break;
      }
      case 'message.updated': {
        const info = p.info, map = S.msgs.get(info?.sessionID);
        if (!map) break;
        const m = map.get(info.id);
        if (m) m.info = info; else map.set(info.id, { info, parts: new Map() });
        schedule(info.sessionID, info.id);
        break;
      }
      case 'message.removed': {
        const map = S.msgs.get(p.sessionID);
        if (map?.delete(p.messageID) && shownIn(p.sessionID) >= 0) paintMessages(p.sessionID);
        break;
      }
      case 'message.part.updated': {
        const part = p.part, map = S.msgs.get(part?.sessionID);
        if (!map) break;
        let m = map.get(part.messageID);
        if (!m) { m = { info: { id: part.messageID, sessionID: part.sessionID, role: 'assistant', time: { created: Date.now() } }, parts: new Map() }; map.set(part.messageID, m); }
        m.parts.set(part.id, part);
        schedule(part.sessionID, part.messageID);
        break;
      }
      case 'message.part.delta': {
        const m = S.msgs.get(p.sessionID)?.get(p.messageID);
        const part = m?.parts.get(p.partID);
        if (!part) break;
        part[p.field] = (part[p.field] || '') + p.delta;
        schedule(p.sessionID, p.messageID);
        break;
      }
      case 'message.part.removed': {
        const m = S.msgs.get(p.sessionID)?.get(p.messageID);
        if (m?.parts.delete(p.partID)) schedule(p.sessionID, p.messageID);
        break;
      }
      case 'file.edited':
      case 'file.watcher.updated':
        fileChanged(p.file);
        break;
    }
  };
}

// ---------- Avisos e confirmação ----------
let toastTimer = 0;
function toast(msg) {
  const t = $('#toast');
  t.textContent = msg; t.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { t.hidden = true; }, 2600);
}
function confirmDialog(titleText, body, okText = 'Apagar') {
  const d = $('#confirm');
  $('#confirm-title').textContent = titleText;
  $('#confirm-body').textContent = body;
  $('#confirm-ok').textContent = okText;
  d.returnValue = '';
  d.showModal();
  $('#confirm-ok').focus();
  return new Promise((ok) => d.addEventListener('close', () => ok(d.returnValue === 'ok'), { once: true }));
}

// ---------- Menu de contexto ----------
function showCtx(items, x, y) {
  const m = $('#ctx');
  m.innerHTML = items.map((it, i) => it === '-' ? '<hr>' : `<button type="button" role="menuitem" data-i="${i}" class="${it.danger ? 'danger' : ''}">${icon(it.icon)}${esc(it.label)}${it.action ? keysHTML(S.prefs.shortcuts[it.action] ?? ACTIONS[it.action].def) : it.keys ? keysHTML(it.keys) : ''}</button>`).join('');
  m.hidden = false;
  const r = m.getBoundingClientRect();
  m.style.left = Math.min(x, innerWidth - r.width - 8) + 'px';
  m.style.top = Math.min(y, innerHeight - r.height - 8) + 'px';
  m.onclick = (e) => { const b = e.target.closest('[data-i]'); if (!b) return; hideCtx(); items[+b.dataset.i].run(); };
  m.querySelector('button')?.focus();
}
// Sem zoom: a interface fica sempre na escala do app (pinça e Ctrl/⌘ + roda chegam como wheel com ctrlKey; Safari usa gesture*).
// Só impede o zoom do navegador; a tecla continua chegando no terminal e no editor.
addEventListener('wheel', (e) => { if (e.ctrlKey || e.metaKey) e.preventDefault(); }, { passive: false, capture: true });
for (const ev of ['gesturestart', 'gesturechange', 'gestureend']) addEventListener(ev, (e) => e.preventDefault(), { passive: false });
addEventListener('keydown', (e) => {
  if ((isMac ? e.metaKey : e.ctrlKey) && !e.altKey && /^(Equal|Minus|Digit0|NumpadAdd|NumpadSubtract|Numpad0)$/.test(e.code)) e.preventDefault();
}, true);
const hideCtx = () => { $('#ctx').hidden = true; };
document.addEventListener('click', (e) => { if (!e.target.closest('#ctx')) hideCtx(); });
document.addEventListener('keydown', (e) => {
  if (e.key !== 'Escape') return;
  if (!$('#ctx').hidden) return hideCtx();
  const t = document.activeElement;
  if (document.querySelector('dialog[open]') || (t && /INPUT|TEXTAREA/.test(t.tagName)) || t?.closest?.('.mon')) return;
  $('.composer textarea', groupEl(S.g))?.focus();
});
window.addEventListener('blur', hideCtx);
function chatMenu(sid, x, y) {
  const open = isOpen(sid);
  showCtx([
    { icon: 'plus', label: open ? 'Ir pra aba' : 'Abrir nesta janela', run: () => openTab(sid) },
    { icon: 'window', label: 'Abrir ao lado', run: () => openBeside(sid), action: sid === S.active ? 'split' : null },
    '-',
    { icon: 'pencil', label: 'Renomear', run: () => { $('#sec-chats').classList.remove('collapsed'); if (innerWidth <= 900) openSide(); startRename(sid); } },
    ...(open ? [{ icon: 'x', label: 'Fechar aba', run: () => closeTab(sid), action: sid === S.active ? 'closeTab' : null }] : []),
    { icon: 'select', label: S.selected.has(sid) ? 'Desmarcar' : 'Marcar', run: () => toggleSelect(sid) },
    '-',
    { icon: 'trash', label: 'Apagar', danger: true, run: () => deleteChat(sid) },
  ], x, y);
}

// ---------- Seleção em lote ----------
function setSelecting(on) {
  if (!on) S.selected.clear();
  $('#sec-chats').classList.remove('collapsed');
  renderChats(); paintSelectBar();
}
function toggleSelect(sid, range) {
  const ids = [...S.sessions.values()].filter(isTop).sort((a, b) => b.time.updated - a.time.updated).map((s) => s.id);
  if (range && S.lastSel && ids.includes(S.lastSel)) {
    const [i, k] = [ids.indexOf(S.lastSel), ids.indexOf(sid)].sort((x, y) => x - y);
    ids.slice(i, k + 1).forEach((x) => S.selected.add(x));
  } else if (S.selected.has(sid)) S.selected.delete(sid);
  else S.selected.add(sid);
  S.lastSel = sid;
  renderChats(); paintSelectBar();
}
function paintSelectBar() {
  const n = S.selected.size;
  S.selecting = n > 0;
  $('#select-bar').hidden = !n;
  $('#select-count').textContent = n === 1 ? '1 selecionada' : `${n} selecionadas`;
  $('#select-delete').disabled = !n;
  $('#select-delete').textContent = n ? `Apagar ${n}` : 'Apagar';
}
$('#select-cancel').addEventListener('click', () => setSelecting(false));
$('#select-all').addEventListener('click', () => {
  const ids = [...S.sessions.values()].filter(isTop).map((s) => s.id);
  if (S.selected.size === ids.length) S.selected.clear(); else ids.forEach((x) => S.selected.add(x));
  renderChats(); paintSelectBar();
});
$('#select-delete').addEventListener('click', async () => {
  const ids = [...S.selected];
  if (!ids.length) return;
  const ok = await confirmDialog(ids.length === 1 ? 'Apagar 1 conversa?' : `Apagar ${ids.length} conversas?`, 'Elas somem da lista e não dá pra desfazer. Os arquivos continuam onde estão.');
  if (!ok) return;
  await deleteMany(ids);
  setSelecting(false);
});

// ---------- Temas ----------
const THEMES = [
  { id: 'padrao', name: 'Padrão', sub: 'Escuro estilo VS Code', p: ['#1F1F1F', '#181818', '#2A2A2A', '#2B2B2B', '#CCCCCC', '#3FB950', '#E0653F'] },
  { id: 'escuro', name: 'Grafite claro', sub: 'Grafite neutro, sem bordas', p: ['#141518', '#141518', '#1D1F23', '#26282D', '#E9E9EC', '#9C9FA7', '#E9B872'] },
  { id: 'auto', name: 'Automático', sub: 'Segue o claro/escuro do sistema' },
  { id: 'berinjela', name: 'Berinjela', sub: 'Escuro, roxo quente', p: ['#17131C', '#1F1A26', '#2A2333', '#3A3145', '#ECE6F2', '#F0B45C', '#7BD8A6'] },
  { id: 'tokyo', name: 'Tokyo Night', sub: 'Azul noturno', p: ['#1A1B26', '#16161E', '#24283B', '#2F334D', '#C0CAF5', '#7AA2F7', '#9ECE6A'] },
  { id: 'grafite', name: 'Grafite', sub: 'Cinza neutro', p: ['#161616', '#1E1E1E', '#2A2A2A', '#383838', '#E8E8E8', '#9ECBFF', '#F2B65E'] },
  { id: 'terminal', name: 'Terminal', sub: 'Verde de fósforo', p: ['#0E1410', '#121A15', '#1A261F', '#25352B', '#CDEBD5', '#7EE2A8', '#E8C26A'] },
  { id: 'claro', name: 'Claro', sub: 'Pra dia claro', p: ['#FAF8FC', '#F1EDF5', '#E6E0ED', '#D6CEDF', '#231C2B', '#6E55D9', '#B7771C'] },
];
function applyTheme(t) {
  if (!THEMES.some((x) => x.id === t)) t = 'padrao';
  document.documentElement.dataset.theme = t;
  S.prefs.theme = t;
  store.set('theme', t);
  defineMonacoTheme();
  window.termTheme?.();
}
function previewHTML(p) {
  const [bg, panel, raise, line, text, acc, acc2] = p;
  return `<div class="tp" style="--p-bg:${bg};--p-panel:${panel};--p-raise:${raise};--p-line:${line};--p-text:${text};--p-acc:${acc};--p-acc2:${acc2}">
    <div class="tp-side"><i></i><i></i><i></i><i></i></div>
    <div class="tp-main"><div class="tp-bub"></div><div class="tp-who"></div><div class="tp-l" style="width:85%"></div><div class="tp-l" style="width:60%"></div><div class="tp-comp"></div></div></div>`;
}
const savePrefs = (patch) => { Object.assign(S.prefs, patch); return api('/prefs', { method: 'PUT', body: patch }).catch(() => toast('Não deu pra salvar a preferência.')); };

// ---------- Atalhos ----------
const ACTIONS = {
  newTab: { name: 'Nova conversa nesta janela', def: 'Alt+KeyT', run: () => newChat() },
  newBeside: { name: 'Nova conversa ao lado', def: 'Alt+KeyN', run: () => newChat(true) },
  split: { name: 'Abrir a aba atual ao lado', def: 'Alt+Backslash', run: () => S.active && openBeside(S.active) },
  nextGroup: { name: 'Ir pra próxima coluna', def: 'Alt+Period', run: () => { focusGroup((S.g + 1) % S.groups.length); $('.composer textarea', groupEl(S.g))?.focus(); } },
  closeTab: { name: 'Fechar aba', def: isMac ? 'Ctrl+KeyW' : 'Alt+KeyW', run: () => S.active && closeTab(S.active) },
  nextTab: { name: 'Próxima aba', def: 'Alt+BracketRight', run: () => cycleTab(1) },
  prevTab: { name: 'Aba anterior', def: 'Alt+BracketLeft', run: () => cycleTab(-1) },
  selectMode: { name: 'Marcar ou desmarcar todas as conversas', def: 'Alt+KeyS', run: () => $('#select-all').click() },
  settings: { name: 'Abrir configurações', def: 'Alt+Comma', run: () => openSettings() },
};
const bindingOf = (a) => (a in S.prefs.shortcuts ? S.prefs.shortcuts[a] : ACTIONS[a].def);
function cycleTab(d) {
  if (!S.open.length) return;
  const i = S.open.indexOf(S.active);
  openTab(S.open[(i + d + S.open.length) % S.open.length]);
}
function comboFrom(e) {
  if (['Shift', 'Control', 'Alt', 'Meta', 'CapsLock'].includes(e.key)) return null;
  if (!e.ctrlKey && !e.altKey && !e.metaKey) return null;
  return [e.ctrlKey && 'Ctrl', e.metaKey && 'Meta', e.altKey && 'Alt', e.shiftKey && 'Shift', e.code].filter(Boolean).join('+');
}
const KEYN = { BracketLeft: '[', BracketRight: ']', Comma: ',', Period: '.', Slash: '/', Backslash: '\\', Semicolon: ';', Quote: "'", Minus: '-', Equal: '=', Backquote: '`', ArrowLeft: '←', ArrowRight: '→', ArrowUp: '↑', ArrowDown: '↓', Enter: '↵', Backspace: '⌫', Space: 'Espaço', Tab: 'Tab', Escape: 'Esc' };
const keyName = (c) => KEYN[c] || c.replace(/^Key/, '').replace(/^Digit/, '').replace(/^Numpad/, 'Num ');
const MODN = isMac ? { Ctrl: '⌃', Meta: '⌘', Alt: '⌥', Shift: '⇧' } : { Ctrl: 'Ctrl', Meta: 'Win', Alt: 'Alt', Shift: 'Shift' };
function keysHTML(c) {
  if (!c) return '';
  return `<span class="keys">${c.split('+').map((k) => `<kbd>${esc(MODN[k] || keyName(k))}</kbd>`).join('')}</span>`;
}
document.addEventListener('keydown', (e) => {
  if (S.recording) return;
  const c = comboFrom(e);
  if (!c) return;
  const a = Object.keys(ACTIONS).find((k) => bindingOf(k) === c);
  if (!a) return;
  // Dentro do terminal, ⌥/⌃ + tecla são do terminal; só os atalhos do próprio terminal passam.
  if (e.target.closest?.('.term-body') && !ACTIONS[a].term) return;
  e.preventDefault(); e.stopPropagation();
  if ($('#settings').open && a !== 'settings') $('#settings').close();
  ACTIONS[a].run();
}, true);

// ---------- Configurações ----------
let setSec = 'aparencia';
function openSettings(sec) {
  if (sec) setSec = sec;
  const d = $('#settings');
  renderSettings();
  if (!d.open) d.showModal();
}
$('#settings-btn').addEventListener('click', () => openSettings());
$('#settings-close').addEventListener('click', () => $('#settings').close());
$('#settings').addEventListener('click', (e) => { if (e.target === e.currentTarget) e.currentTarget.close(); });
$('#settings').addEventListener('close', () => { S.recording = null; });
document.querySelectorAll('.set-nav [data-sec]').forEach((b) => b.addEventListener('click', () => { setSec = b.dataset.sec; renderSettings(); }));

function renderSettings() {
  document.querySelectorAll('.set-nav [data-sec]').forEach((b) => b.setAttribute('aria-selected', b.dataset.sec === setSec));
  const c = $('#set-content');
  if (setSec === 'aparencia') {
    const cur = document.documentElement.dataset.theme;
    c.innerHTML = `<h3>Aparência</h3><p class="lead">Escolha as cores do CodeFy. Fica salvo no seu espaço e vale em qualquer aparelho. A fonte é a JetBrains Mono.</p>
      <div class="themes" role="radiogroup" aria-label="Tema">${THEMES.map((t) => `<button type="button" class="theme-card" role="radio" aria-checked="${t.id === cur}" data-theme-id="${t.id}">
        ${t.p ? previewHTML(t.p) : `<div class="tp-split">${previewHTML(THEMES[0].p)}${previewHTML(THEMES.find((x) => x.id === 'claro').p)}</div>`}
        <span class="nm">${t.name}${icon('check')}</span><span class="sub">${t.sub}</span></button>`).join('')}</div>`;
    c.querySelectorAll('.theme-card').forEach((b) => b.addEventListener('click', () => {
      applyTheme(b.dataset.themeId);
      savePrefs({ theme: b.dataset.themeId });
      renderSettings();
    }));
  } else if (setSec === 'aprovacao') {
    c.innerHTML = `<h3>Aprovação</h3><p class="lead">O que o CodeFy pode fazer sem te perguntar. Vale pras conversas novas; cada conversa pode trocar no botão ao lado do modelo.</p>
      <div class="modes" role="radiogroup" aria-label="Modo padrão">${MODES.map((m) => `<button type="button" class="mode-card" role="radio" aria-checked="${m.id === S.prefs.approval}" data-mode="${m.id}">
        ${icon('shield')}<span><span class="n">${m.name}</span><span class="d">${m.note}</span></span>${icon('check').replace('class="i"', 'class="i ok"')}</button>`).join('')}</div>`;
    c.querySelectorAll('.mode-card').forEach((b) => b.addEventListener('click', async () => { if (!(await okBypass(b.dataset.mode, S.prefs.approval))) return; savePrefs({ approval: b.dataset.mode }); renderSettings(); }));
  } else if (setSec === 'atalhos') {
    c.innerHTML = `<h3>Atalhos</h3><p class="lead">Clique num atalho e aperte a nova combinação. Use ${isMac ? '⌥, ⌃ ou ⌘' : 'Alt, Ctrl ou Win'} junto com uma tecla.</p>
      <div class="sc-list">${Object.entries(ACTIONS).map(([k, a]) => `<div class="sc-row" data-action="${k}"><span class="nm">${a.name}</span>
        <button type="button" class="sc-key${S.recording === k ? ' rec' : ''}" aria-label="Mudar atalho: ${esc(a.name)}">${S.recording === k ? 'Aperte as teclas… (Esc cancela)' : bindingOf(k) ? keysHTML(bindingOf(k)) : '<span class="none">Sem atalho</span>'}</button>
        <button type="button" class="icon-btn sc-clear" aria-label="Remover atalho" title="Remover atalho">${icon('x')}</button></div>`).join('')}</div>
      <p class="sc-note">Combinações do próprio navegador (${isMac ? '⌘T, ⌘N, ⌘W' : 'Ctrl+T, Ctrl+N, Ctrl+W'}) não chegam na página, então não funcionam aqui.</p>
      <div class="set-foot"><button type="button" class="btn-flat" id="sc-reset">Restaurar padrões</button></div>`;
    c.querySelectorAll('.sc-row').forEach((row) => {
      const k = row.dataset.action;
      $('.sc-key', row).addEventListener('click', () => { S.recording = S.recording === k ? null : k; renderSettings(); if (S.recording) $(`.sc-row[data-action="${k}"] .sc-key`).focus(); });
      $('.sc-clear', row).addEventListener('click', () => { savePrefs({ shortcuts: { ...S.prefs.shortcuts, [k]: '' } }); renderSettings(); });
    });
    $('#sc-reset').addEventListener('click', () => { savePrefs({ shortcuts: {} }); toast('Atalhos voltaram pro padrão.'); renderSettings(); });
  } else if (setSec === 'terminal') {
    renderTermSettings(c);
  } else if (setSec === 'api' && !S.user) {
    renderApiSettings(c);
  } else if (setSec === 'usuarios' && S.admin) {
    renderUsers(c);
  } else {
    c.innerHTML = `<h3>Conta</h3><p class="lead">${S.user ? 'Seu espaço é isolado: o CodeFy só enxerga a pasta de projetos dele.' : S.launcher ? `Rodando isolado num contêiner: o CodeFy só enxerga a pasta abaixo.${S.pick ? '' : ' Pra usar outra, rode codefy pasta no terminal.'}` : 'Rodando no seu computador. O CodeFy trabalha na pasta abaixo, mas os comandos dele rodam com as suas permissões.'}</p>
      <div class="acct">
        ${S.user ? `<div class="acct-row"><span>Usuário</span><code>${esc(S.user)}${S.admin ? ' (admin)' : ''}</code></div>` : ''}
        <div class="acct-row"><span>${S.user ? 'Pasta de projetos' : 'Pasta'}</span><code>${esc(S.hostFolder || S.workdir.replace(/^\/home\/[^/]+\//, '~/'))}</code></div>
        ${S.pick ? '<div class="acct-row"><span>Usar outra pasta do computador</span><button type="button" class="btn-flat" id="pick-folder">Trocar pasta</button></div>' : ''}
      </div>
      ${S.user ? `<h4>Trocar senha</h4>
      <form class="pw-form" id="pw-form">
        <label class="field"><span>Senha atual</span><input type="password" name="current" autocomplete="current-password" required></label>
        <label class="field"><span>Nova senha</span><input type="password" name="next" autocomplete="new-password" minlength="8" required></label>
        <p class="form-err" id="pw-err" role="alert"></p>
        <button class="btn-primary" type="submit">Trocar senha</button>
      </form>` : ''}
      <h4>Sessão</h4>
      <div class="acct"><div class="acct-row"><span>Sair deste aparelho</span><button type="button" class="btn-flat" id="logout">Sair</button></div></div>`;
    $('#logout').addEventListener('click', async () => { await fetch('/auth/logout'); location.reload(); });
    // Lançador: o servidor desliga, o computador pergunta a pasta nova e ele volta; a janela recarrega sozinha.
    $('#pick-folder')?.addEventListener('click', async () => {
      await api('/launcher/pick-folder', { method: 'POST' }).catch(() => {});
      $('#settings').close();
      $('#groups').innerHTML = '<div class="empty"><h2>Escolha a pasta</h2><p>Abriu uma janela no seu computador pra escolher a pasta nova. O CodeFy volta sozinho em seguida.</p></div>';
      for (let i = 0; i < 400; i++) {
        await new Promise((r) => setTimeout(r, 1500));
        const me = await fetch('/auth/me').then((r) => r.json()).catch(() => null);
        if (me?.boot && me.boot !== S.boot) { S.leaving = true; return location.reload(); }
      }
    });
    $('#pw-form')?.addEventListener('submit', async (e) => {
      e.preventDefault();
      const f = e.currentTarget;
      $('#pw-err').textContent = '';
      const r = await fetch('/auth/password', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ current: f.current.value, next: f.next.value }) });
      if (!r.ok) { $('#pw-err').textContent = (await r.json().catch(() => ({}))).error || 'Não deu pra trocar.'; return; }
      f.reset();
      toast('Senha trocada.');
    });
  }
}

// ---------- Usuários (admin) ----------
async function adminApi(p, opts = {}) {
  const r = await fetch('/admin' + p, { method: opts.method || 'GET', headers: opts.body ? { 'content-type': 'application/json' } : {}, body: opts.body ? JSON.stringify(opts.body) : undefined });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(j.error || `Erro ${r.status}`);
  return j;
}
const CSTATE = { running: 'ligado', exited: 'desligado', created: 'criado', restarting: 'reiniciando', paused: 'pausado' };
async function renderUsers(c) {
  c.innerHTML = `<h3>Usuários</h3><p class="lead">Cada pessoa entra com usuário e senha e ganha um espaço isolado, com os próprios arquivos e conversas.</p>
    <form class="user-new" id="user-new">
      <label class="field"><span>Usuário</span><input name="username" autocomplete="off" autocapitalize="none" spellcheck="false" required pattern="[a-z0-9][a-z0-9_.\-]{2,31}" title="3 a 32 caracteres: letras minúsculas, números, ponto, hífen ou _"></label>
      <label class="field"><span>Senha</span><input name="password" type="text" autocomplete="off" minlength="8" required></label>
      <label class="check-field"><input type="checkbox" name="admin"> Admin</label>
      <button class="btn-primary" type="submit">Criar usuário</button>
    </form>
    <p class="form-err" id="user-err" role="alert"></p>
    <div class="users" id="users"><p class="side-empty">Carregando…</p></div>`;
  $('#user-new').addEventListener('submit', async (e) => {
    e.preventDefault();
    const f = e.currentTarget;
    $('#user-err').textContent = '';
    try {
      await adminApi('/users', { method: 'POST', body: { username: f.username.value.trim().toLowerCase(), password: f.password.value, admin: f.admin.checked } });
      toast(`Usuário ${f.username.value.trim().toLowerCase()} criado.`);
      f.reset();
      paintUsers();
    } catch (err) { $('#user-err').textContent = err.message; }
  });
  paintUsers();
}
async function paintUsers() {
  const box = $('#users');
  if (!box) return;
  let list;
  try { list = await adminApi('/users'); } catch (err) { box.innerHTML = `<p class="form-err">${esc(err.message)}</p>`; return; }
  box.innerHTML = list.map((u) => `<div class="user-row${u.disabled ? ' off' : ''}" data-u="${esc(u.username)}">
      <div class="user-main"><span class="user-name">${esc(u.username)}</span>
        <span class="user-tags">${u.admin ? '<span class="tag">admin</span>' : ''}${u.disabled ? '<span class="tag off">desativado</span>' : ''}<span class="tag st-${esc(u.container || 'none')}">${u.container ? esc(CSTATE[u.container] || u.container) : 'sem espaço ainda'}</span></span>
        <span class="user-meta">${u.lastLogin ? 'entrou ' + ago(u.lastLogin) + (ago(u.lastLogin) === 'agora' ? '' : ' atrás') : 'nunca entrou'}</span></div>
      <div class="user-acts">
        <button type="button" class="btn-flat" data-ua="pw">Trocar senha</button>
        ${u.username === S.user ? '' : `<button type="button" class="btn-flat" data-ua="toggle">${u.disabled ? 'Ativar' : 'Desativar'}</button>`}
        <button type="button" class="btn-flat" data-ua="restart">Reiniciar espaço</button>
        ${u.username === S.user ? '' : `<button type="button" class="icon-btn danger" data-ua="delete" aria-label="Apagar ${esc(u.username)}">${icon('trash')}</button>`}
      </div>
      <form class="user-pw" hidden><input type="text" name="pw" placeholder="Nova senha (mín. 8)" minlength="8" required autocomplete="off"><button class="btn-primary" type="submit">Salvar</button><button class="btn-flat" type="button" data-ua="pw-cancel">Cancelar</button></form>
    </div>`).join('');
}
document.addEventListener('click', async (e) => {
  const b = e.target.closest('[data-ua]');
  if (!b) return;
  const row = b.closest('.user-row'), u = row.dataset.u, act = b.dataset.ua;
  try {
    if (act === 'pw') { const f = $('.user-pw', row); f.hidden = false; f.pw.focus(); }
    if (act === 'pw-cancel') $('.user-pw', row).hidden = true;
    if (act === 'toggle') { const off = !row.classList.contains('off'); await adminApi('/users/' + u, { method: 'PATCH', body: { disabled: off } }); toast(off ? `${u} desativado.` : `${u} ativado.`); paintUsers(); }
    if (act === 'restart') { b.disabled = true; b.textContent = 'Reiniciando…'; await adminApi(`/users/${u}/restart`, { method: 'POST' }); toast(`Espaço de ${u} reiniciado.`); paintUsers(); }
    if (act === 'delete') {
      if (!(await confirmDialog(`Apagar ${u}?`, 'A pessoa perde o acesso na hora. Os arquivos e conversas dela também são apagados e não dá pra desfazer.'))) return;
      await adminApi(`/users/${u}?data=1`, { method: 'DELETE' });
      toast(`${u} apagado.`);
      paintUsers();
    }
  } catch (err) { toast(err.message); paintUsers(); }
});
document.addEventListener('submit', async (e) => {
  const f = e.target.closest('.user-pw');
  if (!f) return;
  e.preventDefault();
  const u = f.closest('.user-row').dataset.u;
  try { await adminApi('/users/' + u, { method: 'PATCH', body: { password: f.pw.value } }); toast(`Senha de ${u} trocada.`); f.reset(); f.hidden = true; }
  catch (err) { toast(err.message); }
});
// Gravação do atalho novo
document.addEventListener('keydown', (e) => {
  const k = S.recording;
  if (!k) return;
  e.preventDefault(); e.stopPropagation();
  if (e.key === 'Escape') { S.recording = null; return renderSettings(); }
  const c = comboFrom(e);
  if (!c) return;
  const sc = { ...S.prefs.shortcuts, [k]: c };
  const clash = Object.keys(ACTIONS).find((a) => a !== k && (a in sc ? sc[a] : ACTIONS[a].def) === c);
  if (clash) { sc[clash] = ''; toast(`Tirei esse atalho de "${ACTIONS[clash].name}".`); }
  S.recording = null;
  savePrefs({ shortcuts: sc });
  renderSettings();
}, true);

// ---------- Lateral no celular + seções ----------
const closeSide = () => { $('#app').classList.remove('side-open'); $('#scrim').hidden = true; };
const openSide = () => { $('#app').classList.add('side-open'); $('#scrim').hidden = false; };
$('#scrim').addEventListener('click', closeSide);
// ---------- Abrir pasta (workspace, só no codefy web do computador) ----------
async function openWorkspace(folder) {
  $('#ws-err').textContent = '';
  try { await api('/workspace', { method: 'POST', body: { folder } }); }
  catch (err) { $('#ws-err').textContent = err.message; return; }
  $('#ws').close();
  $('#groups').innerHTML = '<div class="empty"><h2>Abrindo a pasta…</h2><p>O CodeFy volta em alguns segundos.</p></div>';
  for (let i = 0; i < 100; i++) {
    await new Promise((r) => setTimeout(r, 600));
    const me = await fetch('/auth/me').then((r) => r.json()).catch(() => null);
    if (me?.boot && me.boot !== S.boot) { S.leaving = true; return location.reload(); } // recarregar sem o aviso de sair
  }
}
$('#ws-btn').addEventListener('click', async () => {
  const d = $('#ws'); $('#ws-err').textContent = ''; $('#ws-path').value = '';
  const w = await api('/workspace').catch(() => ({ recent: [] }));
  $('#ws-recent').innerHTML = w.recent.length ? '<span class="ws-lbl">Recentes</span>' + w.recent.map((f) => `<button type="button" class="ws-item" data-f="${esc(f)}"><svg class="i"><use href="#i-folder"/></svg><span class="n">${esc(f.split(/[\\/]/).pop())}</span><span class="d">${esc(f)}</span></button>`).join('') : '';
  d.showModal();
});
$('#ws-recent').addEventListener('click', (e) => { const b = e.target.closest('.ws-item'); if (b) openWorkspace(b.dataset.f); });
$('#ws-open').addEventListener('click', () => { const f = $('#ws-path').value.trim(); if (f) openWorkspace(f); else $('#ws-err').textContent = 'Cole o caminho ou clique em Procurar pasta.'; });
$('#ws-path').addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); $('#ws-open').click(); } });
$('#ws-browse').addEventListener('click', async () => {
  const b = $('#ws-browse'); b.disabled = true;
  const r = await api('/workspace/pick', { method: 'POST' }).catch(() => ({ error: true }));
  b.disabled = false;
  if (r.folder) return openWorkspace(r.folder);
  if (r.error) $('#ws-err').textContent = 'Não consegui abrir a janela de pastas aqui. Cole o caminho da pasta.';
});

// Vistas da lateral (Arquivos / Conversas), lembradas neste navegador.
function setView(v) {
  const side = $('#side'), app = $('#app');
  if (side.dataset.view === v && !app.classList.contains('side-hidden')) { app.classList.add('side-hidden'); v = side.dataset.view; }
  else { app.classList.remove('side-hidden'); side.dataset.view = v; }
  document.querySelectorAll('.act[data-view]').forEach((b) => b.classList.toggle('on', b.dataset.view === v && !app.classList.contains('side-hidden')));
  try { localStorage.setItem('codefy.view', JSON.stringify({ v, hidden: app.classList.contains('side-hidden') })); } catch {}
}
document.querySelectorAll('.act[data-view]').forEach((b) => b.addEventListener('click', () => setView(b.dataset.view)));
$('#act-term').addEventListener('click', () => $('#term-btn').click());
$('#act-settings').addEventListener('click', () => $('#settings-btn').click());
try { const sv = JSON.parse(localStorage.getItem('codefy.view') || 'null'); if (sv) { if (sv.hidden) $('#app').classList.add('side-hidden'); } } catch {}
{ const v = $('#side').dataset.view; document.querySelectorAll('.act[data-view]').forEach((b) => b.classList.toggle('on', b.dataset.view === v && !$('#app').classList.contains('side-hidden'))); }
document.querySelectorAll('.sec-head').forEach((b) => b.addEventListener('click', () => {
  const sec = b.closest('.side-sec');
  const c = sec.classList.toggle('collapsed');
  b.setAttribute('aria-expanded', !c);
}));
$('#new-chat').addEventListener('click', () => newChat());
$('#tree-collapse').addEventListener('click', () => { S.expanded = new Set(['']); store.set('expanded', ['']); renderTree(); });
setInterval(() => { renderChats(); S.groups.forEach((g) => g.active && !isTermTab(g.active) && updateComposer(g.active)); }, 60000);

// ---------- Início ----------
async function boot() {
  const me = await fetch('/auth/me').then((r) => r.json()).catch(() => ({}));
  S.localAuth = !!me.local;
  if (!me.ok) return showLogin(me.local);
  S.workdir = me.workdir || '';
  S.user = me.user || '';
  S.admin = !!me.admin;
  S.boot = me.boot; S.workspaces = !!me.workspaces; $('#ws-btn').hidden = !S.workspaces; S.launcher = !!me.launcher; S.pick = me.pick ?? S.launcher; S.hostFolder = me.hostFolder || '';
  $('#workdir').textContent = ((S.hostFolder || S.workdir).split(/[\\/]/).filter(Boolean).pop() || 'Projetos').toUpperCase();
  $('#nav-users').hidden = !S.admin;
  $('#login').hidden = true;
  $('#app').hidden = false;
  // O motor leva alguns segundos pra subir quando o container reinicia.
  for (let i = 0; ; i++) {
    try { await loadSessions(); break; } catch (err) {
      if (err.message === 'login') return;
      if (i < 80) {
        $('#groups').innerHTML = '<div class="empty"><h2>Iniciando…</h2><p>O CodeFy está ligando. Leva só alguns segundos.</p></div>';
        await new Promise((r) => setTimeout(r, 1500));
        continue;
      }
      $('#groups').innerHTML = `<div class="empty"><h2>O motor não respondeu</h2><p>${esc(err.message)}</p><button class="btn-primary" type="button" onclick="location.reload()">Tentar de novo</button></div>`;
      return;
    }
  }
  const prefs = await api('/prefs').catch(() => ({}));
  Object.assign(S.prefs, prefs || {});
  S.prefs.shortcuts = S.prefs.shortcuts || {};
  applyTheme(S.prefs.theme || store.get('theme', 'padrao'));
  renderAll();
  refreshTree();
  connectEvents();
  if (URLQ.has('new')) newChat();
  window.termBoot?.();
}
boot();
