// ---------- Explorer: criar arquivo e pasta (como no VS Code) ----------
// Botões no cabeçalho de Projetos e clique direito numa pasta. O nome é digitado na própria árvore;
// "src/app.js" cria as pastas do caminho. Arquivo novo já abre no editor.
let treeSel = ''; // última pasta clicada (ou a pasta do último arquivo) = onde os botões criam

async function newEntry(type, dir = treeSel) {
  if (dir) {
    S.expanded.add(dir); store.set('expanded', [...S.expanded]);
    if (!S.tree.has(dir)) await loadDir(dir).catch(() => {});
    renderTree();
  }
  $('#sec-files').classList.remove('collapsed');
  const ul = dir ? $(`.tree-row[data-path="${CSS.escape(dir)}"]`)?.closest('li')?.querySelector(':scope > ul') : $('#tree');
  if (!ul) return;
  ul.querySelector(':scope > .tree-new')?.remove();
  const li = document.createElement('li');
  li.className = 'tree-new';
  li.innerHTML = `<span class="tw none"></span>${icon(type === 'directory' ? 'folder' : 'file')}<input type="text" spellcheck="false" autocomplete="off" aria-label="${type === 'directory' ? 'Nome da pasta' : 'Nome do arquivo'}" placeholder="${type === 'directory' ? 'nome-da-pasta' : 'arquivo.txt'}">`;
  ul.prepend(li);
  const inp = $('input', li);
  inp.focus();
  let done = false;
  const finish = async (ok) => {
    if (done) return;
    const name = inp.value.trim().replace(/^\/+|\/+$/g, '');
    if (!ok || !name) { done = true; li.remove(); return; }
    done = true;
    inp.disabled = true;
    try {
      const r = await api('/file/new', { method: 'POST', body: { path: (dir ? dir + '/' : '') + name, type } });
      // Pastas do caminho novo ficam abertas pra mostrar o que foi criado.
      const parts = r.path.split('/');
      for (let i = 1; i < parts.length; i++) S.expanded.add(parts.slice(0, i).join('/'));
      if (type === 'directory') { S.expanded.add(r.path); treeSel = r.path; }
      store.set('expanded', [...S.expanded]);
      await refreshTree();
      $(`.tree-row[data-path="${CSS.escape(r.path)}"]`)?.classList.add('flash');
      if (type === 'file') openFile(r.absolute);
    } catch (err) {
      toast(err.message);
      done = false; inp.disabled = false; inp.focus(); inp.select();
    }
  };
  inp.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') { e.preventDefault(); finish(true); }
    if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); finish(false); }
  });
  inp.addEventListener('blur', () => setTimeout(() => finish(!!inp.value.trim()), 0));
}
$('#tree-new-file').addEventListener('click', () => newEntry('file'));
$('#tree-new-dir').addEventListener('click', () => newEntry('directory'));


// ---------- Seleção, teclado e ações do Explorer (como no VS Code) ----------
const X = { sel: new Set(), anchor: null, focus: null, clip: null }; // clip = { mode: 'copy'|'cut', paths }
const MOD = isMac ? 'Meta' : 'Ctrl';
const treeRows = () => [...document.querySelectorAll('#tree .tree-row')];
const rowOf = (p) => $(`#tree .tree-row[data-path="${CSS.escape(p)}"]`);
const absOf = (p) => (S.workdir ? S.workdir + '/' : '') + p;
const baseOf = (p) => p.split('/').pop();
const dirOfRow = (row) => (!row ? '' : row.dataset.dir === 'true' ? row.dataset.path : parentOf(row.dataset.path));
function paintSel() {
  const cut = X.clip?.mode === 'cut' ? X.clip.paths : [];
  for (const r of treeRows()) {
    r.classList.toggle('sel', X.sel.has(r.dataset.path));
    r.classList.toggle('cut', cut.includes(r.dataset.path));
  }
}
new MutationObserver(paintSel).observe($('#tree'), { childList: true });
const setSel = (paths, focus) => { X.sel = new Set(paths); X.focus = focus ?? paths[paths.length - 1] ?? null; paintSel(); };
// Ações valem pra seleção inteira quando a linha clicada faz parte dela.
const targetsOf = (p) => (p && X.sel.has(p) && X.sel.size > 1 ? [...X.sel] : p ? [p] : [...X.sel]);

$('#tree').addEventListener('click', (e) => {
  const row = e.target.closest('.tree-row');
  if (!row) return;
  const p = row.dataset.path;
  treeSel = dirOfRow(row);
  if (e.metaKey || e.ctrlKey) {
    e.preventDefault(); e.stopPropagation();
    X.sel.has(p) ? X.sel.delete(p) : X.sel.add(p);
    X.anchor = p; X.focus = p; return paintSel();
  }
  if (e.shiftKey && X.anchor) {
    e.preventDefault(); e.stopPropagation();
    const list = treeRows().map((r) => r.dataset.path), a = list.indexOf(X.anchor), b = list.indexOf(p);
    if (a >= 0 && b >= 0) return setSel(list.slice(Math.min(a, b), Math.max(a, b) + 1), p);
  }
  X.anchor = p; setSel([p], p);
}, true);

// ---- Aviso com botão (Desfazer) ----
function toastAction(msg, label, fn) {
  const t = $('#toast');
  t.textContent = msg + ' ';
  const b = document.createElement('button');
  b.type = 'button'; b.className = 'toast-act'; b.textContent = label;
  b.onclick = () => { t.hidden = true; fn(); };
  t.append(b); t.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { t.hidden = true; }, 8000);
}

// Caminho renomeado/movido: pastas abertas e o arquivo aberto no editor acompanham.
function followMove(from, to) {
  const re = (x) => (x === from ? to : x.startsWith(from + '/') ? to + x.slice(from.length) : x);
  S.expanded = new Set([...S.expanded].map(re)); store.set('expanded', [...S.expanded]);
  if (S.filePath) {
    const cur = rel(S.filePath), nxt = re(cur);
    if (nxt !== cur) { S.filePath = absOf(nxt); $('#file-path').textContent = nxt; $('#file-path').title = nxt; }
  }
}
function forgetDeleted(paths) {
  if (S.filePath && paths.some((p) => rel(S.filePath) === p || rel(S.filePath).startsWith(p + '/'))) {
    disposeEditors(); FP.mode = null; S.filePath = null; $('#file-panel').hidden = true;
  }
}

// ---- Renomear (F2): o nome vira um campo na própria linha ----
function renameEntry(p) {
  const row = rowOf(p);
  if (!row) return;
  const tn = $('.tn', row), old = baseOf(p);
  const inp = document.createElement('input');
  inp.className = 'tree-rename'; inp.value = old; inp.spellcheck = false; inp.setAttribute('aria-label', 'Novo nome');
  tn.replaceWith(inp);
  row.draggable = false;
  inp.focus();
  const dot = row.dataset.dir === 'true' ? -1 : old.lastIndexOf('.');
  inp.setSelectionRange(0, dot > 0 ? dot : old.length);
  let done = false;
  const finish = async (ok) => {
    if (done) return; done = true;
    const name = inp.value.trim();
    if (!ok || !name || name === old) return renderTree();
    if (/[\\/]/.test(name)) { toast('O nome não pode ter / nem \\.'); done = false; inp.focus(); return; }
    const to = (parentOf(p) ? parentOf(p) + '/' : '') + name;
    try {
      await api('/file/rename', { method: 'POST', body: { from: p, to } });
      followMove(p, to);
      await refreshTree();
      setSel([to], to); rowOf(to)?.focus();
    } catch (err) { toast(err.message); done = false; inp.focus(); inp.select(); }
  };
  inp.addEventListener('keydown', (e) => {
    e.stopPropagation();
    if (e.key === 'Enter') { e.preventDefault(); finish(true); }
    if (e.key === 'Escape') { e.preventDefault(); finish(false); }
  });
  inp.addEventListener('click', (e) => e.stopPropagation(), true);
  inp.addEventListener('blur', () => setTimeout(() => finish(true), 0));
}

// ---- Apagar (vai pra lixeira do CodeFy, com Desfazer) ----
async function deleteEntries(paths) {
  paths = paths.filter((p) => !paths.some((q) => q !== p && p.startsWith(q + '/')));
  if (!paths.length) return;
  const what = paths.length === 1 ? `"${baseOf(paths[0])}"` : `${paths.length} itens`;
  if (!(await confirmDialog(`Apagar ${what}?`, 'Vai pra lixeira do CodeFy. Dá pra desfazer logo em seguida (a lixeira guarda por 7 dias).', 'Apagar'))) return;
  try {
    const r = await api('/file/delete', { method: 'POST', body: { paths } });
    forgetDeleted(paths);
    setSel([]);
    await refreshTree();
    toastAction(`${paths.length === 1 ? baseOf(paths[0]) : paths.length + ' itens'} ${paths.length === 1 ? 'foi' : 'foram'} pra lixeira.`, 'Desfazer', async () => {
      try { await api('/file/restore', { method: 'POST', body: { ids: r.trash } }); await refreshTree(); toast('Restaurado.'); } catch (err) { toast(err.message); }
    });
  } catch (err) { toast(err.message); }
}

// ---- Recortar / copiar / colar / duplicar ----
function clip(mode, paths) {
  if (!paths.length) return;
  X.clip = { mode, paths }; paintSel();
  toast(`${paths.length === 1 ? baseOf(paths[0]) : paths.length + ' itens'} ${mode === 'cut' ? 'recortado' : 'copiado'}${paths.length === 1 ? '' : 's'}. ${isMac ? '⌘' : 'Ctrl+'}V cola na pasta selecionada.`);
}
async function pasteInto(dir) {
  if (!X.clip) return;
  const { mode, paths } = X.clip;
  try {
    const r = await api(`/file/${mode === 'cut' ? 'move' : 'copy'}`, { method: 'POST', body: { paths, to: dir } });
    if (mode === 'cut') { paths.forEach((p, i) => r.paths[i] && followMove(p, r.paths[i])); X.clip = null; }
    if (dir) { S.expanded.add(dir); store.set('expanded', [...S.expanded]); }
    await refreshTree();
    setSel(r.paths);
  } catch (err) { toast(err.message); }
}
async function duplicate(paths) {
  const made = [];
  try {
    for (const p of paths) made.push(...(await api('/file/copy', { method: 'POST', body: { paths: [p], to: parentOf(p) } })).paths);
    await refreshTree(); setSel(made);
  } catch (err) { toast(err.message); }
}
async function moveTo(paths, dir, copy) {
  paths = paths.filter((p) => parentOf(p) !== dir || copy);
  if (!paths.length) return;
  try {
    const r = await api(`/file/${copy ? 'copy' : 'move'}`, { method: 'POST', body: { paths, to: dir } });
    if (!copy) paths.forEach((p, i) => r.paths[i] && followMove(p, r.paths[i]));
    if (dir) { S.expanded.add(dir); store.set('expanded', [...S.expanded]); }
    await refreshTree(); setSel(r.paths);
  } catch (err) { toast(err.message); }
}
const copyText = (t, what) => navigator.clipboard.writeText(t).then(() => toast(`${what} copiado.`), () => toast('Não deu pra copiar.'));

// Menciona no campo da conversa com foco (o agente lê o caminho).
function mention(paths) {
  const ta = $('.composer textarea', groupEl(S.g));
  if (!ta) return toast('Abra uma conversa pra mencionar.');
  const txt = paths.map((p) => '@' + p).join(' ') + ' ';
  ta.value = (ta.value && !/\s$/.test(ta.value) ? ta.value + ' ' : ta.value) + txt;
  ta.dispatchEvent(new Event('input', { bubbles: true }));
  ta.focus();
}

// ---- Menu de clique direito (linha, seleção ou espaço vazio) ----
function treeMenu(row, x, y) {
  const p = row?.dataset.path || '';
  const isDir = !row || row.dataset.dir === 'true';
  if (row && !X.sel.has(p)) setSel([p], p);
  const ts = row ? targetsOf(p) : [];
  const many = ts.length > 1;
  const here = row ? dirOfRow(row) : '';
  const k = (c) => `${MOD}+${c}`;
  const items = [];
  if (!many) {
    if (row && !isDir) items.push({ icon: 'file', label: 'Abrir', run: () => openFile(row.dataset.abs) });
    items.push({ icon: 'file-plus', label: 'Novo arquivo', run: () => newEntry('file', here) });
    items.push({ icon: 'folder-plus', label: 'Nova pasta', run: () => newEntry('directory', here) });
    items.push({ icon: 'cmd', label: 'Abrir no terminal', run: () => newTerm('shell', here || undefined) });
  }
  if (row) items.push({ icon: 'chat-plus', label: 'Mencionar na conversa', run: () => mention(ts) });
  items.push('-');
  if (row) {
    items.push({ icon: 'x', label: 'Recortar', keys: k('KeyX'), run: () => clip('cut', ts) });
    items.push({ icon: 'file', label: 'Copiar', keys: k('KeyC'), run: () => clip('copy', ts) });
  }
  if (X.clip) items.push({ icon: 'download', label: `Colar${X.clip.paths.length > 1 ? ` (${X.clip.paths.length})` : ''}`, keys: k('KeyV'), run: () => pasteInto(here) });
  if (row) {
    items.push('-');
    if (!many) {
      items.push({ icon: 'file', label: 'Copiar caminho', run: () => copyText(row.dataset.abs, 'Caminho') });
      items.push({ icon: 'file', label: 'Copiar caminho relativo', run: () => copyText(p, 'Caminho relativo') });
      items.push('-');
      items.push({ icon: 'pencil', label: 'Renomear', keys: 'F2', run: () => renameEntry(p) });
    }
    items.push({ icon: 'split', label: 'Duplicar', run: () => duplicate(ts) });
    items.push({ icon: 'trash', label: many ? `Apagar ${ts.length} itens` : 'Apagar', keys: isMac ? 'Meta+Backspace' : 'Delete', danger: true, run: () => deleteEntries(ts) });
  }
  if (!many) {
    items.push('-');
    if (isDir) {
      items.push({ icon: 'upload', label: row ? 'Enviar arquivos pra cá' : 'Enviar arquivos', run: () => pick('files', here) });
      items.push({ icon: 'folder', label: row ? 'Enviar uma pasta pra cá' : 'Enviar uma pasta', run: () => pick('dir', here) });
      items.push({ icon: 'download', label: row ? 'Baixar pasta (.zip)' : 'Baixar tudo (.zip)', run: () => downloadPath(here || '.') });
    } else items.push({ icon: 'download', label: 'Baixar', run: () => downloadPath(p) });
  }
  while (items[items.length - 1] === '-') items.pop();
  showCtx(items.filter((it, i) => !(it === '-' && (i === 0 || items[i - 1] === '-'))), x, y);
}
$('#sec-files').addEventListener('contextmenu', (e) => {
  if (e.target.closest('.sec-row, .tree-new, .tree-rename')) return;
  e.preventDefault();
  treeMenu(e.target.closest('.tree-row'), e.clientX, e.clientY);
});

// ---- Teclado na árvore ----
$('#tree').addEventListener('keydown', (e) => {
  const row = e.target.closest?.('.tree-row');
  if (!row || e.target.tagName === 'INPUT') return;
  const p = row.dataset.path, mod = isMac ? e.metaKey : e.ctrlKey;
  const list = treeRows(), i = list.indexOf(row);
  const go = (r) => { if (!r) return; r.focus(); if (e.shiftKey && X.anchor) { const a = list.indexOf(rowOf(X.anchor)), b = list.indexOf(r); setSel(list.slice(Math.min(a, b), Math.max(a, b) + 1).map((x) => x.dataset.path), r.dataset.path); } else { X.anchor = r.dataset.path; setSel([r.dataset.path]); } };
  const stop = () => { e.preventDefault(); e.stopPropagation(); };
  if (e.key === 'F2' || (isMac && e.key === 'Enter' && e.altKey)) { stop(); return renameEntry(p); }
  if (e.key === 'Delete' || (isMac && e.key === 'Backspace' && e.metaKey)) { stop(); return deleteEntries(targetsOf(p)); }
  if (mod && e.code === 'KeyC') { stop(); return clip('copy', targetsOf(p)); }
  if (mod && e.code === 'KeyX') { stop(); return clip('cut', targetsOf(p)); }
  if (mod && e.code === 'KeyV') { stop(); return pasteInto(dirOfRow(row)); }
  if (mod && e.code === 'KeyA') { stop(); return setSel(list.map((r) => r.dataset.path), p); }
  if (e.key === 'ArrowDown') { stop(); return go(list[i + 1]); }
  if (e.key === 'ArrowUp') { stop(); return go(list[i - 1]); }
  if (e.key === 'ArrowRight' && row.dataset.dir === 'true') { stop(); if (!S.expanded.has(p)) row.click(); else go(list[i + 1]); return; }
  if (e.key === 'ArrowLeft') {
    stop();
    if (row.dataset.dir === 'true' && S.expanded.has(p)) return row.click();
    const parent = parentOf(p); if (parent) go(rowOf(parent));
  }
  if (e.key === 'Escape' && X.clip) { stop(); X.clip = null; paintSel(); }
});

// ---- Arrastar dentro da árvore: move (com ⌥/Alt, copia) ----
const RELS_T = 'application/x-claudex-rels';
$('#tree').addEventListener('dragstart', (e) => {
  const row = e.target.closest('.tree-row');
  if (!row) return;
  if (!X.sel.has(row.dataset.path)) setSel([row.dataset.path]);
  e.dataTransfer.setData(RELS_T, JSON.stringify(targetsOf(row.dataset.path)));
  e.dataTransfer.effectAllowed = 'copyMove';
});
const relsDrag = (e) => [...(e.dataTransfer?.types || [])].includes(RELS_T);
const clearDrop = () => document.querySelectorAll('.tree-row.drop, #tree.drop-root').forEach((r) => r.classList.remove('drop', 'drop-root'));
$('#sec-files').addEventListener('dragover', (e) => {
  if (!relsDrag(e)) return;
  e.preventDefault();
  e.dataTransfer.dropEffect = e.altKey ? 'copy' : 'move';
  clearDrop();
  const row = e.target.closest('.tree-row');
  const dirRow = row ? (row.dataset.dir === 'true' ? row : rowOf(parentOf(row.dataset.path))) : null;
  dirRow ? dirRow.classList.add('drop') : $('#tree').classList.add('drop-root');
});
$('#sec-files').addEventListener('dragleave', (e) => { if (relsDrag(e) && !e.currentTarget.contains(e.relatedTarget)) clearDrop(); });
$('#sec-files').addEventListener('drop', (e) => {
  if (!relsDrag(e)) return;
  e.preventDefault(); e.stopPropagation();
  clearDrop();
  let paths; try { paths = JSON.parse(e.dataTransfer.getData(RELS_T)); } catch { return; }
  moveTo(paths, dirOfRow(e.target.closest('.tree-row')), e.altKey);
});
